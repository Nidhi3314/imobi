from app.agents.conflict_agent import run_conflict_detection
from app.db.models import Guardrail, GuardrailSource


def _guardrail(session, id, statement, domain, value, unit, subgroup, metric="duration_days"):
    g = Guardrail(
        id=id,
        domain=domain,
        statement=statement,
        severity="Mandatory",
        normalized_metric=metric,
        normalized_value=value,
        normalized_raw_value=value,
        normalized_unit=unit,
        normalized_subgroup=subgroup,
    )
    session.add(g)
    session.flush()
    session.add(GuardrailSource(guardrail_id=id, clause_id=f"CL-{id}", document_id=f"DOC-{id}"))
    session.commit()
    return g


def test_same_dimension_different_value_opens_ticket_not_a_merge(session):
    _guardrail(
        session, "GR-A", "Security event logs must be retained for a minimum of 12 months for investigation.",
        "Information Security", 360.0, "months", "lifecycle",
    )
    _guardrail(
        session, "GR-B", "Logs containing personal data must be purged or anonymised within 90 days.",
        "Privacy", 90.0, "days", "lifecycle",
    )
    tickets = run_conflict_detection(session)
    assert len(tickets) == 1
    ticket = tickets[0]
    assert ticket.status == "open", "a detected conflict must never be auto-resolved"
    assert {ticket.guardrail_id_a, ticket.guardrail_id_b} == {"GR-A", "GR-B"}


def test_conflict_can_cross_domains(session):
    """The seeded retention conflict spans InfoSec and Privacy documents --
    conflict detection must not be scoped to a single domain."""
    _guardrail(
        session, "GR-A", "Security event logs must be retained for a minimum of 12 months for investigation.",
        "Information Security", 360.0, "months", "lifecycle",
    )
    _guardrail(
        session, "GR-B", "Logs containing personal data must be purged or anonymised within 90 days.",
        "Privacy", 90.0, "days", "lifecycle",
    )
    tickets = run_conflict_detection(session)
    domains = {tickets[0].guardrail_id_a, tickets[0].guardrail_id_b}
    assert domains == {"GR-A", "GR-B"}


def test_same_verb_family_but_unrelated_topic_does_not_falsely_conflict(session):
    """'Rotate keys every 12 months' and 'report incidents within 24 hours' share
    no real topic, only a broad verb-family category -- must not be flagged."""
    _guardrail(
        session, "GR-A", "Suspected security incidents must be reported to SecOps within 24 hours of detection.",
        "Information Security", 1.0, "hours", "sla_turnaround",
    )
    _guardrail(
        session, "GR-B", "Critical severity vulnerabilities must be remediated within 14 days of identification.",
        "Information Security", 14.0, "days", "sla_turnaround",
    )
    tickets = run_conflict_detection(session)
    assert tickets == [], "clauses with zero shared vocabulary should not be flagged just for sharing a verb family"


def test_identical_value_is_not_a_conflict(session):
    _guardrail(session, "GR-A", "Passwords must be at least 12 characters.", "Information Security", 12.0, "characters", None, metric="length_chars")
    _guardrail(session, "GR-B", "Passwords must be a minimum of 12 characters.", "Information Security", 12.0, "characters", None, metric="length_chars")
    tickets = run_conflict_detection(session)
    assert tickets == [], "same value stated two ways is not a conflict"
