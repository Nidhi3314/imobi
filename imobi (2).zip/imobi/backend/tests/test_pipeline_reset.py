from datetime import datetime, timezone

from app.db.models import Clause, ConflictTicket, DesignDescription, Document
from app.pipeline import reset_for_new_ingest


def test_reset_clears_raw_tables_so_a_new_workbook_never_accumulates(session):
    """Regression test: uploading a modified workbook (different ID
    namespace, e.g. the shuffled-dataset rehearsal) must fully replace the
    previous ingest, not add to it -- caught via clauses_extracted (99)
    exceeding the uploaded workbook's own clause count (51) after two
    real ingests in a row."""
    session.add(Document(id="DOC-OLD", title="Old", domain="Information Security"))
    session.add(Clause(id="CL-OLD", document_id="DOC-OLD", clause_text="old clause"))
    session.add(DesignDescription(id="DSN-OLD", title="Old design", domain="Information Security", description="x"))
    session.commit()

    reset_for_new_ingest(session)

    assert session.query(Document).count() == 0
    assert session.query(Clause).count() == 0
    assert session.query(DesignDescription).count() == 0


def test_reset_preserves_decided_tickets_but_clears_open_ones(session):
    """Decided tickets are the learned precedent and must survive a
    re-ingest; open tickets reference guardrails about to be deleted and
    would be stale, so those are cleared."""
    session.add(
        ConflictTicket(
            id="CFT-decided",
            guardrail_id_a="GR-a",
            guardrail_id_b="GR-b",
            metric="length_chars",
            status="approved_a",
            decided_by="reviewer1",
            decided_at=datetime.now(timezone.utc),
        )
    )
    session.add(
        ConflictTicket(
            id="CFT-open",
            guardrail_id_a="GR-c",
            guardrail_id_b="GR-d",
            metric="duration_days",
            status="open",
        )
    )
    session.commit()

    reset_for_new_ingest(session)

    remaining = session.query(ConflictTicket).all()
    assert [t.id for t in remaining] == ["CFT-decided"]
