from datetime import datetime, timedelta, timezone

from app.agents.precedent_agent import find_precedent, learning_summary
from app.db.models import ConflictTicket


def _ticket(id, metric, status, decided_at=None):
    return ConflictTicket(
        id=id,
        guardrail_id_a=f"GR-{id}-a",
        guardrail_id_b=f"GR-{id}-b",
        metric=metric,
        rationale="r",
        recommended_resolution="rec",
        status=status,
        decided_at=decided_at,
    )


def test_no_precedent_when_nothing_decided_yet(session):
    session.add(_ticket("CFT-1", "duration_days:lifecycle", "open"))
    session.commit()
    assert find_precedent(session, "duration_days:lifecycle") is None


def test_finds_most_recent_decided_ticket_for_same_metric(session):
    now = datetime.now(timezone.utc)
    session.add(_ticket("CFT-old", "duration_days:lifecycle", "approved_a", now - timedelta(days=10)))
    session.add(_ticket("CFT-new", "duration_days:lifecycle", "approved_b", now - timedelta(days=1)))
    session.add(_ticket("CFT-other-metric", "length_chars", "approved_a", now))
    session.commit()

    precedent = find_precedent(session, "duration_days:lifecycle")
    assert precedent is not None
    assert precedent.id == "CFT-new"


def test_learning_summary_counts_only_decided_tickets(session):
    session.add(_ticket("CFT-1", "duration_days:lifecycle", "open"))
    session.add(_ticket("CFT-2", "duration_days:lifecycle", "approved_a", datetime.now(timezone.utc)))
    session.add(_ticket("CFT-3", "length_chars", "kept_open", datetime.now(timezone.utc)))
    session.commit()

    summary = learning_summary(session)
    assert summary["precedent_decisions"] == 2
    assert set(summary["metrics_covered"]) == {"duration_days:lifecycle", "length_chars"}
