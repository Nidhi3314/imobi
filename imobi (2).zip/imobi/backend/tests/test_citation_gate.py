from app.agents.citation_gate import check_citation, gate_finding
from app.db.models import Guardrail, GuardrailSource


def _real_guardrail(session, id="GR-real", broken=False):
    g = Guardrail(id=id, domain="Information Security", statement="A real requirement.", severity="Mandatory", broken_reference=broken)
    session.add(g)
    session.flush()
    session.add(GuardrailSource(guardrail_id=id, clause_id="CL-real", document_id="DOC-real"))
    session.commit()
    return g


def test_valid_citation_passes(session):
    _real_guardrail(session)
    ok, reason = check_citation(session, "GR-real", "CL-real")
    assert ok is True


def test_fabricated_guardrail_id_is_rejected(session):
    ok, reason = check_citation(session, "GR-does-not-exist", "CL-real")
    assert ok is False
    assert "does not exist" in reason


def test_fabricated_clause_id_is_rejected(session):
    _real_guardrail(session)
    ok, reason = check_citation(session, "GR-real", "CL-fabricated")
    assert ok is False
    assert "not among" in reason


def test_broken_reference_guardrail_cannot_be_cited(session):
    _real_guardrail(session, id="GR-broken", broken=True)
    ok, reason = check_citation(session, "GR-broken", "CL-real")
    assert ok is False
    assert "broken source reference" in reason


def test_gate_finding_downgrades_fake_citation_to_unverified(session):
    """The demo's 'inject a fake citation live' moment: the gate must catch
    it regardless of what the Evaluation/Auditor Agents claimed."""
    finding = {
        "guardrail_id": "GR-totally-made-up",
        "clause_id": "CL-totally-made-up",
        "verdict": "Non-compliant",
    }
    gate_finding(session, finding)
    assert finding["verdict"] == "Unverified"
    assert finding["status"] == "suppressed"
    assert finding["citation_gate_passed"] is False


def test_gate_finding_passes_through_a_real_citation(session):
    _real_guardrail(session)
    finding = {"guardrail_id": "GR-real", "clause_id": "CL-real", "verdict": "Compliant"}
    gate_finding(session, finding)
    assert finding["verdict"] == "Compliant"
    assert finding["status"] == "shown"
    assert finding["citation_gate_passed"] is True
