from app import auth
from app.db.models import User


def _make_user(session, username="alice", password="testpass123"):
    user = User(username=username, email=f"{username}@example.com", password_hash=auth.hash_password(password))
    session.add(user)
    session.commit()
    return user


def test_password_hash_roundtrip(session):
    hashed = auth.hash_password("correct-password")
    assert auth.verify_password("correct-password", hashed)
    assert not auth.verify_password("wrong-password", hashed)


def test_user_session_created_and_resolved(session):
    user = _make_user(session)
    record = auth.create_user_session(session, user)
    resolved = auth.get_user_from_token(session, record.token)
    assert resolved is not None
    assert resolved.id == user.id


def test_require_user_rejects_missing_or_bad_token(session):
    try:
        auth.require_user(session, None)
        assert False, "should have raised"
    except Exception as e:
        assert "sign in" in str(e).lower()

    try:
        auth.require_user(session, "Bearer not-a-real-token")
        assert False, "should have raised"
    except Exception as e:
        assert "invalid" in str(e).lower() or "expired" in str(e).lower()


def test_admin_and_user_sessions_are_fully_independent(session):
    """A User account must never resolve as an admin, and vice versa --
    registering as a regular CompliX user must never grant Conflict Desk
    decision rights."""
    from app.db.models import AdminUser

    user = _make_user(session, username="regular_user")
    admin = AdminUser(username="reviewer", email="reviewer@example.com", password_hash=auth.hash_password("adminpass123"))
    session.add(admin)
    session.commit()

    user_record = auth.create_user_session(session, user)
    admin_record = auth.create_session(session, admin)

    assert auth.get_admin_from_token(session, user_record.token) is None
    assert auth.get_user_from_token(session, admin_record.token) is None
