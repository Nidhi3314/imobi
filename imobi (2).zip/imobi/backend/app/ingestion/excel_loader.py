"""
Loads a GuardrailIQ-shaped workbook into the DB, verbatim, as ground truth.

Header-driven (not position-driven) so a judge's modified copy can reorder
columns or add new rows without breaking ingestion. Only Governance_Documents,
Clauses and Design_Descriptions are trusted as raw input; the sample
Guardrails sheet is intentionally NOT ingested as the system's model -- the
Extraction Agent derives guardrails from Clauses itself so the pipeline
survives a workbook that doesn't ship a pre-built Guardrails sheet at all.
"""
from __future__ import annotations

from typing import BinaryIO

import openpyxl
from sqlalchemy.orm import Session

from app.db.models import Clause, DesignDescription, Document


def _sheet_rows(ws):
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header = [str(h).strip() if h is not None else "" for h in rows[0]]
    out = []
    for row in rows[1:]:
        if row is None or all(c is None for c in row):
            continue
        record = {header[i]: row[i] for i in range(len(header)) if i < len(row)}
        out.append(record)
    return out


def load_workbook(session: Session, file_or_path) -> dict:
    """file_or_path: a path string or a file-like object (for the Judge Mode upload)."""
    wb = openpyxl.load_workbook(file_or_path, data_only=True)
    counts = {"documents": 0, "clauses": 0, "design_descriptions": 0}

    if "Governance_Documents" in wb.sheetnames:
        for r in _sheet_rows(wb["Governance_Documents"]):
            doc_id = r.get("Document_ID")
            if not doc_id:
                continue
            doc = session.get(Document, doc_id) or Document(id=doc_id)
            doc.title = r.get("Document_Title")
            doc.domain = r.get("Domain") or "Unspecified"
            doc.document_type = r.get("Document_Type")
            doc.owner_function = r.get("Owner_Function")
            doc.version = str(r.get("Version")) if r.get("Version") is not None else None
            doc.effective_date = str(r.get("Effective_Date")) if r.get("Effective_Date") is not None else None
            doc.status = r.get("Status")
            doc.summary = r.get("Summary")
            session.merge(doc)
            counts["documents"] += 1

    if "Clauses" in wb.sheetnames:
        for r in _sheet_rows(wb["Clauses"]):
            clause_id = r.get("Clause_ID")
            if not clause_id:
                continue
            cl = session.get(Clause, clause_id) or Clause(id=clause_id)
            cl.document_id = r.get("Document_ID")
            cl.clause_ref = r.get("Clause_Ref")
            cl.clause_heading = r.get("Clause_Heading")
            cl.clause_text = r.get("Clause_Text") or ""
            cl.seeded_flag = r.get("Seeded_Flag")
            session.merge(cl)
            counts["clauses"] += 1

    if "Design_Descriptions" in wb.sheetnames:
        for r in _sheet_rows(wb["Design_Descriptions"]):
            design_id = r.get("Design_ID")
            if not design_id:
                continue
            dd = session.get(DesignDescription, design_id) or DesignDescription(id=design_id)
            dd.title = r.get("Design_Title")
            dd.domain = r.get("Domain") or "Unspecified"
            dd.description = r.get("Design_Description") or ""
            dd.expected_outcome = r.get("Expected_Outcome")
            dd.scenario_note = r.get("Scenario_Note")
            session.merge(dd)
            counts["design_descriptions"] += 1

    session.commit()
    return counts
