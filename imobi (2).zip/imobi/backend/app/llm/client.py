"""
Single seam between all agents and whatever LLM gateway the team wires up
("LLmass", or any OpenAI-compatible chat-completions endpoint). Every agent
calls only `complete()` -- swapping providers, or going fully LLM-free, means
touching this file alone.

If no endpoint is configured (GUARDRAILIQ_LLM_BASE_URL unset), `complete()`
raises LLMNotConfigured so callers fall back to their deterministic
regex/heuristic path -- the whole pipeline still runs end-to-end without live
model access, which the guide explicitly allows ("LLM-free option").
"""
from __future__ import annotations

import json
import time
from typing import Any

import requests

from app import config

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3


class LLMNotConfigured(RuntimeError):
    pass


class LLMCallFailed(RuntimeError):
    pass


def is_configured() -> bool:
    return bool(config.LLM_BASE_URL)


def complete(system: str, user: str, json_schema: dict | None = None, model: str | None = None) -> dict[str, Any]:
    """Returns a parsed JSON dict. Assumes an OpenAI-compatible /chat/completions
    shape with `response_format: json_schema`; if the gateway doesn't support
    forced JSON, the caller should still get valid JSON back most of the time
    because we also instruct it in the prompt, with a best-effort repair pass
    below."""
    if not is_configured():
        raise LLMNotConfigured("No LLM gateway configured; caller should use its heuristic fallback.")

    payload = {
        "model": model or config.LLM_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0,
    }
    if json_schema:
        payload["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "response", "schema": json_schema, "strict": True},
        }

    headers = {"Content-Type": "application/json"}
    if config.LLM_API_KEY:
        headers["Authorization"] = f"Bearer {config.LLM_API_KEY}"

    last_error: Exception | None = None
    for attempt in range(_MAX_RETRIES + 1):
        try:
            resp = requests.post(
                f"{config.LLM_BASE_URL.rstrip('/')}/chat/completions",
                headers=headers,
                json=payload,
                timeout=60,
            )
            if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES:
                time.sleep(2**attempt)  # 1s, 2s, 4s
                continue
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            return _parse_json(content)
        except requests.RequestException as e:
            last_error = e
            if attempt < _MAX_RETRIES:
                time.sleep(2**attempt)
                continue
            raise LLMCallFailed(str(e)) from e

    raise LLMCallFailed(str(last_error))


def _parse_json(content: str) -> dict[str, Any]:
    content = content.strip()
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    # best-effort repair: pull out the first {...} block
    start = content.find("{")
    end = content.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(content[start : end + 1])
        except json.JSONDecodeError:
            pass
    raise LLMCallFailed(f"Could not parse JSON from LLM response: {content[:200]!r}")
