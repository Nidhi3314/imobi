"""
Minimal registration/login for both identities in the app -- stdlib only (no
new dependency), so a judge running `pip install -r requirements.txt`
doesn't need anything extra. Passwords are PBKDF2-HMAC-SHA256 with a random
salt; sessions are random tokens stored server-side with an expiry, so a
session can be revoked by deleting its row -- consistent with the rest of
the app's "everything is an inspectable DB record" style.

Two separate identities share this module but never each other's rights:
- AdminUser / AdminSession -- reviewers who decide Conflict Desk tickets
  (see routes_admin.py, routes_conflicts.py). Only reachable from the
  separate Admin Console app.
- User / UserSession -- a regular CompliX visitor's account (see
  routes_user.py, the main app's User Console). Registering here never
  grants Conflict Desk rights.

This is a hackathon-appropriate level of auth: real hashing and real
per-account identity, not a toy, but not hardened for production (no rate
limiting, no password reset flow, no HTTPS enforcement -- out of scope
here).
"""
from __future__ import annotations

import hashlib
import os
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.db.models import AdminSession, AdminUser, User, UserSession

_PBKDF2_ITERATIONS = 200_000
SESSION_LIFETIME = timedelta(hours=12)


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _PBKDF2_ITERATIONS)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password: str, password_hash: str) -> bool:
    try:
        salt_hex, digest_hex = password_hash.split("$")
    except ValueError:
        return False
    salt = bytes.fromhex(salt_hex)
    expected = bytes.fromhex(digest_hex)
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _PBKDF2_ITERATIONS)
    return secrets.compare_digest(actual, expected)


def _is_expired(expires_at: datetime) -> bool:
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at < datetime.now(timezone.utc)


# ---- Admin (reviewer) sessions ----------------------------------------


def create_session(session: Session, admin: AdminUser) -> AdminSession:
    token = secrets.token_urlsafe(32)
    record = AdminSession(token=token, admin_id=admin.id, expires_at=datetime.now(timezone.utc) + SESSION_LIFETIME)
    session.add(record)
    session.commit()
    return record


def get_admin_from_token(session: Session, token: str) -> AdminUser | None:
    record = session.get(AdminSession, token)
    if record is None:
        return None
    if _is_expired(record.expires_at):
        session.delete(record)
        session.commit()
        return None
    return session.get(AdminUser, record.admin_id)


def require_admin(session: Session, authorization: str | None) -> AdminUser:
    """Call from inside a route handler with its own `authorization` header
    param (declared as `authorization: str | None = Header(default=None)`).
    Raises 401 if the request doesn't carry a valid 'Authorization: Bearer
    <token>' header for a logged-in admin."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Sign in as an admin to perform this action.")
    token = authorization.removeprefix("Bearer ").strip()
    admin = get_admin_from_token(session, token)
    if admin is None:
        raise HTTPException(401, "Session expired or invalid -- please sign in again.")
    return admin


# ---- Regular user sessions ---------------------------------------------


def create_user_session(session: Session, user: User) -> UserSession:
    token = secrets.token_urlsafe(32)
    record = UserSession(token=token, user_id=user.id, expires_at=datetime.now(timezone.utc) + SESSION_LIFETIME)
    session.add(record)
    session.commit()
    return record


def get_user_from_token(session: Session, token: str) -> User | None:
    record = session.get(UserSession, token)
    if record is None:
        return None
    if _is_expired(record.expires_at):
        session.delete(record)
        session.commit()
        return None
    return session.get(User, record.user_id)


def require_user(session: Session, authorization: str | None) -> User:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Sign in to perform this action.")
    token = authorization.removeprefix("Bearer ").strip()
    user = get_user_from_token(session, token)
    if user is None:
        raise HTTPException(401, "Session expired or invalid -- please sign in again.")
    return user
