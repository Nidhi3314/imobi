"""
Auditor Agent: an independent second pass that critiques the Evaluation
Agent's output before it's shown to anyone. This is the "reasons about
quality" layer -- it can catch subtler problems (an evidence quote that
technically appears in the text but doesn't actually support the verdict)
that the purely mechanical citation_gate below can't. It sits above the
citation gate, not instead of it: the gate is what makes the "no ungrounded
verdicts" rule non-negotiable even if this agent is wrong or unavailable.
"""
from __future__ import annotations

from app.db.models import DesignDescription, Guardrail
from app.llm import client as llm_client

_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "approved": {"type": "boolean"},
        "audit_note": {"type": "string"},
    },
    "required": ["approved"],
}

_SYSTEM_PROMPT = (
    "You are the Auditor Agent in GuardrailIQ. You are given a verdict the Evaluation "
    "Agent produced (Compliant/Non-compliant/Gap), the evidence quote it cited, the "
    "design text, and the guardrail text. Critique it: does the evidence quote "
    "actually appear in the design text, and does it actually support the verdict "
    "(not overreaching beyond what the design says)? Set approved=false if the "
    "citation is fabricated, doesn't support the verdict, or the verdict overreaches "
    "what the design actually states. Output only the JSON object described by the "
    "schema."
)


def _deterministic_check(design: DesignDescription, verdict: dict) -> tuple[bool, str]:
    quote = (verdict.get("evidence_quote") or "").strip()
    if verdict.get("verdict") == "Gap":
        return True, "Gap verdicts carry no evidence claim, nothing to audit."
    if not quote:
        return False, "Non-Gap verdict with no evidence quote -- cannot audit, rejecting."
    normalized_design = " ".join((design.description or "").split()).lower()
    normalized_quote = " ".join(quote.split()).lower()
    if normalized_quote not in normalized_design:
        return False, "Evidence quote does not appear verbatim in the design text -- likely fabricated."
    return True, "Evidence quote verified present in design text."


def audit(design: DesignDescription, guardrail: Guardrail, verdict: dict) -> dict:
    ok, note = _deterministic_check(design, verdict)
    if not ok:
        return {"approved": False, "audit_note": note}

    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Design text:\n{design.description}\n\n"
                f"Guardrail text:\n{guardrail.statement}\n\n"
                f"Evaluation Agent's verdict: {verdict.get('verdict')}\n"
                f"Evidence quote cited: {verdict.get('evidence_quote')}"
            )
            result = llm_client.complete(_SYSTEM_PROMPT, user_prompt, _JSON_SCHEMA)
            return {
                "approved": bool(result.get("approved", False)),
                "audit_note": result.get("audit_note", ""),
            }
        except Exception:
            pass  # deterministic check already passed; don't block the demo on an LLM hiccup

    return {"approved": True, "audit_note": note}
