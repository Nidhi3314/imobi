"""
Orchestrator: the chat entry point. Routes a natural-language message to
whichever specialist agent/endpoint it needs. Intent routing is simple
rule-based keyword matching for now -- easy to upgrade to an LLM-routed
classifier later behind the same function signature, so nothing downstream
has to change.

Every response carries a `trace`: an ordered list of the actual agent
stages that ran to produce it. This isn't cosmetic instrumentation added
after the fact -- it names the real pipeline stages in report.py /
decision_store.py / retriever.py that the request went through, so the
frontend's agent-workflow view reflects what genuinely happened, not a
fabricated animation.

`reply` is a composed natural-language answer (see chat_composer.py) and
`citations` is built directly from the same structured records the reply
was composed from -- never parsed out of the model's prose. That split is
deliberate: the citations list stays exactly as trustworthy as the
underlying data even if the LLM's wording is loose, because the UI never
has to trust the model to get an ID right.
"""
from __future__ import annotations

import re

from sqlalchemy.orm import Session

from app.agents.chat_composer import compose_evaluate_reply, compose_search_reply
from app.conflicts.decision_store import list_tickets
from app.db.models import DesignDescription, Guardrail
from app.evaluation.report import build_report
from app.knowledge.embeddings import TextSimilarityIndex
from app.llm import client as llm_client

_EVALUATE_RE = re.compile(r"\bevaluate\b|\bcompliance check\b|\bassess\b", re.IGNORECASE)
_CONFLICT_RE = re.compile(r"\bconflicts?\b|\bconflicting\b|\bdisagree\b", re.IGNORECASE)

_MODE_NOTE = (
    "LLM-backed reasoning" if llm_client.is_configured() else "deterministic heuristic fallback (no LLM configured)"
)


def handle_message(session: Session, message: str) -> dict:
    if _CONFLICT_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'conflicts' from the message text."},
            {"agent": "Conflict Agent", "action": "Read open tickets from the Conflict Desk queue."},
        ]
        tickets = list_tickets(session, status="open")
        if not tickets:
            return {"intent": "conflicts", "reply": "No open conflicts right now.", "data": [], "citations": [], "trace": trace}
        citations = []
        for t in tickets:
            citations.append({"guardrail_id": t.guardrail_id_a, "label": f"{t.id} - Side A"})
            citations.append({"guardrail_id": t.guardrail_id_b, "label": f"{t.id} - Side B"})
        return {
            "intent": "conflicts",
            "reply": (
                f"There {'is' if len(tickets) == 1 else 'are'} {len(tickets)} open conflict ticket"
                f"{'' if len(tickets) == 1 else 's'} awaiting a human decision in the Conflict Desk. "
                "Each pits two guardrails against each other on the same requirement -- see the citations below "
                "for both sides."
            ),
            "data": [
                {"id": t.id, "metric": t.metric, "rationale": t.rationale, "status": t.status}
                for t in tickets
            ],
            "citations": citations,
            "trace": trace,
        }

    if _EVALUATE_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'evaluate' from the message text."},
        ]
        designs = session.query(DesignDescription).all()
        if not designs:
            return {"intent": "evaluate", "reply": "No designs are loaded yet.", "data": [], "citations": [], "trace": trace}
        idx = TextSimilarityIndex([d.description for d in designs] + [message])
        sim = idx.pairwise_similarity()
        best_i = max(range(len(designs)), key=lambda i: sim[-1, i])
        design = designs[best_i]
        trace.append({"agent": "Orchestrator", "action": f"Matched the message to design '{design.id}' ({design.title})."})
        trace.append({"agent": "Retriever", "action": "Ranked all guardrails by relevance to this design (domain-boosted similarity)."})
        trace.append({"agent": "Evaluation Agent", "action": f"Produced a verdict per candidate guardrail via {_MODE_NOTE}."})
        trace.append({"agent": "Auditor Agent", "action": "Independently re-checked each verdict's evidence before it could be shown."})
        trace.append({"agent": "Citation Gate", "action": "Verified every citation against the database; rejects are shown as Unverified."})
        report = build_report(session, design.id)
        trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language summary of the findings above."})
        reply = compose_evaluate_reply(design, report["findings"])
        citations = [
            {"guardrail_id": f["guardrail_id"], "clause_id": f["clause_id"], "label": f["verdict"]}
            for f in report["findings"]
            if f["clause_id"]
        ]
        return {
            "intent": "evaluate",
            "reply": reply,
            "data": report,
            "citations": citations,
            "trace": trace,
        }

    trace = [
        {"agent": "Orchestrator", "action": "No 'evaluate' or 'conflict' intent detected -- treated as a guardrail search."},
        {"agent": "Retriever", "action": "Ranked all guardrails by text similarity to the message."},
    ]
    guardrails = session.query(Guardrail).all()
    if not guardrails:
        return {"intent": "search", "reply": "No guardrails are loaded yet.", "data": [], "citations": [], "trace": trace}
    idx = TextSimilarityIndex([g.statement for g in guardrails] + [message])
    sim = idx.pairwise_similarity()[-1][:-1]
    ranked = sorted(zip(guardrails, sim), key=lambda p: p[1], reverse=True)[:5]
    ranked = [(g, s) for g, s in ranked if s > 0]
    trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language summary of the matches above."})
    reply = compose_search_reply(message, ranked)
    citations = [{"guardrail_id": g.id, "label": g.severity} for g, _ in ranked]
    return {
        "intent": "search",
        "reply": reply,
        "data": [
            {"id": g.id, "statement": g.statement, "severity": g.severity, "domain": g.domain, "similarity": round(float(s), 3)}
            for g, s in ranked
        ],
        "citations": citations,
        "trace": trace,
    }
