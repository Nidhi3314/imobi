"""
Evaluation Agent: for one design description and its candidate guardrails,
produce a verdict per guardrail -- Compliant / Non-compliant / Gap -- with a
quoted span of design evidence and the exact clause citation. Explicitly
instructed (LLM path) or hard-coded to default (heuristic path) to return
Gap rather than guess when the design doesn't say enough either way, per the
guide's "no fabricated compliance" rule.

evaluate_batch() makes ONE LLM call per design covering all shortlisted
guardrails, rather than one call per guardrail -- this matters in practice,
not just for cost: an evaluation can easily shortlist 10-30 guardrails, and
per-guardrail calls hit rate limits fast (observed directly against the
Gemini test gateway). Falls back to the heuristic path per-guardrail if the
batch call fails outright.
"""
from __future__ import annotations

import re

from app.db.models import DesignDescription, Guardrail
from app.llm import client as llm_client

_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string", "enum": ["Compliant", "Non-compliant", "Gap"]},
        "evidence_quote": {"type": "string"},
        "plain_language": {"type": "string"},
        "technical_detail": {"type": "string"},
    },
    "required": ["verdict", "plain_language"],
}

_BATCH_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "results": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "guardrail_id": {"type": "string"},
                    "verdict": {"type": "string", "enum": ["Compliant", "Non-compliant", "Gap"]},
                    "evidence_quote": {"type": "string"},
                    "plain_language": {"type": "string"},
                    "technical_detail": {"type": "string"},
                },
                "required": ["guardrail_id", "verdict", "plain_language"],
            },
        },
    },
    "required": ["results"],
}

_SYSTEM_PROMPT = (
    "You are the Evaluation Agent in GuardrailIQ. Given a design description and one "
    "governance guardrail, decide whether the design is Compliant, Non-compliant, or "
    "has a Gap (the design does not say enough to judge either way). NEVER guess -- if "
    "the design is silent on what the guardrail requires, the verdict MUST be 'Gap'. "
    "If you cite evidence, evidence_quote must be an exact substring of the design "
    "text. Output only the JSON object described by the schema."
)

_BATCH_SYSTEM_PROMPT = (
    "You are the Evaluation Agent in GuardrailIQ. Given one design description and a "
    "list of governance guardrails, decide for EACH guardrail whether the design is "
    "Compliant, Non-compliant, or has a Gap (the design does not say enough to judge "
    "either way). NEVER guess -- if the design is silent on what a guardrail requires, "
    "that guardrail's verdict MUST be 'Gap'. If a design merely fails to mention "
    "something (e.g. 'does not state whether X was done'), that is a Gap, NOT "
    "Non-compliant -- Non-compliant requires the design to actively describe doing the "
    "wrong thing. evidence_quote, when given, must be an exact substring of the design "
    "text. Return one result per guardrail_id given, in the same order. Output only "
    "the JSON object described by the schema."
)

_NEGATION_RE = re.compile(r"\b(no|not|without|none|lack of|no\s+access|never)\b", re.IGNORECASE)
_GAP_INDICATOR_RE = re.compile(
    r"\b(does not state|do not state|does not specify|do not specify|not specified|"
    r"unclear whether|unclear if|not sure whether|not sure if|no information on|"
    r"not mentioned|not documented|does not mention|do not mention|whether\s+\w+\s+was)\b",
    re.IGNORECASE,
)
_STOPWORDS = {
    "the", "a", "an", "of", "to", "for", "and", "or", "must", "should", "shall", "be",
    "is", "are", "at", "in", "on", "with", "least", "than", "more", "this", "that",
    "will", "may", "can", "has", "have", "it", "its",
}


def _key_terms(statement: str) -> list[str]:
    words = re.findall(r"[a-zA-Z]+", statement.lower())
    return [w for w in words if w not in _STOPWORDS and len(w) > 3]


def _heuristic_evaluate(design: DesignDescription, guardrail: Guardrail) -> dict:
    design_text = design.description or ""
    design_lower = design_text.lower()
    terms = _key_terms(guardrail.statement)
    if not terms:
        return {
            "verdict": "Gap",
            "evidence_quote": "",
            "plain_language": "Not enough information in the design to check this requirement.",
            "technical_detail": "No extractable key terms from the guardrail statement.",
        }

    hits = [t for t in terms if t in design_lower]
    if not hits:
        return {
            "verdict": "Gap",
            "evidence_quote": "",
            "plain_language": f"The design doesn't mention anything related to '{guardrail.statement[:80]}...' "
            "so we can't confirm either way.",
            "technical_detail": f"No key terms ({', '.join(terms[:5])}) found in design text.",
        }

    # A window with a *gap* indicator ("does not state whether...") means the design is
    # silent on this point -- that's missing information, not an active violation, even
    # though it also contains a generic negation word. Check this before the plain
    # negation check below, which would otherwise misread it as Non-compliant.
    for term in hits:
        for m in re.finditer(re.escape(term), design_lower):
            window_start = max(0, m.start() - 60)
            window_end = min(len(design_lower), m.end() + 30)
            window = design_text[window_start:window_end]
            if _GAP_INDICATOR_RE.search(window):
                return {
                    "verdict": "Gap",
                    "evidence_quote": window.strip(),
                    "plain_language": f"The design doesn't say enough to confirm this: \"{window.strip()}\".",
                    "technical_detail": f"Gap-indicator phrasing found near key term '{term}' -- treated as missing "
                    "information, not a violation.",
                }

    # look for a negation within a small window before/after a hit term -> violation signal
    for term in hits:
        for m in re.finditer(re.escape(term), design_lower):
            window_start = max(0, m.start() - 40)
            window_end = min(len(design_lower), m.end() + 10)
            window = design_text[window_start:window_end]
            if _NEGATION_RE.search(window):
                return {
                    "verdict": "Non-compliant",
                    "evidence_quote": window.strip(),
                    "plain_language": f"The design appears to violate this requirement: \"{window.strip()}\".",
                    "technical_detail": f"Negation pattern found near key term '{term}'.",
                }

    hit_context = next(
        (design_text[max(0, design_text.lower().find(h) - 20) : design_text.lower().find(h) + len(h) + 30] for h in hits),
        hits[0],
    )
    return {
        "verdict": "Compliant",
        "evidence_quote": hit_context.strip(),
        "plain_language": f"The design addresses this requirement: \"{hit_context.strip()}\".",
        "technical_detail": f"Key terms present without a nearby negation: {', '.join(hits[:5])}.",
    }


def evaluate(design: DesignDescription, guardrail: Guardrail) -> dict:
    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Design ({design.id} - {design.title}):\n{design.description}\n\n"
                f"Guardrail ({guardrail.id}, severity {guardrail.severity}):\n{guardrail.statement}\n"
                f"Do: {guardrail.do_instructions}\nDon't: {guardrail.dont_instructions}\n"
                f"Applicability: {guardrail.applicability}"
            )
            result = llm_client.complete(_SYSTEM_PROMPT, user_prompt, _JSON_SCHEMA)
            result.setdefault("evidence_quote", "")
            result.setdefault("technical_detail", "")
            return result
        except Exception:
            return _heuristic_evaluate(design, guardrail)

    return _heuristic_evaluate(design, guardrail)


def evaluate_batch(design: DesignDescription, guardrails: list[Guardrail]) -> dict[str, dict]:
    """Returns {guardrail_id: verdict_dict}. One LLM call for the whole batch when
    configured; per-guardrail heuristic otherwise or on failure."""
    if not guardrails:
        return {}

    if llm_client.is_configured():
        try:
            guardrail_block = "\n\n".join(
                f"guardrail_id: {g.id}\nseverity: {g.severity}\nstatement: {g.statement}\n"
                f"do: {g.do_instructions}\ndont: {g.dont_instructions}\napplicability: {g.applicability}"
                for g in guardrails
            )
            user_prompt = (
                f"Design ({design.id} - {design.title}):\n{design.description}\n\n"
                f"Guardrails to evaluate against ({len(guardrails)} total):\n\n{guardrail_block}"
            )
            result = llm_client.complete(_BATCH_SYSTEM_PROMPT, user_prompt, _BATCH_JSON_SCHEMA)
            by_id = {}
            for item in result.get("results", []):
                gid = item.get("guardrail_id")
                if not gid:
                    continue
                item.setdefault("evidence_quote", "")
                item.setdefault("technical_detail", "")
                by_id[gid] = item
            # any guardrail the model dropped from its response still gets a heuristic verdict
            missing = [g for g in guardrails if g.id not in by_id]
            for g in missing:
                by_id[g.id] = _heuristic_evaluate(design, g)
            return by_id
        except Exception:
            pass

    return {g.id: _heuristic_evaluate(design, g) for g in guardrails}
