"""
Orphan Agent: validates that every GuardrailSource a Guardrail carries
actually resolves to a real Clause/Document row. A broken reference is
flagged (`broken_reference=True`) and excluded from the valid-citation pool
by the citation gate -- it is never presented as a usable citation, only
surfaced separately as a data-quality audit issue.

Runs generically over whatever is in the DB, so it applies equally to
guardrails this system derived itself and to any pre-declared guardrail
records a workbook might otherwise supply.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.db.models import Clause, Document, Guardrail


def run_orphan_check(session: Session) -> list[str]:
    """Returns the list of guardrail IDs flagged as having a broken reference."""
    existing_clause_ids = {c.id for c in session.query(Clause.id).all()}
    existing_document_ids = {d.id for d in session.query(Document.id).all()}

    flagged: list[str] = []
    for guardrail in session.query(Guardrail).all():
        broken = False
        for source in guardrail.sources:
            if source.clause_id not in existing_clause_ids:
                broken = True
            if source.document_id and source.document_id not in existing_document_ids:
                broken = True
        if guardrail.broken_reference != broken:
            guardrail.broken_reference = broken
        if broken:
            flagged.append(guardrail.id)

    session.commit()
    return flagged
