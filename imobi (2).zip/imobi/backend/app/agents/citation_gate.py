"""
The deterministic, non-LLM backstop. No prompt, no model call -- plain code
that cannot be reasoned with. This is what makes "no ungrounded verdicts" an
actual guarantee rather than a hope: even if the Evaluation Agent and the
Auditor Agent both somehow approve a bad finding, this gate still checks the
raw facts against the database directly.

Deliberately built to be trivially demoable: `check_citation` takes a
finding dict, so a demo can hand it a hand-crafted fake citation and watch it
get rejected live.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.db.models import Guardrail


def check_citation(session: Session, guardrail_id: str, clause_id: str | None) -> tuple[bool, str]:
    guardrail = session.get(Guardrail, guardrail_id)
    if guardrail is None:
        return False, f"Cited guardrail '{guardrail_id}' does not exist."
    if guardrail.broken_reference:
        return False, f"Guardrail '{guardrail_id}' has a broken source reference and cannot be cited."
    if clause_id is None:
        return False, "No clause citation provided."
    real_clause_ids = {s.clause_id for s in guardrail.sources}
    if clause_id not in real_clause_ids:
        return False, f"Clause '{clause_id}' is not among guardrail '{guardrail_id}''s real sources {sorted(real_clause_ids)}."
    return True, "Citation verified against the database."


def gate_finding(session: Session, finding: dict) -> dict:
    """Mutates a finding dict in place: on failure, downgrades verdict to
    'Unverified' and records why, regardless of what the agents said."""
    guardrail_id = finding.get("guardrail_id")
    clause_id = finding.get("clause_id")
    ok, reason = check_citation(session, guardrail_id, clause_id)
    finding["citation_gate_passed"] = ok
    finding["citation_gate_reason"] = reason
    if not ok:
        finding["verdict"] = "Unverified"
        finding["status"] = "suppressed"
    else:
        finding.setdefault("status", "shown")
    return finding
