"""
Extraction Agent: Clause -> GuardrailDraft.

Tries the configured LLM gateway first (structured JSON output matching
GuardrailDraft); falls back to a deterministic modal-verb + numeric-value
heuristic when no LLM is configured or the call fails, so the pipeline never
silently produces nothing. Every draft always carries the literal clause and
document ID it came from -- extraction never invents a source.
"""
from __future__ import annotations

import re

from app.agents.schema import GuardrailDraft
from app.db.models import Clause
from app.knowledge.numeric import extract_numeric_requirement
from app.llm import client as llm_client

_GUARDRAIL_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "statement": {"type": "string"},
        "category": {"type": "string"},
        "severity": {"type": "string", "enum": ["Low", "Medium", "High", "Mandatory"]},
        "instruction_type": {"type": "string"},
        "applicability": {"type": "string"},
        "not_applicable": {"type": "string"},
        "do_instructions": {"type": "string"},
        "dont_instructions": {"type": "string"},
        "trigger_conditions": {"type": "string"},
        "plain_language_guidance": {"type": "string"},
    },
    "required": ["statement", "severity"],
}

_SYSTEM_PROMPT = (
    "You are the Extraction Agent in GuardrailIQ, a governance-guardrail platform. "
    "Given one clause of a governance document, produce a single structured guardrail "
    "record: a plain-language requirement statement, its severity (Low/Medium/High/"
    "Mandatory, inferred from modal language like 'must'=Mandatory, 'should'="
    "Recommended/Medium, 'may'=Low), category, applicability, and do/don't guidance. "
    "Never invent a requirement that isn't supported by the clause text. Output only "
    "the JSON object described by the schema."
)

_MANDATORY_WORDS = re.compile(r"\bmust\b|\bshall\b|\brequired\b|\bmandatory\b", re.IGNORECASE)
_RECOMMENDED_WORDS = re.compile(r"\bshould\b|\brecommended\b", re.IGNORECASE)


def _heuristic_extract(clause: Clause) -> GuardrailDraft:
    text = clause.clause_text or ""
    if _MANDATORY_WORDS.search(text):
        severity, instruction_type = "Mandatory", "Mandatory"
    elif _RECOMMENDED_WORDS.search(text):
        severity, instruction_type = "Medium", "Recommended"
    else:
        severity, instruction_type = "Low", "Principle"

    numeric = extract_numeric_requirement(text)

    return GuardrailDraft(
        statement=text.strip(),
        domain=clause.document.domain if clause.document else "Unspecified",
        category=clause.clause_heading,
        severity=severity,
        instruction_type=instruction_type,
        applicability=clause.clause_heading,
        source_clause_id=clause.id,
        source_document_id=clause.document_id,
        normalized_metric_group=numeric["metric_group"] if numeric else None,
        normalized_value=numeric["value"] if numeric else None,
        normalized_raw_value=numeric["raw_value"] if numeric else None,
        normalized_unit=numeric["unit"] if numeric else None,
        normalized_label=numeric["label"] if numeric else None,
        normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
    )


def extract_guardrail(clause: Clause) -> GuardrailDraft:
    domain = clause.document.domain if clause.document else "Unspecified"
    numeric = extract_numeric_requirement(clause.clause_text or "")

    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Clause heading: {clause.clause_heading}\n"
                f"Clause text: {clause.clause_text}\n"
                f"Domain: {domain}"
            )
            result = llm_client.complete(_SYSTEM_PROMPT, user_prompt, _GUARDRAIL_JSON_SCHEMA)
            return GuardrailDraft(
                statement=result.get("statement", clause.clause_text),
                domain=domain,
                category=result.get("category"),
                severity=result.get("severity", "Low"),
                instruction_type=result.get("instruction_type"),
                applicability=result.get("applicability"),
                not_applicable=result.get("not_applicable"),
                do_instructions=result.get("do_instructions"),
                dont_instructions=result.get("dont_instructions"),
                trigger_conditions=result.get("trigger_conditions"),
                plain_language_guidance=result.get("plain_language_guidance"),
                source_clause_id=clause.id,
                source_document_id=clause.document_id,
                normalized_metric_group=numeric["metric_group"] if numeric else None,
                normalized_value=numeric["value"] if numeric else None,
                normalized_raw_value=numeric["raw_value"] if numeric else None,
                normalized_unit=numeric["unit"] if numeric else None,
                normalized_label=numeric["label"] if numeric else None,
                normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
            )
        except Exception:
            return _heuristic_extract(clause)

    return _heuristic_extract(clause)
