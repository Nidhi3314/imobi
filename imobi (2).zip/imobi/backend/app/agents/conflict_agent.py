"""
Conflict Agent (flagship): finds guardrail pairs that are about the same
underlying policy dimension but disagree on a concrete value, reasons about
*why*, computes a best-effort impact analysis against existing designs, and
opens a Conflict Desk ticket -- it never merges or auto-resolves. A human
approves A, approves B, or keeps it open; that decision is the only thing
that ever changes the guardrail model (see conflicts/decision_store.py).

Deliberately runs *globally*, not scoped to one domain: real cross-document
conflicts (e.g. a security policy and a privacy policy both governing log
retention) routinely cross domain boundaries, and scoping to one domain
would structurally miss exactly that case.

Two ways a pair can be flagged, in priority order:
1. Same normalized_metric + normalized_subgroup (a verb-family taxonomy --
   "retain/purge/delete" vs "remediate/respond" vs "rotate/recertify", see
   knowledge/numeric.py) with different values. This is the primary signal:
   it survives clauses that are worded completely differently (e.g. "retained
   for 12 months" vs "purged within 90 days" share almost no vocabulary) as
   long as they use recognizable lifecycle-type verbs -- which is a
   reasonable, generalizable bet for real governance text, not an ID match.
2. Fallback: same normalized_metric group (no subgroup match) but lexical
   topic similarity crosses CONFLICT_TOPIC_SIMILARITY_THRESHOLD -- a lower-
   recall path for numeric requirements the verb taxonomy doesn't cover.
"""
from __future__ import annotations

import json
import re
import uuid

from sqlalchemy.orm import Session

from app.agents.precedent_agent import find_precedent, precedent_note
from app.config import CONFLICT_TOPIC_SIMILARITY_THRESHOLD, DEDUP_SIMILARITY_THRESHOLD
from app.db.models import ConflictTicket, DesignDescription, Document, Guardrail, GuardrailRelationship
from app.knowledge.embeddings import content_word_overlap
from app.knowledge.numeric import extract_numeric_requirement

_MIN_WORD = re.compile(r"\bmin(imum)?\b|\bat least\b", re.IGNORECASE)
_MAX_WORD = re.compile(r"\bmax(imum)?\b|\bretention\b|\bpurge\b|\bno more than\b|\bat most\b", re.IGNORECASE)


def _guess_operator(statement: str) -> str:
    if _MIN_WORD.search(statement):
        return ">="
    if _MAX_WORD.search(statement):
        return "<="
    return "unknown"


def _is_conflict_candidate(ga: Guardrail, gb: Guardrail) -> tuple[bool, float, str]:
    """Returns (is_candidate, topic_similarity, reason)."""
    if not ga.normalized_metric or ga.normalized_value is None:
        return False, 0.0, ""
    if not gb.normalized_metric or gb.normalized_value is None:
        return False, 0.0, ""
    if ga.normalized_metric != gb.normalized_metric:
        return False, 0.0, ""
    if ga.normalized_value == gb.normalized_value:
        return False, 0.0, ""  # same value stated two ways -- not a conflict

    sim = content_word_overlap(ga.statement, gb.statement)

    # Even when the verb-family taxonomy matches, require *some* nonzero shared
    # vocabulary -- this is what tells "12mo key rotation" and "24h incident
    # reporting" (same broad verb family, zero shared content words, unrelated
    # obligations) apart from "12mo log retention" and "90d log purge" (same
    # verb family, low but nonzero shared vocabulary, genuinely the same
    # obligation). Cheap, generic, and empirically a clean separator here.
    if sim <= 0:
        return False, sim, ""

    if ga.normalized_subgroup and ga.normalized_subgroup == gb.normalized_subgroup:
        return True, sim, f"same '{ga.normalized_subgroup}' policy dimension ({ga.normalized_metric})"
    if CONFLICT_TOPIC_SIMILARITY_THRESHOLD <= sim < DEDUP_SIMILARITY_THRESHOLD:
        return True, sim, f"lexical topic overlap ({ga.normalized_metric})"
    return False, sim, ""


def _impact_analysis(session: Session, guardrail_a: Guardrail, guardrail_b: Guardrail) -> dict:
    """Best-effort: which designs mention a comparable number, and would they
    read as compliant under A's value vs B's value. Operator is a heuristic
    guess from wording, so results are explicitly labeled as such rather than
    presented as a certain verdict (never overstate confidence)."""
    operator = _guess_operator(guardrail_a.statement) or _guess_operator(guardrail_b.statement)
    metric_group = guardrail_a.normalized_metric
    designs = session.query(DesignDescription).all()
    affected = []
    for design in designs:
        numeric = extract_numeric_requirement(design.description or "")
        if not numeric or numeric["metric_group"] != metric_group:
            continue
        value = numeric["value"]

        def compliant(threshold: float) -> str:
            if operator == ">=":
                return "compliant" if value >= threshold else "non_compliant"
            if operator == "<=":
                return "compliant" if value <= threshold else "non_compliant"
            return "ambiguous"

        under_a = compliant(guardrail_a.normalized_value)
        under_b = compliant(guardrail_b.normalized_value)
        if under_a != under_b:
            affected.append(
                {
                    "design_id": design.id,
                    "design_title": design.title,
                    "observed_value": value,
                    "verdict_under_a": under_a,
                    "verdict_under_b": under_b,
                }
            )
    return {
        "operator_guessed": operator,
        "note": "Operator direction is inferred from wording (min/max/retention/purge) and is a "
        "heuristic, not a certainty -- shown to reviewers as such.",
        "designs_that_flip": affected,
    }


def _existing_ticket(session: Session, id_a: str, id_b: str) -> ConflictTicket | None:
    return (
        session.query(ConflictTicket)
        .filter(
            ((ConflictTicket.guardrail_id_a == id_a) & (ConflictTicket.guardrail_id_b == id_b))
            | ((ConflictTicket.guardrail_id_a == id_b) & (ConflictTicket.guardrail_id_b == id_a))
        )
        .first()
    )


def run_conflict_detection(session: Session) -> list[ConflictTicket]:
    guardrails = session.query(Guardrail).filter(Guardrail.broken_reference == False).all()  # noqa: E712

    created: list[ConflictTicket] = []
    for i in range(len(guardrails)):
        for j in range(i + 1, len(guardrails)):
            ga, gb = guardrails[i], guardrails[j]
            is_candidate, sim, reason = _is_conflict_candidate(ga, gb)
            if not is_candidate:
                continue
            if _existing_ticket(session, ga.id, gb.id):
                continue

            doc_a = session.get(Document, ga.sources[0].document_id) if ga.sources else None
            doc_b = session.get(Document, gb.sources[0].document_id) if gb.sources else None

            display_a = f"{ga.normalized_raw_value:g} {ga.normalized_unit}" if ga.normalized_raw_value is not None else f"{ga.normalized_value:g}"
            display_b = f"{gb.normalized_raw_value:g} {gb.normalized_unit}" if gb.normalized_raw_value is not None else f"{gb.normalized_value:g}"
            rationale_parts = [
                f"Guardrails '{ga.id}' ({ga.domain}) and '{gb.id}' ({gb.domain}) both concern {reason} "
                f"but state different values: {display_a} vs {display_b}.",
            ]
            if doc_a and doc_b and doc_a.effective_date and doc_b.effective_date:
                newer = doc_a if str(doc_a.effective_date) > str(doc_b.effective_date) else doc_b
                rationale_parts.append(
                    f"'{newer.title}' (v{newer.version}, effective {newer.effective_date}) is the more "
                    f"recently effective source -- a possible but NOT automatic tie-breaker."
                )
            # Learning step: has a human already resolved a structurally similar
            # conflict before? If so, surface it as context -- never applied
            # automatically, but this is what makes each Conflict Desk decision
            # actually change future behavior instead of the agent re-deriving
            # the same reasoning from scratch every time.
            precedent = find_precedent(session, ga.normalized_metric)
            if precedent:
                rationale_parts.append(precedent_note(precedent))
                recommendation = (
                    f"No automatic resolution -- a similar prior decision ({precedent.id}, "
                    f"{precedent.status.replace('_', ' ')}) is offered as context below; a human reviewer "
                    "still decides this ticket independently."
                )
            else:
                recommendation = "No automatic resolution -- recommend the more restrictive value pending human review."

            rationale = " ".join(rationale_parts)

            impact = _impact_analysis(session, ga, gb)

            ticket = ConflictTicket(
                id=f"CFT-{uuid.uuid4().hex[:8]}",
                guardrail_id_a=ga.id,
                guardrail_id_b=gb.id,
                metric=ga.normalized_metric,
                rationale=rationale,
                recommended_resolution=recommendation,
                impact_analysis=json.dumps(impact),
                status="open",
            )
            session.add(ticket)
            session.add(
                GuardrailRelationship(
                    guardrail_id_a=ga.id,
                    guardrail_id_b=gb.id,
                    relationship_type="conflicts_with",
                    rationale=rationale,
                )
            )
            created.append(ticket)

    session.commit()
    return created
