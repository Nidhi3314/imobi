"""
Writes the chat answer as a short, natural-language response instead of a
bare list of records -- while keeping citations completely separate and
deterministic. The LLM (when configured) never has to get a guardrail or
clause ID right for the UI to stay trustworthy: `compose_*` only produces
the prose `reply`; the caller (orchestrator.py) builds the `citations` list
directly from the same structured data, so a loose sentence from the model
can never invent or drop a source reference the citation gate hasn't
already verified.
"""
from __future__ import annotations

from app.db.models import DesignDescription
from app.llm import client as llm_client

_SEARCH_SYSTEM_PROMPT = (
    "You are the GuardrailIQ chat assistant. Write a short (2-4 sentence) natural-language "
    "answer to the user's question, using ONLY the guardrail matches given to you as facts. "
    "Do not invent guardrails, IDs, or details not present in the data. Do not include "
    "guardrail IDs in your prose -- citations are shown separately in the UI. Plain text only."
)

_EVALUATE_SYSTEM_PROMPT = (
    "You are the GuardrailIQ chat assistant. Write a short (3-5 sentence) natural-language "
    "summary of this design's compliance evaluation, using ONLY the findings given to you. "
    "Mention how many findings are Non-compliant, Gap, and Compliant, and call out the most "
    "severe issue if there is a Non-compliant Mandatory/High finding. Never state a finding "
    "that isn't in the data. Do not include guardrail IDs in your prose -- citations are shown "
    "separately in the UI. Plain text only."
)


def _fallback_search_reply(message: str, ranked: list[tuple]) -> str:
    if not ranked:
        return f"I couldn't find any guardrails relevant to \"{message}\"."
    top = ranked[0][0]
    return (
        f"I found {len(ranked)} guardrail{'s' if len(ranked) != 1 else ''} relevant to \"{message}\". "
        f"The closest match is a {top.severity.lower()}-severity requirement in {top.domain}: "
        f"\"{top.statement}\" See the citations below for the exact source clauses."
    )


def compose_search_reply(message: str, ranked: list[tuple]) -> str:
    if llm_client.is_configured() and ranked:
        try:
            facts = "\n".join(
                f"- [{g.severity}] ({g.domain}) {g.statement}" for g, _ in ranked
            )
            user_prompt = f"User asked: \"{message}\"\n\nMatching guardrails:\n{facts}"
            result = llm_client.complete(
                _SEARCH_SYSTEM_PROMPT,
                user_prompt,
                {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]},
            )
            answer = result.get("answer", "").strip()
            if answer:
                return answer
        except Exception:
            pass
    return _fallback_search_reply(message, ranked)


def _fallback_evaluate_reply(design: DesignDescription, findings: list[dict]) -> str:
    non_compliant = [f for f in findings if f["verdict"] == "Non-compliant"]
    gaps = [f for f in findings if f["verdict"] == "Gap"]
    compliant = [f for f in findings if f["verdict"] == "Compliant"]
    parts = [f"I evaluated '{design.title}' ({design.id}) against {len(findings)} relevant guardrails."]
    if non_compliant:
        worst = max(non_compliant, key=lambda f: {"Mandatory": 3, "High": 2, "Medium": 1, "Low": 0}.get(f["severity"], 0))
        parts.append(
            f"{len(non_compliant)} finding{'s' if len(non_compliant) != 1 else ''} came back Non-compliant -- "
            f"most seriously: {worst['plain_language']}"
        )
    if gaps:
        parts.append(f"{len(gaps)} guardrail{'s' if len(gaps) != 1 else ''} couldn't be confirmed either way (Gap).")
    if compliant:
        parts.append(f"{len(compliant)} guardrail{'s' if len(compliant) != 1 else ''} were satisfied.")
    parts.append("See the citations below for the exact source clauses behind each finding.")
    return " ".join(parts)


def compose_evaluate_reply(design: DesignDescription, findings: list[dict]) -> str:
    if llm_client.is_configured() and findings:
        try:
            facts = "\n".join(
                f"- [{f['verdict']}, {f['severity']}] {f['plain_language']}" for f in findings
            )
            user_prompt = f"Design: {design.title}\n\nFindings:\n{facts}"
            result = llm_client.complete(
                _EVALUATE_SYSTEM_PROMPT,
                user_prompt,
                {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]},
            )
            answer = result.get("answer", "").strip()
            if answer:
                return answer
        except Exception:
            pass
    return _fallback_evaluate_reply(design, findings)
