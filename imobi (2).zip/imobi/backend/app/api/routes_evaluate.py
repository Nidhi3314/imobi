from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.db.models import DesignDescription
from app.db.session import get_session
from app.evaluation.report import build_report

router = APIRouter(prefix="/evaluate", tags=["evaluate"])


class EvaluateTextRequest(BaseModel):
    design_id: str | None = None  # if provided, evaluates a stored design (demo convenience)
    title: str | None = None
    domain: str
    description: str


@router.get("/designs")
def list_designs():
    session = get_session()
    try:
        rows = session.query(DesignDescription).all()
        return [
            {"id": d.id, "title": d.title, "domain": d.domain, "expected_outcome": d.expected_outcome}
            for d in rows
        ]
    finally:
        session.close()


@router.post("")
def evaluate_text(req: EvaluateTextRequest):
    session = get_session()
    try:
        if req.design_id:
            design = session.get(DesignDescription, req.design_id)
            if design is None:
                raise HTTPException(404, f"No design '{req.design_id}'")
        else:
            design = DesignDescription(
                id="__adhoc__",
                title=req.title or "Ad-hoc design",
                domain=req.domain,
                description=req.description,
            )
            session.merge(design)
            session.commit()
        return build_report(session, design.id)
    finally:
        session.close()


@router.get("/{design_id}")
def evaluate_stored_design(design_id: str):
    session = get_session()
    try:
        return build_report(session, design_id)
    except LookupError as e:
        raise HTTPException(404, str(e))
    finally:
        session.close()
