"""
Aggregate stats for the dashboard view. Read-only, computed fresh from the
DB every call -- nothing cached, so it always reflects the current model
(including after a Judge Mode re-ingest or a Conflict Desk decision).
"""
from __future__ import annotations

from collections import Counter

from fastapi import APIRouter

from app.conflicts.decision_store import list_tickets
from app.db.models import Clause, DesignDescription, Document, Guardrail
from app.db.session import get_session

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
def summary():
    session = get_session()
    try:
        guardrails = session.query(Guardrail).all()
        by_domain = Counter(g.domain for g in guardrails)
        by_severity = Counter(g.severity for g in guardrails)
        duplicates = sum(1 for g in guardrails if g.merged_from)
        broken = sum(1 for g in guardrails if g.broken_reference)

        tickets = list_tickets(session)
        open_tickets = [t for t in tickets if t.status == "open"]
        decided_tickets = [t for t in tickets if t.status != "open"]

        return {
            "documents": session.query(Document).count(),
            "clauses": session.query(Clause).count(),
            "designs": session.query(DesignDescription).count(),
            "guardrails_total": len(guardrails),
            "guardrails_by_domain": dict(by_domain),
            "guardrails_by_severity": dict(by_severity),
            "duplicates_merged": duplicates,
            "broken_references": broken,
            "conflicts_open": len(open_tickets),
            "conflicts_decided": len(decided_tickets),
        }
    finally:
        session.close()
