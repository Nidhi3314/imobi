from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel

from app.agents.orchestrator import handle_message
from app.db.session import get_session

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str


@router.post("")
def chat(req: ChatRequest):
    session = get_session()
    try:
        return handle_message(session, req.message)
    finally:
        session.close()
