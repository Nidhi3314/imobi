from __future__ import annotations

from fastapi import APIRouter, HTTPException

from app.db.session import get_session
from app.db.models import Guardrail

router = APIRouter(prefix="/guardrails", tags=["guardrails"])


def _serialize(g: Guardrail) -> dict:
    return {
        "id": g.id,
        "domain": g.domain,
        "category": g.category,
        "statement": g.statement,
        "severity": g.severity,
        "instruction_type": g.instruction_type,
        "applicability": g.applicability,
        "not_applicable": g.not_applicable,
        "do_instructions": g.do_instructions,
        "dont_instructions": g.dont_instructions,
        "trigger_conditions": g.trigger_conditions,
        "plain_language_guidance": g.plain_language_guidance,
        "broken_reference": g.broken_reference,
        "merged_from": g.merged_from.split(",") if g.merged_from else [],
        "is_duplicate_merge": bool(g.merged_from),
        "sources": [{"clause_id": s.clause_id, "document_id": s.document_id} for s in g.sources],
    }


@router.get("")
def list_guardrails(domain: str | None = None, severity: str | None = None, q: str | None = None):
    session = get_session()
    try:
        query = session.query(Guardrail)
        if domain:
            query = query.filter(Guardrail.domain == domain)
        if severity:
            query = query.filter(Guardrail.severity == severity)
        guardrails = query.all()
        if q:
            ql = q.lower()
            guardrails = [g for g in guardrails if ql in (g.statement or "").lower()]
        return [_serialize(g) for g in guardrails]
    finally:
        session.close()


@router.get("/domains")
def list_domains():
    session = get_session()
    try:
        rows = session.query(Guardrail.domain).distinct().all()
        return sorted({r[0] for r in rows})
    finally:
        session.close()


@router.get("/{guardrail_id}")
def get_guardrail(guardrail_id: str):
    session = get_session()
    try:
        g = session.get(Guardrail, guardrail_id)
        if g is None:
            raise HTTPException(404, f"No guardrail '{guardrail_id}'")
        return _serialize(g)
    finally:
        session.close()
