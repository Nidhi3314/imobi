from __future__ import annotations

import json

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from app import auth
from app.conflicts.decision_store import decide, list_tickets
from app.db.models import Guardrail
from app.db.session import get_session

router = APIRouter(prefix="/conflicts", tags=["conflicts"])


def _serialize(ticket, session) -> dict:
    ga = session.get(Guardrail, ticket.guardrail_id_a)
    gb = session.get(Guardrail, ticket.guardrail_id_b)
    return {
        "id": ticket.id,
        "metric": ticket.metric,
        "rationale": ticket.rationale,
        "recommended_resolution": ticket.recommended_resolution,
        "impact_analysis": json.loads(ticket.impact_analysis) if ticket.impact_analysis else None,
        "status": ticket.status,
        "decided_by": ticket.decided_by,
        "decided_at": ticket.decided_at.isoformat() if ticket.decided_at else None,
        "guardrail_a": {"id": ga.id, "statement": ga.statement, "value": ga.normalized_value} if ga else None,
        "guardrail_b": {"id": gb.id, "statement": gb.statement, "value": gb.normalized_value} if gb else None,
    }


class DecisionRequest(BaseModel):
    decision: str  # approved_a | approved_b | kept_open


@router.get("")
def get_tickets(status: str | None = None):
    session = get_session()
    try:
        return [_serialize(t, session) for t in list_tickets(session, status)]
    finally:
        session.close()


@router.post("/{ticket_id}/decision")
def post_decision(ticket_id: str, req: DecisionRequest, authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        ticket = decide(session, ticket_id, req.decision, admin.username)
        return _serialize(ticket, session)
    except LookupError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        session.close()
