"""
Registration/login for a regular CompliX visitor -- the User Console
identity. Deliberately separate from /admin: registering here never grants
Conflict Desk decision rights (see auth.py's module docstring)."""
from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException

from app import auth
from app.api.auth_schemas import LoginRequest, RegisterRequest
from app.db.models import User, UserSession
from app.db.session import get_session

router = APIRouter(prefix="/user", tags=["user"])


def _serialize_user(user: User) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "display_name": user.display_name,
    }


@router.post("/register")
def register(req: RegisterRequest):
    session = get_session()
    try:
        if session.query(User).filter(User.username == req.username).first():
            raise HTTPException(409, "That username is already taken.")
        if session.query(User).filter(User.email == req.email).first():
            raise HTTPException(409, "That email is already registered.")

        user = User(
            username=req.username,
            email=req.email,
            password_hash=auth.hash_password(req.password),
            display_name=req.display_name or req.username,
        )
        session.add(user)
        session.commit()

        record = auth.create_user_session(session, user)
        return {"token": record.token, "user": _serialize_user(user)}
    finally:
        session.close()


@router.post("/login")
def login(req: LoginRequest):
    session = get_session()
    try:
        user = session.query(User).filter(User.username == req.username).first()
        if user is None or not auth.verify_password(req.password, user.password_hash):
            raise HTTPException(401, "Incorrect username or password.")
        record = auth.create_user_session(session, user)
        return {"token": record.token, "user": _serialize_user(user)}
    finally:
        session.close()


@router.post("/logout")
def logout(authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        if authorization and authorization.startswith("Bearer "):
            token = authorization.removeprefix("Bearer ").strip()
            existing = session.get(UserSession, token)
            if existing:
                session.delete(existing)
                session.commit()
        return {"ok": True}
    finally:
        session.close()


@router.get("/me")
def me(authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        user = auth.require_user(session, authorization)
        return _serialize_user(user)
    finally:
        session.close()
