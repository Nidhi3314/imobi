from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException

from app import auth
from app.api.auth_schemas import LoginRequest, RegisterRequest
from app.db.models import AdminSession, AdminUser
from app.db.session import get_session

router = APIRouter(prefix="/admin", tags=["admin"])


def _serialize_admin(admin: AdminUser) -> dict:
    return {
        "id": admin.id,
        "username": admin.username,
        "email": admin.email,
        "display_name": admin.display_name,
    }


@router.post("/register")
def register(req: RegisterRequest):
    session = get_session()
    try:
        if session.query(AdminUser).filter(AdminUser.username == req.username).first():
            raise HTTPException(409, "That username is already taken.")
        if session.query(AdminUser).filter(AdminUser.email == req.email).first():
            raise HTTPException(409, "That email is already registered.")

        admin = AdminUser(
            username=req.username,
            email=req.email,
            password_hash=auth.hash_password(req.password),
            display_name=req.display_name or req.username,
        )
        session.add(admin)
        session.commit()

        record = auth.create_session(session, admin)
        return {"token": record.token, "admin": _serialize_admin(admin)}
    finally:
        session.close()


@router.post("/login")
def login(req: LoginRequest):
    session = get_session()
    try:
        admin = session.query(AdminUser).filter(AdminUser.username == req.username).first()
        if admin is None or not auth.verify_password(req.password, admin.password_hash):
            raise HTTPException(401, "Incorrect username or password.")
        record = auth.create_session(session, admin)
        return {"token": record.token, "admin": _serialize_admin(admin)}
    finally:
        session.close()


@router.post("/logout")
def logout(authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        if authorization and authorization.startswith("Bearer "):
            token = authorization.removeprefix("Bearer ").strip()
            existing = session.get(AdminSession, token)
            if existing:
                session.delete(existing)
                session.commit()
        return {"ok": True}
    finally:
        session.close()


@router.get("/me")
def me(authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        return _serialize_admin(admin)
    finally:
        session.close()
