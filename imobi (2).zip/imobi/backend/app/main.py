from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    routes_admin,
    routes_clauses,
    routes_conflicts,
    routes_dashboard,
    routes_debug,
    routes_evaluate,
    routes_guardrails,
    routes_ingest,
    routes_chat,
    routes_user,
)
from app.config import DEFAULT_DATASET_PATH
from app.db.session import get_session, init_db
from app.pipeline import run_full_pipeline

logger = logging.getLogger("guardrailiq")

app = FastAPI(title="CompliX", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_guardrails.router)
app.include_router(routes_evaluate.router)
app.include_router(routes_conflicts.router)
app.include_router(routes_ingest.router)
app.include_router(routes_chat.router)
app.include_router(routes_debug.router)
app.include_router(routes_admin.router)
app.include_router(routes_dashboard.router)
app.include_router(routes_clauses.router)
app.include_router(routes_user.router)


@app.on_event("startup")
def startup():
    init_db()
    session = get_session()
    try:
        result = run_full_pipeline(session, DEFAULT_DATASET_PATH)
        logger.info("Startup ingestion of default dataset: %s", result)
    except Exception:
        logger.exception("Startup ingestion failed -- the app will still serve, but /guardrails may be empty.")
    finally:
        session.close()


@app.get("/health")
def health():
    return {"status": "ok"}
