"""
Retrieves candidate guardrails for a design description, and -- for the
"negative-space transparency" differentiator -- keeps the full considered
list with an explicit reason for every guardrail that was ruled out, not
just the final shortlist.

Domain is a *soft* signal (a similarity boost), not a hard filter: a real
design's self-declared domain label ("Third-Party Security") often won't
exactly match a governance document's domain taxonomy ("Information
Security"), and a hard domain gate would silently return zero candidates
for such a design instead of a real Gap-worthy evaluation -- exactly the
"detect by meaning, not by exact field match" failure mode the guide warns
against. Relevance ranking runs across the whole guardrail set; matching
domain guardrails just get a boost, and Mandatory/High guardrails are only
force-included when they're already reasonably relevant, not dumped in
regardless of topic.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from sqlalchemy.orm import Session

from app.config import RETRIEVAL_TOP_K
from app.db.models import DesignDescription, Guardrail
from app.knowledge.embeddings import TextSimilarityIndex

_DOMAIN_MATCH_BOOST = 0.15
_MANDATORY_FORCE_MIN_SIMILARITY = 0.05


@dataclass
class ConsideredGuardrail:
    guardrail: Guardrail
    similarity: float
    kept: bool
    reason: str


@dataclass
class RetrievalResult:
    shortlist: list[ConsideredGuardrail] = field(default_factory=list)
    rejected: list[ConsideredGuardrail] = field(default_factory=list)

    @property
    def considered_count(self) -> int:
        return len(self.shortlist) + len(self.rejected)


def retrieve_candidates(session: Session, design: DesignDescription) -> RetrievalResult:
    all_guardrails = session.query(Guardrail).filter(Guardrail.broken_reference == False).all()  # noqa: E712
    if not all_guardrails:
        return RetrievalResult()

    corpus_texts = [f"{g.statement} {g.applicability or ''} {g.trigger_conditions or ''}" for g in all_guardrails]
    idx = TextSimilarityIndex(corpus_texts)
    raw_sims = idx.similarity_to_corpus(design.description or "")

    domain_match = [g.domain == design.domain for g in all_guardrails]
    boosted = [float(raw_sims[i]) + (_DOMAIN_MATCH_BOOST if domain_match[i] else 0.0) for i in range(len(all_guardrails))]

    ranked = sorted(range(len(all_guardrails)), key=lambda i: boosted[i], reverse=True)
    top_k_set = set(ranked[:RETRIEVAL_TOP_K])

    mandatory_forced = {
        i
        for i, g in enumerate(all_guardrails)
        if g.severity in ("Mandatory", "High") and domain_match[i] and float(raw_sims[i]) >= _MANDATORY_FORCE_MIN_SIMILARITY
    }
    keep_set = top_k_set | mandatory_forced

    result = RetrievalResult()
    for i, g in enumerate(all_guardrails):
        sim = float(raw_sims[i])
        domain_note = "domain match" if domain_match[i] else f"domain mismatch (guardrail domain: {g.domain})"
        if i in keep_set:
            reason = (
                "mandatory/high severity in a relevant area, always included"
                if i in mandatory_forced and i not in top_k_set
                else f"top relevance match ({domain_note})"
            )
            result.shortlist.append(ConsideredGuardrail(g, sim, True, reason))
        else:
            result.rejected.append(
                ConsideredGuardrail(g, sim, False, f"below relevance threshold for this design ({domain_note})")
            )

    result.shortlist.sort(key=lambda c: c.similarity, reverse=True)
    return result
