"""
Human decisions on Conflict Desk tickets. Deliberately non-destructive: a
decision only changes the ticket's own status/decided_by/decided_at fields.
Neither guardrail's statement, sources, or values are ever edited or
deleted -- the ticket itself is the permanent, inspectable record of "the
Conflict Agent recommended X, a human chose Y, on this date." This is the
concrete form of the guide's "recommend, don't enforce" rule: the platform
never silently rewrites the guardrail model on anyone's behalf.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.db.models import ConflictTicket

_VALID_DECISIONS = {"approved_a", "approved_b", "kept_open"}


def list_tickets(session: Session, status: str | None = None) -> list[ConflictTicket]:
    q = session.query(ConflictTicket)
    if status:
        q = q.filter(ConflictTicket.status == status)
    return q.order_by(ConflictTicket.created_at.desc()).all()


def decide(session: Session, ticket_id: str, decision: str, decided_by: str) -> ConflictTicket:
    if decision not in _VALID_DECISIONS:
        raise ValueError(f"Invalid decision '{decision}'; must be one of {_VALID_DECISIONS}")

    ticket = session.get(ConflictTicket, ticket_id)
    if ticket is None:
        raise LookupError(f"No conflict ticket '{ticket_id}'")

    ticket.status = decision
    ticket.decided_by = decided_by
    ticket.decided_at = datetime.now(timezone.utc)
    session.commit()
    return ticket
