import { useEffect, useState } from "react";
import { LogOut, Moon, ShieldCheck, Sun, UserRound } from "lucide-react";
import "./App.scss";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import { AdminAuth } from "./components/AdminAuth";
import { AdminConflictDesk } from "./components/AdminConflictDesk";
import { api, type DashboardSummary } from "./api/client";
import { useTheme } from "./theme";

function StatStrip() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);

  useEffect(() => {
    api.dashboardSummary().then(setSummary).catch(() => {});
  }, []);

  if (!summary) return null;

  return (
    <div className="stat-strip">
      <div className="stat-strip-item">
        <span className="stat-strip-value">{summary.guardrails_total}</span>
        <span className="stat-strip-label">Guardrails</span>
      </div>
      <div className={`stat-strip-item ${summary.conflicts_open > 0 ? "stat-strip-alert" : ""}`}>
        <span className="stat-strip-value">{summary.conflicts_open}</span>
        <span className="stat-strip-label">Open conflicts</span>
      </div>
      <div className="stat-strip-item">
        <span className="stat-strip-value">{summary.conflicts_decided}</span>
        <span className="stat-strip-label">Decided</span>
      </div>
      <div className={`stat-strip-item ${summary.broken_references > 0 ? "stat-strip-alert" : ""}`}>
        <span className="stat-strip-value">{summary.broken_references}</span>
        <span className="stat-strip-label">Broken refs</span>
      </div>
    </div>
  );
}

function ConsoleShell() {
  const { admin, loading, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const isDark = theme === "dark" || (theme === "system" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);

  if (loading) {
    return <div className="admin-loading">Loading…</div>;
  }

  if (!admin) {
    return <AdminAuth />;
  }

  return (
    <div className="admin-shell">
      <header className="admin-navbar">
        <div className="admin-navbar-brand">
          <ShieldCheck size={22} /> CompliX Admin Console
        </div>
        <div className="admin-navbar-spacer" />
        <button className="theme-toggle" onClick={toggle} aria-label="Toggle dark mode" title="Toggle dark mode">
          {isDark ? <Sun size={15} /> : <Moon size={15} />}
        </button>
        <div className="admin-navbar-account">
          <span className="admin-navbar-name">
            <UserRound size={16} /> {admin.display_name || admin.username}
          </span>
          <button className="admin-navbar-signout" onClick={logout}>
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </header>
      <main className="admin-main">
        <StatStrip />
        <AdminConflictDesk />
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ConsoleShell />
    </AuthProvider>
  );
}

export default App;
