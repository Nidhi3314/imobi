const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";
const TOKEN_STORAGE_KEY = "guardrailiq_admin_token";

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_STORAGE_KEY, token);
    else localStorage.removeItem(TOKEN_STORAGE_KEY);
  } catch {
    // ignore storage failures -- session just won't persist
  }
}

async function request<T>(path: string, options?: RequestInit, authed = false): Promise<T> {
  const headers: HeadersInit = { "Content-Type": "application/json", ...(options?.headers ?? {}) };
  if (authed) {
    const token = getStoredToken();
    if (token) (headers as Record<string, string>)["Authorization"] = `Bearer ${token}`;
  }
  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    let message = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (body?.detail) message = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      // response wasn't JSON -- keep the status-line message
    }
    throw new Error(message);
  }
  return res.json();
}

export interface AdminInfo {
  id: number;
  username: string;
  email: string;
  display_name: string | null;
}

export interface ConflictTicket {
  id: string;
  metric: string;
  rationale: string;
  recommended_resolution: string;
  impact_analysis: {
    operator_guessed: string;
    note: string;
    designs_that_flip: { design_id: string; design_title: string; observed_value: number; verdict_under_a: string; verdict_under_b: string }[];
  } | null;
  status: string;
  decided_by: string | null;
  decided_at: string | null;
  guardrail_a: { id: string; statement: string; value: number | null } | null;
  guardrail_b: { id: string; statement: string; value: number | null } | null;
}

export interface DashboardSummary {
  documents: number;
  clauses: number;
  designs: number;
  guardrails_total: number;
  guardrails_by_domain: Record<string, number>;
  guardrails_by_severity: Record<string, number>;
  duplicates_merged: number;
  broken_references: number;
  conflicts_open: number;
  conflicts_decided: number;
}

export const api = {
  register: (body: { username: string; email: string; password: string; display_name?: string }) =>
    request<{ token: string; admin: AdminInfo }>("/admin/register", { method: "POST", body: JSON.stringify(body) }),
  login: (body: { username: string; password: string }) =>
    request<{ token: string; admin: AdminInfo }>("/admin/login", { method: "POST", body: JSON.stringify(body) }),
  logout: () => request<{ ok: boolean }>("/admin/logout", { method: "POST" }, true),
  me: () => request<AdminInfo>("/admin/me", undefined, true),

  listConflicts: (status?: string) => request<ConflictTicket[]>(`/conflicts${status ? `?status=${status}` : ""}`, undefined, true),
  decideConflict: (ticketId: string, decision: string) =>
    request<ConflictTicket>(`/conflicts/${ticketId}/decision`, { method: "POST", body: JSON.stringify({ decision }) }, true),

  dashboardSummary: () => request<DashboardSummary>("/dashboard/summary"),
};
