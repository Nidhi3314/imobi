import { useState } from "react";
import {
  LayoutDashboard,
  MessageCircle,
  BookOpen,
  Scale,
  ClipboardList,
  FlaskConical,
  ShieldCheck,
  ChevronsLeft,
  ChevronsRight,
  Sun,
  Moon,
} from "lucide-react";
import "./App.scss";
import { ChatPanel } from "./components/ChatPanel";
import { GuardrailExplorer } from "./components/GuardrailExplorer";
import { ConflictDesk } from "./components/ConflictDesk";
import { EvaluationReportView } from "./components/EvaluationReportView";
import { JudgeMode } from "./components/JudgeMode";
import { Dashboard } from "./components/Dashboard";
import { UserAuthProvider } from "./auth/UserAuthContext";
import { UserConsoleButton, UserConsolePanel } from "./components/UserConsole";
import { useTheme } from "./theme";

type View = "dashboard" | "chat" | "guardrails" | "conflicts" | "evaluate" | "judge-mode";

const NAV_ITEMS: { key: View; label: string; Icon: typeof LayoutDashboard }[] = [
  { key: "dashboard", label: "Dashboard", Icon: LayoutDashboard },
  { key: "chat", label: "Chat", Icon: MessageCircle },
  { key: "guardrails", label: "Guardrail Explorer", Icon: BookOpen },
  { key: "conflicts", label: "Conflict Desk", Icon: Scale },
  { key: "evaluate", label: "Evaluation Report", Icon: ClipboardList },
  { key: "judge-mode", label: "Judge Mode", Icon: FlaskConical },
];

function AppShell() {
  const [view, setView] = useState<View>("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [userConsoleOpen, setUserConsoleOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const isDark = theme === "dark" || (theme === "system" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);

  return (
    <div className="app-shell">
      <header className="navbar">
        <div className="navbar-identity">
          <span className="navbar-brand">
            <ShieldCheck size={22} /> CompliX
          </span>
          <span className="navbar-tagline">Enterprise Guardrails Intelligence Platform</span>
        </div>
        <div className="navbar-spacer" />
        <div className="navbar-actions">
          <button className="theme-toggle" onClick={toggle} aria-label="Toggle dark mode" title="Toggle dark mode">
            {isDark ? <Sun size={15} /> : <Moon size={15} />}
          </button>
          <UserConsoleButton onToggleOpen={() => setUserConsoleOpen((o) => !o)} />
        </div>
        <UserConsolePanel open={userConsoleOpen} onClose={() => setUserConsoleOpen(false)} />
      </header>
      <div className="app-body">
        <nav className={`sidenav ${collapsed ? "collapsed" : ""}`}>
          <button className="sidenav-toggle" onClick={() => setCollapsed((c) => !c)} aria-label="Toggle navigation">
            {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
          </button>
          {NAV_ITEMS.map((item) => (
            <button
              key={item.key}
              className={`sidenav-item ${view === item.key ? "active" : ""}`}
              onClick={() => setView(item.key)}
            >
              <span className="sidenav-icon">
                <item.Icon size={18} />
              </span>
              {!collapsed && <span className="sidenav-label">{item.label}</span>}
            </button>
          ))}
          <div className="sidenav-spacer" />
          <div className="sidenav-footer">
            {!collapsed && (
              <span className="sidenav-footer-text">
                Conflict decisions are made by a signed-in reviewer in the Admin Console.
              </span>
            )}
          </div>
        </nav>
        <main className="main-pane">
          {view === "dashboard" && <Dashboard onNavigate={(v) => setView(v)} />}
          {view === "chat" && <ChatPanel />}
          {view === "guardrails" && <GuardrailExplorer />}
          {view === "conflicts" && <ConflictDesk />}
          {view === "evaluate" && <EvaluationReportView />}
          {view === "judge-mode" && <JudgeMode />}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <UserAuthProvider>
      <AppShell />
    </UserAuthProvider>
  );
}

export default App;
