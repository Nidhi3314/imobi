const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

// Admin sign-in and Conflict Desk *decisions* live entirely in the separate
// Admin Console app (see ../../admin-frontend). This client only carries the
// regular-visitor "User Console" identity (/user/*) -- a distinct account
// type that never grants Conflict Desk rights (see backend/app/auth.py).
const USER_TOKEN_STORAGE_KEY = "compliX_user_token";

export function getStoredUserToken(): string | null {
  try {
    return localStorage.getItem(USER_TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredUserToken(token: string | null) {
  try {
    if (token) localStorage.setItem(USER_TOKEN_STORAGE_KEY, token);
    else localStorage.removeItem(USER_TOKEN_STORAGE_KEY);
  } catch {
    // ignore storage failures -- session just won't persist
  }
}

async function request<T>(path: string, options?: RequestInit, authed = false): Promise<T> {
  const isFormData = options?.body instanceof FormData;
  const headers: HeadersInit = {
    ...(isFormData ? {} : { "Content-Type": "application/json" }),
    ...(options?.headers ?? {}),
  };
  if (authed) {
    const token = getStoredUserToken();
    if (token) (headers as Record<string, string>)["Authorization"] = `Bearer ${token}`;
  }
  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  if (!res.ok) {
    let message = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (body?.detail) message = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      // response wasn't JSON -- keep the status-line message
    }
    throw new Error(message);
  }
  return res.json();
}

export interface TraceStep {
  agent: string;
  action: string;
}

export interface Citation {
  guardrail_id: string;
  clause_id?: string;
  label?: string;
}

export interface UserInfo {
  id: number;
  username: string;
  email: string;
  display_name: string | null;
}

export interface GuardrailSource {
  clause_id: string;
  document_id: string | null;
}

export interface Guardrail {
  id: string;
  domain: string;
  category: string | null;
  statement: string;
  severity: string;
  instruction_type: string | null;
  applicability: string | null;
  broken_reference: boolean;
  merged_from: string[];
  is_duplicate_merge: boolean;
  sources: GuardrailSource[];
}

export interface Finding {
  guardrail_id: string;
  guardrail_statement: string;
  domain: string;
  severity: string;
  clause_id: string | null;
  all_clause_ids: string[];
  verdict: "Compliant" | "Non-compliant" | "Gap" | "Unverified";
  evidence_quote: string;
  plain_language: string;
  technical_detail: string;
  retrieval_similarity: number;
  retrieval_reason: string;
  auditor_approved: boolean;
  audit_note: string;
  citation_gate_passed: boolean | null;
  citation_gate_reason: string;
  status: string;
}

export interface EvaluationReport {
  design_id: string;
  design_title: string;
  domain: string;
  findings: Finding[];
  unverified_suppressed: Finding[];
  negative_space: {
    considered_count: number;
    shortlisted_count: number;
    rejected: { guardrail_id: string; similarity: number; reason: string }[];
  };
}

export interface ConflictTicket {
  id: string;
  metric: string;
  rationale: string;
  recommended_resolution: string;
  impact_analysis: {
    operator_guessed: string;
    note: string;
    designs_that_flip: { design_id: string; design_title: string; observed_value: number; verdict_under_a: string; verdict_under_b: string }[];
  } | null;
  status: string;
  decided_by: string | null;
  decided_at: string | null;
  guardrail_a: { id: string; statement: string; value: number | null } | null;
  guardrail_b: { id: string; statement: string; value: number | null } | null;
}

export const api = {
  listGuardrails: (params?: { domain?: string; severity?: string; q?: string }) => {
    const entries = Object.entries(params ?? {}).filter(([, v]) => v !== undefined && v !== "") as [string, string][];
    const qs = new URLSearchParams(entries).toString();
    return request<Guardrail[]>(`/guardrails${qs ? `?${qs}` : ""}`);
  },
  listDomains: () => request<string[]>("/guardrails/domains"),
  getGuardrail: (id: string) => request<Guardrail>(`/guardrails/${id}`),

  getClause: (id: string) =>
    request<{
      id: string;
      clause_ref: string | null;
      clause_heading: string | null;
      clause_text: string;
      document_id: string;
      document_title: string | null;
      document_domain: string | null;
      document_version: string | null;
      document_effective_date: string | null;
    }>(`/clauses/${id}`),

  listDesigns: () => request<{ id: string; title: string; domain: string; expected_outcome: string | null }[]>("/evaluate/designs"),
  evaluateStoredDesign: (designId: string) => request<EvaluationReport>(`/evaluate/${designId}`),
  evaluateText: (body: { design_id?: string; title?: string; domain: string; description: string }) =>
    request<EvaluationReport>("/evaluate", { method: "POST", body: JSON.stringify(body) }),

  listConflicts: (status?: string) => request<ConflictTicket[]>(`/conflicts${status ? `?status=${status}` : ""}`),

  ingestUpload: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<Record<string, unknown>>("/ingest/upload", { method: "POST", body: form });
  },
  ingestDefault: () => request<Record<string, unknown>>("/ingest/default", { method: "POST" }),

  dashboardSummary: () =>
    request<{
      documents: number;
      clauses: number;
      designs: number;
      guardrails_total: number;
      guardrails_by_domain: Record<string, number>;
      guardrails_by_severity: Record<string, number>;
      duplicates_merged: number;
      broken_references: number;
      conflicts_open: number;
      conflicts_decided: number;
    }>("/dashboard/summary"),

  chat: (message: string) =>
    request<{ intent: string; reply: string; data: unknown; citations: Citation[]; trace: TraceStep[] }>("/chat", {
      method: "POST",
      body: JSON.stringify({ message }),
    }),

  citationGateCheck: (guardrailId: string, clauseId: string) =>
    request<{ passed: boolean; reason: string }>("/debug/citation-gate-check", {
      method: "POST",
      body: JSON.stringify({ guardrail_id: guardrailId, clause_id: clauseId }),
    }),

  llmStatus: () =>
    request<{
      configured: boolean;
      mode: "llm" | "heuristic_fallback";
      model: string | null;
      learning: { precedent_decisions: number; metrics_covered: string[] };
    }>("/debug/llm-status"),

  registerUser: (body: { username: string; email: string; password: string; display_name?: string }) =>
    request<{ token: string; user: UserInfo }>("/user/register", { method: "POST", body: JSON.stringify(body) }),
  loginUser: (body: { username: string; password: string }) =>
    request<{ token: string; user: UserInfo }>("/user/login", { method: "POST", body: JSON.stringify(body) }),
  logoutUser: () => request<{ ok: boolean }>("/user/logout", { method: "POST" }, true),
  currentUser: () => request<UserInfo>("/user/me", undefined, true),
};
