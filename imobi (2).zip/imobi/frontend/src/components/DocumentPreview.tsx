import { useEffect, useState } from "react";
import { X, FileText } from "lucide-react";
import { api } from "../api/client";
import "./DocumentPreview.scss";

interface Props {
  clauseId: string | null;
  onClose: () => void;
}

export function DocumentPreview({ clauseId, onClose }: Props) {
  const [clause, setClause] = useState<Awaited<ReturnType<typeof api.getClause>> | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!clauseId) return;
    setLoading(true);
    setError(null);
    setClause(null);
    api
      .getClause(clauseId)
      .then(setClause)
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }, [clauseId]);

  if (!clauseId) return null;

  return (
    <aside className="doc-preview">
      <div className="doc-preview-header">
        <span className="doc-preview-title">
          <FileText size={16} /> Citation
        </span>
        <button className="doc-preview-close" onClick={onClose} aria-label="Close preview">
          <X size={16} />
        </button>
      </div>
      {loading && <p className="doc-preview-loading">Loading…</p>}
      {error && <p className="doc-preview-error">{error}</p>}
      {clause && (
        <div className="doc-preview-body">
          <div className="doc-preview-doc">
            <div className="doc-preview-doc-title">{clause.document_title}</div>
            <div className="doc-preview-doc-meta">
              {clause.document_domain}
              {clause.document_version && <> · v{clause.document_version}</>}
              {clause.document_effective_date && <> · effective {clause.document_effective_date}</>}
            </div>
          </div>
          <div className="doc-preview-clause">
            <div className="doc-preview-clause-ref">
              {clause.id} {clause.clause_ref && <>· §{clause.clause_ref}</>} {clause.clause_heading && <>· {clause.clause_heading}</>}
            </div>
            <blockquote className="doc-preview-clause-text">{clause.clause_text}</blockquote>
          </div>
        </div>
      )}
    </aside>
  );
}
