import { useState } from "react";
import { LogOut, Mail, User as UserIcon, X } from "lucide-react";
import { useUserAuth } from "../auth/UserAuthContext";
import "./UserConsole.scss";

export function UserConsoleButton({ onToggleOpen }: { onToggleOpen: () => void }) {
  const { user } = useUserAuth();
  const initial = (user?.display_name || user?.username || "?").trim().charAt(0).toUpperCase();

  return (
    <button
      className={`user-console-btn ${user ? "user-console-btn-signed-in" : ""}`}
      onClick={onToggleOpen}
      aria-label="User Console"
      title={user ? `Signed in as ${user.username}` : "Sign in / Register"}
    >
      {user ? initial : <UserIcon size={16} />}
    </button>
  );
}

export function UserConsolePanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user, loading, login, register, logout } = useUserAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "login") await login(username, password);
      else await register(username, email, password, displayName || undefined);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="user-console-panel">
      <div className="user-console-header">
        <span>User Console</span>
        <button onClick={onClose} aria-label="Close">
          <X size={15} />
        </button>
      </div>

      {loading && <p className="user-console-loading">Loading…</p>}

      {!loading && user && (
        <div className="user-console-profile">
          <div className="user-console-avatar">{(user.display_name || user.username).charAt(0).toUpperCase()}</div>
          <div className="user-console-profile-name">{user.display_name || user.username}</div>
          <div className="user-console-profile-row">
            <UserIcon size={13} /> {user.username}
          </div>
          <div className="user-console-profile-row">
            <Mail size={13} /> {user.email}
          </div>
          <button className="btn-ghost user-console-signout" onClick={logout}>
            <LogOut size={14} /> Sign out
          </button>
        </div>
      )}

      {!loading && !user && (
        <>
          <div className="user-console-tabs">
            <button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>
              Sign in
            </button>
            <button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>
              Register
            </button>
          </div>
          <form onSubmit={submit} className="user-console-form">
            <label>
              Username
              <input value={username} onChange={(e) => setUsername(e.target.value)} required autoComplete="username" />
            </label>
            {mode === "register" && (
              <>
                <label>
                  Email
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </label>
                <label>
                  Display name (optional)
                  <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
                </label>
              </>
            )}
            <label>
              Password
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
                autoComplete={mode === "login" ? "current-password" : "new-password"}
              />
            </label>
            {error && <p className="user-console-error">{error}</p>}
            <button className="btn-primary user-console-submit" type="submit" disabled={busy}>
              {busy ? "Working…" : mode === "login" ? "Sign in" : "Create account"}
            </button>
          </form>
        </>
      )}
    </div>
  );
}
