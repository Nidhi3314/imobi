import { useEffect, useState } from "react";
import { api, type EvaluationReport } from "../api/client";
import { VerdictBadge, SeverityBadge, Chip } from "../design-system/Badge";
import "./EvaluationReportView.scss";

export function EvaluationReportView() {
  const [designs, setDesigns] = useState<{ id: string; title: string; domain: string }[]>([]);
  const [designId, setDesignId] = useState("");
  const [report, setReport] = useState<EvaluationReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [showNegativeSpace, setShowNegativeSpace] = useState(false);
  const [showTech, setShowTech] = useState<Record<string, boolean>>({});

  useEffect(() => {
    api.listDesigns().then((ds) => {
      setDesigns(ds);
      if (ds.length) setDesignId(ds[0].id);
    });
  }, []);

  useEffect(() => {
    if (!designId) return;
    setLoading(true);
    api
      .evaluateStoredDesign(designId)
      .then(setReport)
      .finally(() => setLoading(false));
  }, [designId]);

  return (
    <div className="eval-report-view">
      <h1>Evaluation Report</h1>
      <p className="report-sub">
        Every finding below carries a citation to a specific guardrail and source clause. If a citation can't be
        verified, it's shown as <VerdictBadge verdict="Unverified" /> instead of a fabricated verdict.
      </p>

      <select className="design-picker" value={designId} onChange={(e) => setDesignId(e.target.value)}>
        {designs.map((d) => (
          <option key={d.id} value={d.id}>
            {d.id} — {d.title} ({d.domain})
          </option>
        ))}
      </select>

      {loading && <p>Evaluating…</p>}

      {report && !loading && (
        <>
          <div className="report-negative-space">
            <button className="negative-space-toggle" onClick={() => setShowNegativeSpace((s) => !s)}>
              {report.negative_space.considered_count} guardrails considered → {report.negative_space.shortlisted_count} relevant
              → {report.negative_space.rejected.length} ruled out {showNegativeSpace ? "▲" : "▼"}
            </button>
            {showNegativeSpace && (
              <ul className="negative-space-list">
                {report.negative_space.rejected.slice(0, 20).map((r) => (
                  <li key={r.guardrail_id}>
                    <span className="ns-id">{r.guardrail_id}</span> — {r.reason} (similarity {r.similarity.toFixed(2)})
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="findings-list">
            {report.findings.map((f, i) => (
              <div key={i} className="finding-card">
                <div className="finding-header">
                  <VerdictBadge verdict={f.verdict} />
                  <SeverityBadge severity={f.severity} />
                  <Chip>{f.guardrail_id}</Chip>
                  {f.clause_id && <Chip>clause {f.clause_id}</Chip>}
                </div>
                <p className="finding-plain">{f.plain_language}</p>
                {f.evidence_quote && <blockquote className="finding-evidence">"{f.evidence_quote}"</blockquote>}
                <button
                  className="finding-tech-toggle"
                  onClick={() => setShowTech((s) => ({ ...s, [i]: !s[i] }))}
                >
                  {showTech[i] ? "Hide" : "Show"} technical detail
                </button>
                {showTech[i] && (
                  <div className="finding-tech">
                    <p>{f.technical_detail}</p>
                    <p className="finding-audit">
                      Auditor Agent: {f.auditor_approved ? "approved" : "rejected"} — {f.audit_note}
                    </p>
                    <p className="finding-audit">Citation gate: {f.citation_gate_reason}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          {report.unverified_suppressed.length > 0 && (
            <div className="suppressed-section">
              <h2>Suppressed by the trust layers ({report.unverified_suppressed.length})</h2>
              <p className="suppressed-note">
                These findings failed the Auditor Agent or the citation gate and were withheld rather than shown as a
                verdict — never displayed as if they were trustworthy.
              </p>
              {report.unverified_suppressed.map((f, i) => (
                <div key={i} className="finding-card finding-card-suppressed">
                  <VerdictBadge verdict="Unverified" /> <Chip>{f.guardrail_id}</Chip>
                  <p className="finding-plain">{f.citation_gate_reason || f.audit_note}</p>
                </div>
              ))}
            </div>
          )}

          <p className="report-disclaimer">
            Recommend, don't enforce: this report flags issues for a human reviewer and never automatically approves
            or blocks a real deployment.
          </p>
        </>
      )}
    </div>
  );
}
