import { useState } from "react";
import { api, type EvaluationReport } from "../api/client";
import { VerdictBadge } from "../design-system/Badge";
import "./JudgeMode.scss";

export function JudgeMode() {
  const [uploadResult, setUploadResult] = useState<Record<string, unknown> | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [domain, setDomain] = useState("Information Security");
  const [description, setDescription] = useState(
    "A new microservice stores customer support tickets, including free-text notes that sometimes contain customer emails, in a public cloud bucket with default settings.",
  );
  const [adhocReport, setAdhocReport] = useState<EvaluationReport | null>(null);
  const [evaluating, setEvaluating] = useState(false);

  const [gGuardrail, setGGuardrail] = useState("GR-does-not-exist");
  const [gClause, setGClause] = useState("CL-9999");
  const [gateResult, setGateResult] = useState<{ passed: boolean; reason: string } | null>(null);
  const [gateChecking, setGateChecking] = useState(false);

  async function handleUpload(file: File) {
    setUploading(true);
    setUploadError(null);
    setUploadResult(null);
    try {
      const result = await api.ingestUpload(file);
      setUploadResult(result);
    } catch (e) {
      setUploadError((e as Error).message);
    } finally {
      setUploading(false);
    }
  }

  async function runAdhoc() {
    setEvaluating(true);
    try {
      const report = await api.evaluateText({ domain, description });
      setAdhocReport(report);
    } finally {
      setEvaluating(false);
    }
  }

  async function checkGate() {
    setGateChecking(true);
    try {
      setGateResult(await api.citationGateCheck(gGuardrail, gClause));
    } finally {
      setGateChecking(false);
    }
  }

  return (
    <div className="judge-mode">
      <h1>Judge Mode</h1>
      <p className="judge-sub">
        Three ways to stress-test the "not hardcoded to the sample IDs" claim, live — no need to take our word for it.
      </p>

      <section className="judge-section">
        <h2>1. Upload your own workbook</h2>
        <p>
          Upload any .xlsx with the same sheet shapes (<code>Governance_Documents</code>, <code>Clauses</code>,
          <code>Design_Descriptions</code>) — including a modified copy with different IDs, new documents, or new
          duplicates/conflicts — and watch the identical pipeline run against it, live.
        </p>
        <input
          type="file"
          accept=".xlsx"
          disabled={uploading}
          onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
        />
        {uploading && <p>Running the full pipeline against your file…</p>}
        {uploadError && <p className="judge-error">{uploadError}</p>}
        {uploadResult && (
          <pre className="judge-result">{JSON.stringify(uploadResult, null, 2)}</pre>
        )}
      </section>

      <section className="judge-section">
        <h2>2. Evaluate a design we've never seen</h2>
        <p>Type (or paste) any design description — not one of the 12 sample designs — and get a fully cited report.</p>
        <input className="judge-input" value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Domain" />
        <textarea
          className="judge-textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
        />
        <button className="btn-primary" onClick={runAdhoc} disabled={evaluating}>
          {evaluating ? "Evaluating…" : "Evaluate"}
        </button>
        {adhocReport && (
          <div className="judge-adhoc-results">
            {adhocReport.findings.slice(0, 8).map((f, i) => (
              <div key={i} className="judge-finding">
                <VerdictBadge verdict={f.verdict} /> <strong>{f.guardrail_id}</strong> — {f.plain_language}
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="judge-section">
        <h2>3. Try to fool the citation gate</h2>
        <p>
          Type any guardrail ID and clause ID — including ones you make up — and see whether the deterministic gate
          lets it through. It never does unless both are real and actually linked.
        </p>
        <div className="judge-gate-row">
          <input className="judge-input" value={gGuardrail} onChange={(e) => setGGuardrail(e.target.value)} placeholder="Guardrail ID" />
          <input className="judge-input" value={gClause} onChange={(e) => setGClause(e.target.value)} placeholder="Clause ID" />
          <button className="btn-primary" onClick={checkGate} disabled={gateChecking}>
            Check
          </button>
        </div>
        {gateResult && (
          <p className={gateResult.passed ? "gate-pass" : "gate-fail"}>
            {gateResult.passed ? "✓ Passed" : "✕ Rejected"}: {gateResult.reason}
          </p>
        )}
      </section>
    </div>
  );
}
