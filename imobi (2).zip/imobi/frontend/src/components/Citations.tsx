import { BookMarked } from "lucide-react";
import type { Citation } from "../api/client";
import "./Citations.scss";

interface Props {
  citations: Citation[];
  onOpen: (citation: Citation) => void;
}

/** The answer's prose is written by the Chat Composer (see chat_composer.py);
 * these chips are built directly from the same structured records, not
 * parsed out of that prose -- so citations stay exactly as trustworthy as
 * the underlying data regardless of how the model worded the answer. */
export function Citations({ citations, onOpen }: Props) {
  if (citations.length === 0) return null;

  return (
    <div className="citations">
      <div className="citations-heading">
        <BookMarked size={12} /> Citations ({citations.length})
      </div>
      <div className="citations-chips">
        {citations.map((c, i) => (
          <button key={i} className="citations-chip" onClick={() => onOpen(c)} title={c.label}>
            {c.guardrail_id}
          </button>
        ))}
      </div>
    </div>
  );
}
