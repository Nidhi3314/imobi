import { useState, useRef, useEffect } from "react";
import { SendHorizontal, Plus, MessageSquare, Trash2 } from "lucide-react";
import { api, type Citation, type TraceStep } from "../api/client";
import { AgentTrace, agentTraceDurationMs } from "./AgentTrace";
import { Citations } from "./Citations";
import { DocumentPreview } from "./DocumentPreview";
import { ChatSettingsButton, ChatSettingsPanel, type ChatSettingsState } from "./ChatSettings";
import "./ChatPanel.scss";

interface Message {
  role: "user" | "assistant";
  text: string;
  intent?: string;
  citations?: Citation[];
  trace?: TraceStep[];
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
}

const SUGGESTIONS = [
  "Show mandatory Information Security guardrails about encryption",
  "Evaluate the public customer file share design",
  "Show me open conflicts",
];

const THINKING_PHRASES = ["Routing your request…", "Consulting the guardrail model…"];

function welcomeMessage(name: string): Message {
  return {
    role: "assistant",
    text: `Hi ${name}. Ask me to search guardrails, evaluate a design, or check open conflicts — every answer traces back to a source clause.`,
  };
}

const SESSIONS_KEY = "guardrailiq_chat_sessions";
const USERNAME_KEY = "guardrailiq_chat_username";
const SETTINGS_KEY = "guardrailiq_chat_settings";
const DEFAULT_SETTINGS: ChatSettingsState = { showTrace: true, showThinkingPhrases: true };

function readLocalStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
  } catch {
    // ignore corrupt/missing storage
  }
  return fallback;
}

function writeLocalStorage(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage failures
  }
}

function newSession(userName: string): ChatSession {
  return { id: crypto.randomUUID(), title: "New chat", messages: [welcomeMessage(userName)] };
}

export function ChatPanel() {
  const [userName, setUserName] = useState(() => readLocalStorage(USERNAME_KEY, "Guest"));
  const [settings, setSettings] = useState<ChatSettingsState>(() => readLocalStorage(SETTINGS_KEY, DEFAULT_SETTINGS));
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const stored = readLocalStorage<ChatSession[] | null>(SESSIONS_KEY, null);
    return stored && stored.length > 0 ? stored : [newSession(readLocalStorage(USERNAME_KEY, "Guest"))];
  });
  const [activeId, setActiveId] = useState(sessions[0].id);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [pendingTrace, setPendingTrace] = useState<TraceStep[] | null>(null);
  const [thinkingPhrase, setThinkingPhrase] = useState(THINKING_PHRASES[0]);
  const [previewClauseId, setPreviewClauseId] = useState<string | null>(null);
  const [llmMode, setLlmMode] = useState<Awaited<ReturnType<typeof api.llmStatus>> | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const active = sessions.find((s) => s.id === activeId) ?? sessions[0];

  useEffect(() => writeLocalStorage(SESSIONS_KEY, sessions), [sessions]);
  useEffect(() => writeLocalStorage(USERNAME_KEY, userName), [userName]);
  useEffect(() => writeLocalStorage(SETTINGS_KEY, settings), [settings]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [active?.messages, pendingTrace, loading]);

  useEffect(() => {
    api.llmStatus().then(setLlmMode).catch(() => {});
  }, []);

  useEffect(() => {
    if (!loading || pendingTrace || !settings.showThinkingPhrases) return;
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % THINKING_PHRASES.length;
      setThinkingPhrase(THINKING_PHRASES[i]);
    }, 1100);
    return () => clearInterval(id);
  }, [loading, pendingTrace, settings.showThinkingPhrases]);

  function updateActive(fn: (s: ChatSession) => ChatSession) {
    setSessions((all) => all.map((s) => (s.id === activeId ? fn(s) : s)));
  }

  function startNewChat() {
    const session = newSession(userName);
    setSessions((all) => [session, ...all]);
    setActiveId(session.id);
  }

  function deleteChat(id: string) {
    setSessions((all) => {
      const remaining = all.filter((s) => s.id !== id);
      if (remaining.length === 0) {
        const fresh = newSession(userName);
        if (id === activeId) setActiveId(fresh.id);
        return [fresh];
      }
      if (id === activeId) setActiveId(remaining[0].id);
      return remaining;
    });
  }

  async function send(text: string) {
    if (!text.trim() || loading) return;
    const isFirstUserMessage = !active.messages.some((m) => m.role === "user");
    updateActive((s) => ({
      ...s,
      title: isFirstUserMessage ? text.slice(0, 42) : s.title,
      messages: [...s.messages, { role: "user", text }],
    }));
    setInput("");
    setLoading(true);
    setPendingTrace(null);
    setThinkingPhrase(THINKING_PHRASES[0]);

    try {
      const res = await api.chat(text);
      const commit = () => {
        updateActive((s) => ({
          ...s,
          messages: [
            ...s.messages,
            { role: "assistant", text: res.reply, intent: res.intent, citations: res.citations, trace: res.trace },
          ],
        }));
        setLoading(false);
        setPendingTrace(null);
      };

      // Hold the finished answer back until the agent-trace animation plays
      // through, so the workflow steps visibly happen *before* the answer
      // appears -- not decorated onto an already-completed message.
      if (settings.showTrace && res.trace?.length) {
        setPendingTrace(res.trace);
        setTimeout(commit, agentTraceDurationMs(res.trace));
      } else {
        commit();
      }
    } catch (e) {
      updateActive((s) => ({
        ...s,
        messages: [...s.messages, { role: "assistant", text: `Error: ${(e as Error).message}` }],
      }));
      setLoading(false);
      setPendingTrace(null);
    }
  }

  async function openCitation(citation: Citation) {
    if (citation.clause_id) {
      setPreviewClauseId(citation.clause_id);
      return;
    }
    try {
      const g = await api.getGuardrail(citation.guardrail_id);
      if (g.sources[0]) setPreviewClauseId(g.sources[0].clause_id);
    } catch {
      // no-op -- preview just won't open
    }
  }

  const userInitial = (userName || "G").trim().charAt(0).toUpperCase() || "G";

  return (
    <div className="chat-layout">
      <aside className="chat-history">
        <button className="chat-new-btn" onClick={startNewChat}>
          <Plus size={15} /> New chat
        </button>
        <div className="chat-history-heading">Chat history</div>
        <div className="chat-history-list">
          {sessions.map((s) => (
            <div key={s.id} className={`chat-history-item ${s.id === activeId ? "active" : ""}`}>
              <button className="chat-history-item-main" onClick={() => setActiveId(s.id)}>
                <MessageSquare size={14} />
                <span>{s.title}</span>
              </button>
              <button
                className="chat-history-item-delete"
                onClick={() => deleteChat(s.id)}
                aria-label={`Delete "${s.title}"`}
                title="Delete chat"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </div>

        <div className="chat-history-footer">
          <span className="chat-user-badge">
            <span className="chat-user-avatar">{userInitial}</span>
            {userName}
          </span>
          <ChatSettingsButton open={settingsOpen} onToggleOpen={() => setSettingsOpen((o) => !o)} />
          <ChatSettingsPanel
            open={settingsOpen}
            onToggleOpen={() => setSettingsOpen(false)}
            userName={userName}
            onUserNameChange={setUserName}
            settings={settings}
            onSettingsChange={setSettings}
            llmMode={llmMode}
          />
        </div>
      </aside>

      <div className="chat-panel">
        <div className="chat-panel-header">
          <span className="chat-panel-header-title">CompliX Assistant</span>
        </div>

        <div className="chat-messages">
          {active.messages.map((m, i) => (
            <div key={i} className={`chat-bubble chat-bubble-${m.role}`}>
              {m.role === "assistant" && settings.showTrace && m.trace && <AgentTrace steps={m.trace} />}
              <div className="chat-bubble-text">{m.text}</div>
              {m.citations && <Citations citations={m.citations} onOpen={openCitation} />}
            </div>
          ))}
          {loading && (
            <div className="chat-bubble chat-bubble-assistant chat-loading">
              {settings.showTrace && pendingTrace ? (
                <AgentTrace steps={pendingTrace} />
              ) : (
                <span className="chat-loading-text">
                  <span className="chat-loading-dot" />
                  {settings.showThinkingPhrases ? thinkingPhrase : "Working…"}
                </span>
              )}
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="chat-suggestions">
          {SUGGESTIONS.map((s) => (
            <button key={s} className="chat-suggestion-chip" onClick={() => send(s)}>
              {s}
            </button>
          ))}
        </div>
        <form
          className="chat-input-row"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <input
            className="chat-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask CompliX…"
          />
          <button className="chat-send" type="submit" disabled={loading} aria-label="Send">
            <SendHorizontal size={16} />
          </button>
        </form>
        <p className="chat-disclaimer">
          CompliX recommends; it does not automatically approve or block a real deployment. A human reviewer
          stays in control.
        </p>
      </div>

      <DocumentPreview clauseId={previewClauseId} onClose={() => setPreviewClauseId(null)} />
    </div>
  );
}
