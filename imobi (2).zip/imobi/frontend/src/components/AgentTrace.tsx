import { useEffect, useRef, useState } from "react";
import { Bot, Check } from "lucide-react";
import type { TraceStep } from "../api/client";
import "./AgentTrace.scss";

export const AGENT_TRACE_STEP_DELAY_MS = 260;
export const AGENT_TRACE_TAIL_MS = 450;

export function agentTraceDurationMs(steps: TraceStep[]): number {
  if (steps.length === 0) return 0;
  return (steps.length - 1) * AGENT_TRACE_STEP_DELAY_MS + AGENT_TRACE_TAIL_MS;
}

/** Reveals each real pipeline stage in sequence rather than dumping the
 * whole trace at once -- the steps are genuine (see orchestrator.py), the
 * staggered reveal just makes the multi-agent handoff visible instead of
 * an instant wall of text. Meant to play out *while the answer is still
 * pending*, not attached after the fact to an already-finished message --
 * see ChatPanel, which holds the real reply back until this finishes. */
export function AgentTrace({ steps, onDone }: { steps: TraceStep[]; onDone?: () => void }) {
  const [revealed, setRevealed] = useState(steps.length === 0 ? steps.length : 1);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  useEffect(() => {
    setRevealed(1);
    if (steps.length <= 1) {
      onDoneRef.current?.();
      return;
    }
    const timers = steps.slice(1).map((_, i) =>
      setTimeout(() => setRevealed((r) => Math.max(r, i + 2)), (i + 1) * AGENT_TRACE_STEP_DELAY_MS),
    );
    const doneTimer = setTimeout(() => onDoneRef.current?.(), agentTraceDurationMs(steps));
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(doneTimer);
    };
  }, [steps]);

  if (steps.length === 0) return null;

  return (
    <div className="agent-trace">
      {steps.slice(0, revealed).map((step, i) => (
        <div key={i} className={`agent-trace-step ${i === revealed - 1 ? "agent-trace-step-latest" : ""}`}>
          <span className="agent-trace-icon">
            {i < revealed - 1 ? <Check size={12} /> : <Bot size={12} />}
          </span>
          <span className="agent-trace-agent">{step.agent}</span>
          <span className="agent-trace-action">{step.action}</span>
        </div>
      ))}
    </div>
  );
}
