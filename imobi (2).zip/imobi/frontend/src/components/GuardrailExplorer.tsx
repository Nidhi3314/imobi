import { useEffect, useState } from "react";
import { api, type Guardrail } from "../api/client";
import { SeverityBadge } from "../design-system/Badge";
import "./GuardrailExplorer.scss";

export function GuardrailExplorer() {
  const [guardrails, setGuardrails] = useState<Guardrail[]>([]);
  const [domains, setDomains] = useState<string[]>([]);
  const [domain, setDomain] = useState("");
  const [severity, setSeverity] = useState("");
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listDomains().then(setDomains).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .listGuardrails({ domain: domain || undefined, severity: severity || undefined, q: q || undefined })
      .then(setGuardrails)
      .finally(() => setLoading(false));
  }, [domain, severity, q]);

  return (
    <div className="guardrail-explorer">
      <h1>Guardrail Explorer</h1>
      <p className="explorer-sub">
        Every guardrail below was derived from real clauses, not typed in by hand — expand a row to see its sources,
        and any duplicate-merge or broken-reference flags.
      </p>
      <div className="explorer-filters">
        <input
          className="explorer-search"
          placeholder="Search guardrail text…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select value={domain} onChange={(e) => setDomain(e.target.value)}>
          <option value="">All domains</option>
          {domains.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
        <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
          <option value="">All severities</option>
          {["Mandatory", "High", "Medium", "Low"].map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <p>Loading…</p>
      ) : (
        <div className="explorer-table">
          {guardrails.map((g) => (
            <div key={g.id} className="explorer-row">
              <div className="explorer-row-summary" onClick={() => setExpanded(expanded === g.id ? null : g.id)}>
                <SeverityBadge severity={g.severity} />
                <span className="explorer-row-id">{g.id}</span>
                <span className="explorer-row-statement">{g.statement}</span>
                <div className="explorer-row-flags">
                  {g.is_duplicate_merge && <span className="flag flag-amber">merged duplicate</span>}
                  {g.broken_reference && <span className="flag flag-red">broken reference</span>}
                </div>
                <span className="explorer-chevron">{expanded === g.id ? "▲" : "▼"}</span>
              </div>
              {expanded === g.id && (
                <div className="explorer-row-detail">
                  <p>
                    <strong>Domain:</strong> {g.domain} {g.category && <>· <strong>Category:</strong> {g.category}</>}
                  </p>
                  {g.applicability && (
                    <p>
                      <strong>Applicability:</strong> {g.applicability}
                    </p>
                  )}
                  <p>
                    <strong>Sources</strong> ({g.sources.length}
                    {g.is_duplicate_merge ? " — preserved from all merged clauses" : ""}):
                  </p>
                  <ul>
                    {g.sources.map((s, i) => (
                      <li key={i}>
                        Clause {s.clause_id} {s.document_id && <>(Document {s.document_id})</>}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
          {guardrails.length === 0 && <p>No guardrails match these filters.</p>}
        </div>
      )}
    </div>
  );
}
