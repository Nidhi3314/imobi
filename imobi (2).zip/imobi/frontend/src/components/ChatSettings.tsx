import { BookOpen, Cpu, Settings, Sparkles, X } from "lucide-react";
import "./ChatSettings.scss";

export interface ChatSettingsState {
  showTrace: boolean;
  showThinkingPhrases: boolean;
}

interface LlmMode {
  configured: boolean;
  model: string | null;
  learning: { precedent_decisions: number; metrics_covered: string[] };
}

interface Props {
  open: boolean;
  onToggleOpen: () => void;
  userName: string;
  onUserNameChange: (name: string) => void;
  settings: ChatSettingsState;
  onSettingsChange: (settings: ChatSettingsState) => void;
  llmMode: LlmMode | null;
}

export function ChatSettingsButton({ open, onToggleOpen }: Pick<Props, "open" | "onToggleOpen">) {
  return (
    <button
      className="chat-settings-btn"
      onClick={onToggleOpen}
      aria-label="Chat settings"
      aria-expanded={open}
      title="Chat settings"
    >
      <Settings size={16} />
    </button>
  );
}

export function ChatSettingsPanel({ open, onToggleOpen, userName, onUserNameChange, settings, onSettingsChange, llmMode }: Props) {
  if (!open) return null;

  return (
    <div className="chat-settings-panel">
      <div className="chat-settings-header">
        <span>Chat settings</span>
        <button onClick={onToggleOpen} aria-label="Close settings">
          <X size={15} />
        </button>
      </div>

      <label className="chat-settings-field">
        Your name
        <input
          value={userName}
          onChange={(e) => onUserNameChange(e.target.value || "Guest")}
          placeholder="Guest"
          maxLength={40}
        />
      </label>

      <label className="chat-settings-toggle">
        <input
          type="checkbox"
          checked={settings.showTrace}
          onChange={(e) => onSettingsChange({ ...settings, showTrace: e.target.checked })}
        />
        Show agent workflow trace
      </label>

      <label className="chat-settings-toggle">
        <input
          type="checkbox"
          checked={settings.showThinkingPhrases}
          onChange={(e) => onSettingsChange({ ...settings, showThinkingPhrases: e.target.checked })}
        />
        Show "thinking" status phrases
      </label>

      <div className="chat-settings-mode">
        <span className="chat-settings-mode-label">Reasoning mode (read-only)</span>
        <span className="chat-settings-mode-value">
          {llmMode ? (
            <>
              {llmMode.configured ? <Sparkles size={12} /> : <Cpu size={12} />}
              {llmMode.configured ? `LLM — ${llmMode.model}` : "Heuristic fallback (no LLM configured)"}
            </>
          ) : (
            "Checking…"
          )}
        </span>
      </div>

      <div className="chat-settings-mode">
        <span className="chat-settings-mode-label">Learning (read-only)</span>
        <span className="chat-settings-mode-value">
          {llmMode ? (
            <>
              <BookOpen size={12} />
              {llmMode.learning.precedent_decisions === 0
                ? "No precedent yet — the Conflict Agent starts learning after the first Conflict Desk decision"
                : `Applying ${llmMode.learning.precedent_decisions} past decision${llmMode.learning.precedent_decisions === 1 ? "" : "s"} as precedent across ${llmMode.learning.metrics_covered.length} conflict type${llmMode.learning.metrics_covered.length === 1 ? "" : "s"}`}
            </>
          ) : (
            "Checking…"
          )}
        </span>
      </div>
    </div>
  );
}
