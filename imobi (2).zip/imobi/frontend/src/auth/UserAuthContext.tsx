import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, getStoredUserToken, setStoredUserToken, type UserInfo } from "../api/client";

interface UserAuthState {
  user: UserInfo | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string, displayName?: string) => Promise<void>;
  logout: () => void;
}

const UserAuthContext = createContext<UserAuthState | null>(null);

export function UserAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getStoredUserToken();
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .currentUser()
      .then(setUser)
      .catch(() => setStoredUserToken(null))
      .finally(() => setLoading(false));
  }, []);

  async function login(username: string, password: string) {
    const res = await api.loginUser({ username, password });
    setStoredUserToken(res.token);
    setUser(res.user);
  }

  async function register(username: string, email: string, password: string, displayName?: string) {
    const res = await api.registerUser({ username, email, password, display_name: displayName });
    setStoredUserToken(res.token);
    setUser(res.user);
  }

  function logout() {
    api.logoutUser().catch(() => {});
    setStoredUserToken(null);
    setUser(null);
  }

  return (
    <UserAuthContext.Provider value={{ user, loading, login, register, logout }}>{children}</UserAuthContext.Provider>
  );
}

export function useUserAuth(): UserAuthState {
  const ctx = useContext(UserAuthContext);
  if (!ctx) throw new Error("useUserAuth must be used within UserAuthProvider");
  return ctx;
}
