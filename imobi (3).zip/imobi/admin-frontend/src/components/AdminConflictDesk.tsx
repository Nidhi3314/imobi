import { useEffect, useState } from "react";
import { Scale, UserPlus } from "lucide-react";
import { api, type ConflictTicket } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import "./AdminConflictDesk.scss";

export function AdminConflictDesk() {
  const { admin } = useAuth();
  const [tickets, setTickets] = useState<ConflictTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [assigning, setAssigning] = useState<string | null>(null);
  const [assignee, setAssignee] = useState("");

  function load() {
    setLoading(true);
    api
      .listConflicts()
      .then(setTickets)
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function decide(id: string, decision: string) {
    setBusy(id);
    setError(null);
    try {
      await api.decideConflict(id, decision);
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function assign(id: string) {
    if (!assignee.trim()) return;
    setError(null);
    try {
      await api.assignConflict(id, assignee.trim());
      setAssigning(null);
      setAssignee("");
      load();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  const open = tickets.filter((t) => t.status === "open");
  const decided = tickets.filter((t) => t.status !== "open");

  return (
    <div className="conflict-desk">
      <h1>
        <Scale size={22} /> Conflict Desk
      </h1>
      <p className="desk-sub">
        CompliX <strong>never</strong> silently picks a side when two sources disagree. Approve A, approve B, or
        keep it open — your decision is recorded against your account, and the original guardrails are never edited.
      </p>

      {error && <p className="desk-error">{error}</p>}
      {loading && <p>Loading…</p>}
      {!loading && open.length === 0 && <p className="desk-empty">No open conflicts right now.</p>}

      {open.map((t) => (
        <div key={t.id} className={`conflict-ticket ${t.assigned_to === admin?.username ? "conflict-ticket-mine" : ""}`}>
          <div className="ticket-header">
            <span className="ticket-id">{t.id}</span>
            <span className="ticket-metric">{t.metric}</span>
            {t.assigned_to && <span className="ticket-assigned">Assigned to {t.assigned_to}</span>}
            <span className="ticket-status ticket-status-open">Awaiting decision</span>
          </div>

          <div className="ticket-sides">
            <div className="ticket-side">
              <div className="ticket-side-label">Side A</div>
              <div className="ticket-side-id">{t.guardrail_a?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_a?.statement}</div>
            </div>
            <div className="ticket-vs">vs</div>
            <div className="ticket-side">
              <div className="ticket-side-label">Side B</div>
              <div className="ticket-side-id">{t.guardrail_b?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_b?.statement}</div>
            </div>
          </div>

          <p className="ticket-rationale">
            <strong>Why the Conflict Agent flagged this:</strong> {t.rationale}
          </p>
          <p className="ticket-recommendation">
            <strong>Recommendation:</strong> {t.recommended_resolution}
          </p>

          {t.impact_analysis && (
            <div className="ticket-impact">
              <strong>Impact analysis</strong> <span className="impact-note">({t.impact_analysis.note})</span>
              {t.impact_analysis.designs_that_flip.length === 0 ? (
                <p className="impact-empty">No existing designs would flip verdict under either resolution.</p>
              ) : (
                <ul>
                  {t.impact_analysis.designs_that_flip.map((d) => (
                    <li key={d.design_id}>
                      <strong>{d.design_id}</strong> ({d.design_title}): observed value {d.observed_value} —{" "}
                      {d.verdict_under_a} under A, {d.verdict_under_b} under B
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <div className="ticket-actions">
            <button className="btn-primary" disabled={busy === t.id} onClick={() => decide(t.id, "approved_a")}>
              Approve A
            </button>
            <button className="btn-primary" disabled={busy === t.id} onClick={() => decide(t.id, "approved_b")}>
              Approve B
            </button>
            <button className="btn-ghost" disabled={busy === t.id} onClick={() => decide(t.id, "kept_open")}>
              Keep Open
            </button>
            {assigning === t.id ? (
              <span className="ticket-assign-form">
                <input
                  placeholder="username"
                  value={assignee}
                  onChange={(e) => setAssignee(e.target.value)}
                  autoFocus
                />
                <button className="btn-ghost" onClick={() => assign(t.id)}>
                  Save
                </button>
              </span>
            ) : (
              <button className="btn-ghost" onClick={() => setAssigning(t.id)}>
                <UserPlus size={13} /> Assign
              </button>
            )}
          </div>
        </div>
      ))}

      {decided.length > 0 && (
        <>
          <h2 className="desk-decided-heading">Decided</h2>
          {decided.map((t) => (
            <div key={t.id} className="conflict-ticket conflict-ticket-decided">
              <div className="ticket-header">
                <span className="ticket-id">{t.id}</span>
                <span className="ticket-metric">{t.metric}</span>
                <span className="ticket-status">
                  {t.status.replace("_", " ")} by {t.decided_by}
                </span>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
