import { useState } from "react";
import { FilePlus2 } from "lucide-react";
import { api } from "../api/client";
import { AdminFileUploadButton } from "./AdminFileUploadButton";
import "./AdminDesignForm.scss";

export function AdminDesignForm() {
  const [title, setTitle] = useState("");
  const [domain, setDomain] = useState("Information Security");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setBusy(true);
    try {
      const result = await api.createDesign({ title, domain, description });
      setSuccess(`Created ${result.id}. It's now listed in the Evaluation Report picker.`);
      setTitle("");
      setDescription("");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-design-form">
      <h1>
        <FilePlus2 size={20} /> Add a Design
      </h1>
      <p className="admin-design-sub">
        A permanent design description, listed alongside the dataset's own samples in the Evaluation Report and
        chat's "evaluate the X design" matching -- not a throwaway ad-hoc check.
      </p>

      <form onSubmit={submit} className="admin-design-form-fields">
        <label>
          Title
          <input value={title} onChange={(e) => setTitle(e.target.value)} required />
        </label>
        <label>
          Domain
          <input value={domain} onChange={(e) => setDomain(e.target.value)} required />
        </label>
        <label>
          Design description
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={6}
            placeholder="Describe the architecture: components, data flows, hosting, security controls…"
            required
          />
        </label>
        <AdminFileUploadButton
          extract={(file) => api.extractDesignFile(file)}
          onExtracted={(text, suggestedTitle) => {
            setDescription(text);
            if (suggestedTitle && !title.trim()) setTitle(suggestedTitle);
          }}
        />
        {error && <p className="admin-design-error">{error}</p>}
        {success && <p className="admin-design-success">{success}</p>}
        <button className="btn-primary" type="submit" disabled={busy}>
          {busy ? "Creating…" : "Create design"}
        </button>
      </form>
    </div>
  );
}
