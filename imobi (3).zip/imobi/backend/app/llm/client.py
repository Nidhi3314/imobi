"""
Single seam between all agents and whatever LLM gateway the team wires up
("LLmass", or any OpenAI-compatible chat-completions endpoint). Every agent
calls only `complete()` -- swapping providers, or going fully LLM-free, means
touching this file alone.

If no endpoint is configured (GUARDRAILIQ_LLM_BASE_URL unset), `complete()`
raises LLMNotConfigured so callers fall back to their deterministic
regex/heuristic path -- the whole pipeline still runs end-to-end without live
model access, which the guide explicitly allows ("LLM-free option").
"""
from __future__ import annotations

import json
import time
from typing import Any

import requests

from app import config

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 4
_MAX_BACKOFF_SECONDS = 20


class LLMNotConfigured(RuntimeError):
    pass


class LLMCallFailed(RuntimeError):
    pass


def is_configured() -> bool:
    return bool(config.LLM_BASE_URL)


def complete(
    system: str,
    user: str | list[dict[str, Any]],
    json_schema: dict | None = None,
    model: str | None = None,
) -> dict[str, Any]:
    """Returns a parsed JSON dict. Assumes an OpenAI-compatible /chat/completions
    shape with `response_format: json_schema`; if the gateway doesn't support
    forced JSON, the caller should still get valid JSON back most of the time
    because we also instruct it in the prompt, with a best-effort repair pass
    below.

    `user` is normally plain text, but can also be a pre-built multimodal
    content list (see `image_content_part` / `complete_vision` below) for
    gateways that support image input in the same chat-completions shape."""
    if not is_configured():
        raise LLMNotConfigured("No LLM gateway configured; caller should use its heuristic fallback.")

    payload = {
        "model": model or config.LLM_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0,
    }
    if json_schema:
        payload["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "response", "schema": json_schema, "strict": True},
        }

    headers = {"Content-Type": "application/json"}
    if config.LLM_API_KEY:
        headers["Authorization"] = f"Bearer {config.LLM_API_KEY}"

    last_error: Exception | None = None
    for attempt in range(_MAX_RETRIES + 1):
        try:
            resp = requests.post(
                f"{config.LLM_BASE_URL.rstrip('/')}/chat/completions",
                headers=headers,
                json=payload,
                timeout=60,
            )
            if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES:
                time.sleep(min(2**attempt, _MAX_BACKOFF_SECONDS))  # 1s, 2s, 4s, 8s, capped at 20s
                continue
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            return _parse_json(content)
        except requests.RequestException as e:
            last_error = e
            if attempt < _MAX_RETRIES:
                time.sleep(min(2**attempt, _MAX_BACKOFF_SECONDS))
                continue
            raise LLMCallFailed(str(e)) from e

    raise LLMCallFailed(str(last_error))


def image_content_part(image_base64: str, mime_type: str) -> list[dict[str, Any]]:
    """Builds the multimodal `user` content list for complete()/complete_vision()."""
    return [{"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_base64}"}}]


def complete_vision(
    system: str,
    text: str,
    image_base64: str,
    mime_type: str,
    json_schema: dict | None = None,
    model: str | None = None,
) -> dict[str, Any]:
    """Convenience wrapper: text + one image, in that order, as the user turn."""
    content = [{"type": "text", "text": text}] + image_content_part(image_base64, mime_type)
    return complete(system, content, json_schema, model or config.LLM_VISION_MODEL)


def _parse_json(content: str) -> dict[str, Any]:
    content = content.strip()
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    # best-effort repair: pull out the first {...} block
    start = content.find("{")
    end = content.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(content[start : end + 1])
        except json.JSONDecodeError:
            pass
    raise LLMCallFailed(f"Could not parse JSON from LLM response: {content[:200]!r}")
