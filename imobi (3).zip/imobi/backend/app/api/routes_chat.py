from __future__ import annotations

import base64

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.agents.chat_evaluate import evaluate_adhoc_design
from app.agents.orchestrator import handle_message
from app.db.session import get_session
from app.diagram.vision_extractor import VisionNotAvailable, extract_design_description
from app.ingestion.text_extractor import TextExtractionFailed, extract_text
from app.llm.client import LLMCallFailed

router = APIRouter(prefix="/chat", tags=["chat"])

_MAX_IMAGE_BYTES = 8 * 1024 * 1024  # 8MB
_MAX_TEXT_FILE_BYTES = 2 * 1024 * 1024  # 2MB
_ALLOWED_IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp", "image/gif"}


class ChatRequest(BaseModel):
    message: str


@router.post("")
def chat(req: ChatRequest):
    session = get_session()
    try:
        return handle_message(session, req.message)
    finally:
        session.close()


@router.post("/attach")
async def chat_attach(file: UploadFile = File(...), domain: str = Form("Information Security")):
    """Attach an architecture diagram image to the conversation: the Diagram
    Agent describes it, and that description is evaluated exactly like a
    typed design -- same retrieval, same Evaluation/Auditor Agents, same
    citation gate. No sample diagram exists in the dataset; this only ever
    runs against what a user actually uploads."""
    if file.content_type not in _ALLOWED_IMAGE_TYPES:
        raise HTTPException(400, f"Unsupported image type '{file.content_type}'. Use PNG, JPEG, WEBP, or GIF.")
    contents = await file.read()
    if len(contents) > _MAX_IMAGE_BYTES:
        raise HTTPException(400, "Image too large (max 8MB).")

    trace = [{"agent": "Diagram Agent", "action": f"Analyzing the attached image '{file.filename}'..."}]
    try:
        extracted = extract_design_description(base64.b64encode(contents).decode("ascii"), file.content_type, file.filename)
    except VisionNotAvailable as e:
        return {"intent": "diagram", "reply": str(e), "data": None, "citations": [], "trace": trace}
    except LLMCallFailed as e:
        return {
            "intent": "diagram",
            "reply": f"The vision model is temporarily unavailable ({e}), so I couldn't read this diagram. "
            "Please try again shortly, or describe the architecture as text instead.",
            "data": None,
            "citations": [],
            "trace": trace,
        }

    trace[0]["action"] = f"Described the attached diagram '{file.filename}' in plain language."

    session = get_session()
    try:
        result = evaluate_adhoc_design(session, extracted["title"], domain, extracted["description"], "chat_attach")
        return {
            "intent": "diagram",
            "reply": f"Here's what I saw in the diagram: {extracted['description']}\n\n{result['reply']}",
            "data": result["data"],
            "citations": result["citations"],
            "trace": trace + result["trace"],
        }
    finally:
        session.close()


class EvaluateTextRequest(BaseModel):
    title: str | None = None
    domain: str = "Information Security"
    description: str


@router.post("/evaluate-text")
def chat_evaluate_text(req: EvaluateTextRequest):
    """The 'describe your architecture' / 'upload a text file' path: evaluates
    the given text directly, rather than trying to match it against one of
    the sample designs the way a typed chat message asking to 'evaluate the
    X design' does."""
    if not req.description.strip():
        raise HTTPException(400, "Description is empty.")
    session = get_session()
    try:
        result = evaluate_adhoc_design(session, req.title or "Untitled design", req.domain, req.description, "chat_text")
        return {"intent": "evaluate", "reply": result["reply"], "data": result["data"], "citations": result["citations"], "trace": result["trace"]}
    finally:
        session.close()


@router.post("/attach-text-file")
async def chat_attach_text_file(file: UploadFile = File(...), domain: str = Form("Information Security")):
    """A design document attached as a file -- plain text/markdown is read
    directly, PDF goes through text_extractor.py. No vision call needed."""
    is_pdf = (file.content_type == "application/pdf") or file.filename.lower().endswith(".pdf")
    is_text = (file.content_type or "").startswith("text/") or file.filename.lower().endswith((".txt", ".md"))
    if not is_pdf and not is_text:
        raise HTTPException(400, "Only plain text files (.txt, .md) or PDFs (.pdf) are supported for direct upload.")
    contents = await file.read()
    if len(contents) > _MAX_TEXT_FILE_BYTES:
        raise HTTPException(400, "File too large (max 2MB).")
    try:
        text = extract_text(contents, file.filename, file.content_type)
    except TextExtractionFailed as e:
        raise HTTPException(400, str(e))

    session = get_session()
    try:
        result = evaluate_adhoc_design(session, file.filename, domain, text, "chat_file")
        return {"intent": "evaluate", "reply": result["reply"], "data": result["data"], "citations": result["citations"], "trace": result["trace"]}
    finally:
        session.close()
