from __future__ import annotations

import uuid

from fastapi import APIRouter, File, Header, HTTPException, UploadFile
from pydantic import BaseModel

from app import auth
from app.api.upload_utils import read_and_extract
from app.db.models import DesignDescription
from app.db.session import get_session
from app.evaluation.report import build_report

router = APIRouter(prefix="/evaluate", tags=["evaluate"])
admin_router = APIRouter(prefix="/evaluate/admin", tags=["evaluate", "admin"])


class EvaluateTextRequest(BaseModel):
    design_id: str | None = None  # if provided, evaluates a stored design (demo convenience)
    title: str | None = None
    domain: str
    description: str


@router.get("/designs")
def list_designs():
    session = get_session()
    try:
        rows = session.query(DesignDescription).all()
        return [
            {"id": d.id, "title": d.title, "domain": d.domain, "expected_outcome": d.expected_outcome}
            for d in rows
        ]
    finally:
        session.close()


@router.post("")
def evaluate_text(req: EvaluateTextRequest):
    session = get_session()
    try:
        if req.design_id:
            design = session.get(DesignDescription, req.design_id)
            if design is None:
                raise HTTPException(404, f"No design '{req.design_id}'")
        else:
            design = DesignDescription(
                id="__adhoc__",
                title=req.title or "Ad-hoc design",
                domain=req.domain,
                description=req.description,
            )
            session.merge(design)
            session.commit()
        return build_report(session, design.id)
    finally:
        session.close()


@router.get("/{design_id}")
def evaluate_stored_design(design_id: str):
    session = get_session()
    try:
        return build_report(session, design_id)
    except LookupError as e:
        raise HTTPException(404, str(e))
    finally:
        session.close()


class CreateDesignRequest(BaseModel):
    title: str
    domain: str
    description: str


@admin_router.post("/designs/extract-file")
async def extract_design_file(file: UploadFile = File(...), authorization: str | None = Header(default=None)):
    """Reads a .txt/.md/.pdf file and returns its extracted text so the Add
    Design form can populate the description field for the admin to review
    and edit -- this only extracts, it doesn't create the design; that's
    still a separate, explicit POST /designs so nothing gets saved from a
    file the admin hasn't looked at yet."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
    finally:
        session.close()

    text = await read_and_extract(file)
    return {"text": text, "suggested_title": file.filename.rsplit(".", 1)[0]}


@admin_router.post("/designs")
def create_design(req: CreateDesignRequest, authorization: str | None = Header(default=None)):
    """Adds a permanent, listed design (unlike the throwaway '__adhoc__' one
    evaluate_text() overwrites on every ad-hoc call) so it shows up in
    /evaluate/designs -- and therefore in the Evaluation Report picker --
    from here on, exactly like one of the dataset's own sample designs."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
        if not req.title.strip() or not req.description.strip():
            raise HTTPException(400, "Title and description are required.")
        design = DesignDescription(
            id=f"DSN-{uuid.uuid4().hex[:8]}",
            title=req.title,
            domain=req.domain,
            description=req.description,
        )
        session.add(design)
        session.commit()
        return {"id": design.id, "title": design.title, "domain": design.domain, "expected_outcome": None}
    finally:
        session.close()
