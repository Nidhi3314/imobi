"""
Auditor Agent: an independent second pass that critiques the Evaluation
Agent's output before it's shown to anyone. This is the "reasons about
quality" layer -- it can catch subtler problems (an evidence quote that
technically appears in the text but doesn't actually support the verdict)
that the purely mechanical citation_gate below can't. It sits above the
citation gate, not instead of it: the gate is what makes the "no ungrounded
verdicts" rule non-negotiable even if this agent is wrong or unavailable.
"""
from __future__ import annotations

import logging

from app.db.models import DesignDescription, Guardrail
from app.llm import client as llm_client

logger = logging.getLogger("guardrailiq")

_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "approved": {"type": "boolean"},
        "audit_note": {"type": "string"},
    },
    "required": ["approved"],
}

_SYSTEM_PROMPT = (
    "You are the Auditor Agent in GuardrailIQ. You are given a verdict the Evaluation "
    "Agent produced (Compliant/Non-compliant/Gap), the evidence quote it cited, the "
    "design text, and the guardrail text. Critique it: does the evidence quote "
    "actually appear in the design text, and does it actually support the verdict "
    "(not overreaching beyond what the design says)? Set approved=false if the "
    "citation is fabricated, doesn't support the verdict, or the verdict overreaches "
    "what the design actually states. Output only the JSON object described by the "
    "schema."
)

_BATCH_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "results": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "guardrail_id": {"type": "string"},
                    "approved": {"type": "boolean"},
                    "audit_note": {"type": "string"},
                },
                "required": ["guardrail_id", "approved"],
            },
        },
    },
    "required": ["results"],
}

_BATCH_SYSTEM_PROMPT = (
    "You are the Auditor Agent in GuardrailIQ. You are given a list of verdicts the "
    "Evaluation Agent produced for one design, each against a different guardrail, "
    "with the evidence quote cited for each. For EACH one, critique it: does the "
    "evidence quote actually appear in the design text, and does it actually support "
    "the verdict (not overreaching beyond what the design says)? Set approved=false "
    "for any item where the citation is fabricated, doesn't support the verdict, or "
    "the verdict overreaches what the design actually states. Return one result per "
    "guardrail_id given, in the same order. Output only the JSON object described by "
    "the schema."
)


def _deterministic_check(design: DesignDescription, verdict: dict) -> tuple[bool, str]:
    quote = (verdict.get("evidence_quote") or "").strip()
    if verdict.get("verdict") == "Gap":
        return True, "Gap verdicts carry no evidence claim, nothing to audit."
    if not quote:
        return False, "Non-Gap verdict with no evidence quote -- cannot audit, rejecting."
    normalized_design = " ".join((design.description or "").split()).lower()
    normalized_quote = " ".join(quote.split()).lower()
    if normalized_quote not in normalized_design:
        return False, "Evidence quote does not appear verbatim in the design text -- likely fabricated."
    return True, "Evidence quote verified present in design text."


def audit(design: DesignDescription, guardrail: Guardrail, verdict: dict) -> dict:
    ok, note = _deterministic_check(design, verdict)
    if not ok:
        return {"approved": False, "audit_note": note}

    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Design text:\n{design.description}\n\n"
                f"Guardrail text:\n{guardrail.statement}\n\n"
                f"Evaluation Agent's verdict: {verdict.get('verdict')}\n"
                f"Evidence quote cited: {verdict.get('evidence_quote')}"
            )
            result = llm_client.complete(_SYSTEM_PROMPT, user_prompt, _JSON_SCHEMA)
            return {
                "approved": bool(result.get("approved", False)),
                "audit_note": result.get("audit_note", ""),
            }
        except Exception as e:
            logger.warning("Auditor Agent: LLM call failed for guardrail %s, deterministic check stands: %s", guardrail.id, e)

    return {"approved": True, "audit_note": note}


def audit_batch(design: DesignDescription, items: list[tuple[Guardrail, dict]]) -> dict[str, dict]:
    """Same contract as audit(), batched into one LLM call for every item that
    passes the deterministic check -- an evaluate request can shortlist
    dozens of guardrails, and a per-guardrail audit call on top of the
    per-guardrail evaluation call doubled the quota pressure that was
    pushing real requests into the heuristic fallback."""
    results: dict[str, dict] = {}
    llm_candidates: list[tuple[Guardrail, dict]] = []

    for guardrail, verdict in items:
        ok, note = _deterministic_check(design, verdict)
        if not ok:
            results[guardrail.id] = {"approved": False, "audit_note": note}
        elif not llm_client.is_configured():
            results[guardrail.id] = {"approved": True, "audit_note": note}
        else:
            llm_candidates.append((guardrail, verdict))

    if not llm_candidates:
        return results

    try:
        block = "\n\n".join(
            f"guardrail_id: {g.id}\nguardrail text: {g.statement}\nverdict: {v.get('verdict')}\n"
            f"evidence quote cited: {v.get('evidence_quote')}"
            for g, v in llm_candidates
        )
        user_prompt = f"Design text:\n{design.description}\n\nVerdicts to audit ({len(llm_candidates)} total):\n\n{block}"
        result = llm_client.complete(_BATCH_SYSTEM_PROMPT, user_prompt, _BATCH_JSON_SCHEMA)
        by_id = {item.get("guardrail_id"): item for item in result.get("results", []) if item.get("guardrail_id")}
        for guardrail, verdict in llm_candidates:
            item = by_id.get(guardrail.id)
            if item:
                results[guardrail.id] = {
                    "approved": bool(item.get("approved", False)),
                    "audit_note": item.get("audit_note", ""),
                }
            else:
                logger.warning("Auditor Agent: batch response missing guardrail %s, deterministic check stands.", guardrail.id)
                results[guardrail.id] = {"approved": True, "audit_note": "Evidence quote verified present in design text."}
    except Exception as e:
        logger.warning(
            "Auditor Agent: batch LLM call failed, deterministic check stands for all %d items: %s",
            len(llm_candidates), e,
        )
        for guardrail, verdict in llm_candidates:
            results[guardrail.id] = {"approved": True, "audit_note": "Evidence quote verified present in design text."}

    return results
