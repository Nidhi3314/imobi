"""
Shared "evaluate this new ad-hoc design and shape it as a chat reply" path,
used by every way a design can enter the conversation: a typed message that
matches a *known* design (orchestrator.py), a freshly typed/uploaded design
that isn't in the dataset at all (routes_chat.py's /evaluate-text), or an
uploaded architecture diagram image (routes_chat.py's /attach, after the
Diagram Agent turns it into text). One code path means the trust chain
(Retriever -> Evaluation Agent -> Auditor Agent -> Citation Gate -> Chat
Composer) is identical regardless of how the design text arrived.
"""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.agents.chat_composer import compose_evaluate_reply
from app.db.models import DesignDescription
from app.evaluation.report import build_report


def evaluate_adhoc_design(session: Session, title: str, domain: str, description: str, id_prefix: str) -> dict:
    design_id = f"__{id_prefix}_{uuid.uuid4().hex[:8]}__"
    design = DesignDescription(id=design_id, title=title, domain=domain, description=description)
    session.add(design)
    session.commit()

    report = build_report(session, design_id)
    mode_summary = report.get("analysis_mode_summary", {"mode": "heuristic"})
    eval_action = {
        "llm": "Produced a verdict per candidate guardrail via LLM-backed reasoning.",
        "heuristic": "LLM unavailable (rate-limited or not configured) -- fell back to deterministic keyword analysis.",
        "mixed": "Produced verdicts via LLM-backed reasoning, with a deterministic keyword fallback for the guardrails the LLM call missed.",
    }[mode_summary["mode"]]

    trace = [
        {"agent": "Retriever", "action": "Ranked all guardrails by relevance to this design."},
        {"agent": "Evaluation Agent", "action": eval_action},
        {"agent": "Auditor Agent", "action": "Independently re-checked each verdict's evidence before it could be shown."},
        {"agent": "Citation Gate", "action": "Verified every citation against the database."},
        {"agent": "Chat Composer", "action": "Wrote a plain-language summary of the findings."},
    ]
    reply = compose_evaluate_reply(design, report["findings"], report.get("overall_verdict"), mode_summary)
    citations = [
        {"guardrail_id": f["guardrail_id"], "clause_id": f["clause_id"], "label": f["verdict"]}
        for f in report["findings"]
        if f["clause_id"]
    ]
    return {"data": report, "trace": trace, "reply": reply, "citations": citations}
