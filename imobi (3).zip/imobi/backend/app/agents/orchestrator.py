"""
Orchestrator: the chat entry point. Routes a natural-language message to
whichever specialist agent/endpoint it needs. Intent routing is simple
rule-based keyword matching for now -- easy to upgrade to an LLM-routed
classifier later behind the same function signature, so nothing downstream
has to change.

Every response carries a `trace`: an ordered list of the actual agent
stages that ran to produce it. This isn't cosmetic instrumentation added
after the fact -- it names the real pipeline stages in report.py /
decision_store.py / retriever.py that the request went through, so the
frontend's agent-workflow view reflects what genuinely happened, not a
fabricated animation.

`reply` is a composed natural-language answer (see chat_composer.py) and
`citations` is built directly from the same structured records the reply
was composed from -- never parsed out of the model's prose. That split is
deliberate: the citations list stays exactly as trustworthy as the
underlying data even if the LLM's wording is loose, because the UI never
has to trust the model to get an ID right.
"""
from __future__ import annotations

import random
import re

from sqlalchemy.orm import Session

from app.agents.chat_composer import compose_evaluate_reply, compose_search_reply
from app.conflicts.decision_store import list_tickets
from app.db.models import DesignDescription, Guardrail
from app.evaluation.report import build_report
from app.knowledge.embeddings import TextSimilarityIndex

# Small talk never touches the LLM or retrieval -- it's not a governance
# question, so there's nothing to reason about or cite. Matched first and
# only on a short, whole-message match so it doesn't misfire on a real
# question that happens to start with "hi" as part of a longer sentence.
_GREETING_RE = re.compile(
    r"^\s*(hey+|hi+|hello+|howdy|yo|sup|good\s+(morning|afternoon|evening))[\s!.,]*$",
    re.IGNORECASE,
)
_HOW_ARE_YOU_RE = re.compile(
    r"^\s*(how'?s?\s+it\s+going|how\s+are\s+you|what'?s?\s+up|how\s+do\s+you\s+do)[\s?!.,]*$",
    re.IGNORECASE,
)
_THANKS_RE = re.compile(r"^\s*(thanks|thank\s+you|thx|ty|cheers)[\s!.,]*$", re.IGNORECASE)

_GREETING_REPLIES = [
    "Hey! Ask me to search guardrails, evaluate a design, or check open conflicts whenever you're ready.",
    "Hi there. I'm ready when you are -- try asking about a guardrail, a design, or open conflicts.",
    "Hello! I can search guardrails, evaluate a design description, or list open conflicts.",
]
_HOW_ARE_YOU_REPLIES = [
    "Doing well, thanks for asking. What would you like to check -- a guardrail, a design, or open conflicts?",
    "All good on my end. Ready to search guardrails, evaluate a design, or check conflicts whenever you are.",
]
_THANKS_REPLIES = [
    "You're welcome! Anything else you'd like to check?",
    "Happy to help. Let me know if you want to search more guardrails or evaluate another design.",
]

_EVALUATE_RE = re.compile(r"\bevaluate\b|\bcompliance check\b|\bassess\b", re.IGNORECASE)
_CONFLICT_RE = re.compile(r"\bconflicts?\b|\bconflicting\b|\bdisagree\b", re.IGNORECASE)

def _small_talk_reply(message: str) -> str | None:
    if _GREETING_RE.match(message):
        return random.choice(_GREETING_REPLIES)
    if _HOW_ARE_YOU_RE.match(message):
        return random.choice(_HOW_ARE_YOU_REPLIES)
    if _THANKS_RE.match(message):
        return random.choice(_THANKS_REPLIES)
    return None


def handle_message(session: Session, message: str) -> dict:
    small_talk = _small_talk_reply(message)
    if small_talk is not None:
        return {
            "intent": "smalltalk",
            "reply": small_talk,
            "data": [],
            "citations": [],
            "trace": [{"agent": "Orchestrator", "action": "Recognized this as small talk -- answered directly, no retrieval or LLM call."}],
        }

    if _CONFLICT_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'conflicts' from the message text."},
            {"agent": "Conflict Agent", "action": "Read open tickets from the Conflict Desk queue."},
        ]
        tickets = list_tickets(session, status="open")
        if not tickets:
            return {"intent": "conflicts", "reply": "No open conflicts right now.", "data": [], "citations": [], "trace": trace}
        citations = []
        for t in tickets:
            citations.append({"guardrail_id": t.guardrail_id_a, "label": f"{t.id} - Side A"})
            citations.append({"guardrail_id": t.guardrail_id_b, "label": f"{t.id} - Side B"})
        return {
            "intent": "conflicts",
            "reply": (
                f"There {'is' if len(tickets) == 1 else 'are'} {len(tickets)} open conflict ticket"
                f"{'' if len(tickets) == 1 else 's'} awaiting a human decision in the Conflict Desk. "
                "Each pits two guardrails against each other on the same requirement -- see the citations below "
                "for both sides."
            ),
            "data": [
                {"id": t.id, "metric": t.metric, "rationale": t.rationale, "status": t.status}
                for t in tickets
            ],
            "citations": citations,
            "trace": trace,
        }

    if _EVALUATE_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'evaluate' from the message text."},
        ]
        designs = session.query(DesignDescription).all()
        if not designs:
            return {"intent": "evaluate", "reply": "No designs are loaded yet.", "data": [], "citations": [], "trace": trace}
        idx = TextSimilarityIndex([d.description for d in designs] + [message])
        sim = idx.pairwise_similarity()
        best_i = max(range(len(designs)), key=lambda i: sim[-1, i])
        design = designs[best_i]
        trace.append({"agent": "Orchestrator", "action": f"Matched the message to design '{design.id}' ({design.title})."})
        trace.append({"agent": "Retriever", "action": "Ranked all guardrails by relevance to this design (domain-boosted similarity)."})
        report = build_report(session, design.id)
        mode_summary = report.get("analysis_mode_summary", {"mode": "heuristic"})
        eval_action = {
            "llm": "Produced a verdict per candidate guardrail via LLM-backed reasoning.",
            "heuristic": "LLM unavailable (rate-limited or not configured) -- fell back to deterministic keyword analysis.",
            "mixed": "Produced verdicts via LLM-backed reasoning, with a deterministic keyword fallback for the guardrails the LLM call missed.",
        }[mode_summary["mode"]]
        trace.append({"agent": "Evaluation Agent", "action": eval_action})
        trace.append({"agent": "Auditor Agent", "action": "Independently re-checked each verdict's evidence before it could be shown."})
        trace.append({"agent": "Citation Gate", "action": "Verified every citation against the database; rejects are shown as Unverified."})
        trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language summary of the findings above."})
        reply = compose_evaluate_reply(design, report["findings"], report.get("overall_verdict"), mode_summary)
        citations = [
            {"guardrail_id": f["guardrail_id"], "clause_id": f["clause_id"], "label": f["verdict"]}
            for f in report["findings"]
            if f["clause_id"]
        ]
        return {
            "intent": "evaluate",
            "reply": reply,
            "data": report,
            "citations": citations,
            "trace": trace,
        }

    trace = [
        {"agent": "Orchestrator", "action": "No 'evaluate' or 'conflict' intent detected -- treated as a guardrail search."},
        {"agent": "Retriever", "action": "Ranked all guardrails by text similarity to the message."},
    ]
    guardrails = session.query(Guardrail).all()
    if not guardrails:
        return {"intent": "search", "reply": "No guardrails are loaded yet.", "data": [], "citations": [], "trace": trace}
    idx = TextSimilarityIndex([g.statement for g in guardrails] + [message])
    sim = idx.pairwise_similarity()[-1][:-1]
    ranked = sorted(zip(guardrails, sim), key=lambda p: p[1], reverse=True)[:5]
    ranked = [(g, s) for g, s in ranked if s > 0]
    trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language summary of the matches above."})
    reply = compose_search_reply(message, ranked)
    citations = [{"guardrail_id": g.id, "label": g.severity} for g, _ in ranked]
    return {
        "intent": "search",
        "reply": reply,
        "data": [
            {"id": g.id, "statement": g.statement, "severity": g.severity, "domain": g.domain, "similarity": round(float(s), 3)}
            for g, s in ranked
        ],
        "citations": citations,
        "trace": trace,
    }
