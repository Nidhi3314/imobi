# CompliX

An AI-powered platform that turns scattered governance documents into a structured,
traceable guardrail model, then evaluates design descriptions against it — every
finding (compliant, non-compliant, or gap) citing the exact guardrail and source
clause it came from. No citation, no verdict.

Built for the GuardrailIQ Challenge, with a domain focus on **Information Security**.

## Why this shape

The fixed, judged requirement is trust and traceability, not any particular
technique — the guide explicitly says a modified copy of the dataset will be used for
judging, so nothing here matches on sample IDs. Everything is driven by meaning:
domain labels, text similarity, and normalized numeric values, never a literal
`KG-xxxx` or `CL-xxxx` string.

The **Conflict Desk** is the flagship feature: cross-document conflicts (e.g. two
policies stating different log-retention periods) are surfaced with a rationale and an
impact analysis, and a human reviewer explicitly approves one side, approves the
other, or keeps it open — the platform never silently picks a value. Every decision a
reviewer makes becomes learned precedent: the Conflict Agent cites it the next time a
structurally similar conflict shows up, even against a completely different (e.g.
re-uploaded, re-IDed) copy of the dataset. This is deliberately a multi-agent design
(Extraction, Dedup, Conflict, Evaluation, Auditor, Precedent, and an Orchestrator that
routes chat messages to the right one), reflecting this year's agentic-platforms
theme, layered on top of a deterministic citation gate that can't be argued out of the
"no ungrounded verdicts" rule.

## Three apps, one backend

- **`frontend/`** — the main app (Dashboard, Chat, Guardrail Explorer, Conflict Desk
  read-only view, Evaluation Report, Judge Mode). Anyone can register a CompliX **User
  Console** account here (name + email, no special rights) for a personalized chat.
- **`admin-frontend/`** — a separate **Admin Console** app, deliberately isolated on
  its own port. This is the only place Conflict Desk tickets actually get decided —
  reviewers register/sign in here, and every decision is attributed to their account.
- **`backend/`** — the FastAPI service both apps talk to.

## Architecture

```
Excel workbook (Documents, Clauses, Design_Descriptions)
        │
        ▼
 Extraction Agent  ──▶  Dedup Agent  ──▶  Orphan Agent  ──▶  Conflict Agent
 (clause → draft         (merge near-       (validate every    (flag cross-doc value
  guardrail record)       duplicates,        source clause/      conflicts; consults
                          union sources)      doc reference)      Precedent Agent;
                                                                    opens a ticket)
        │
        ▼
   SQLite: documents / clauses / guardrails / guardrail_sources /
           guardrail_relationships / conflict_tickets / design_descriptions /
           users / admin_users (+ their sessions)
        │
        ▼
 Evaluation Agent (per design: retrieve candidates → verdict + evidence)
        │
        ▼
 Auditor Agent (independent critique)  ──▶  Citation Gate (deterministic backstop)
        │
        ▼
 Chat Composer (writes the answer in prose; citations come straight from the
 structured records above, never parsed out of that prose)
        │
        ▼
 FastAPI (/guardrails, /evaluate, /conflicts, /ingest/upload, /chat, /user, /admin, /debug)
        │
        ▼
 React: main app (:5173) + Admin Console (:5174)
```

## Running it

### 1. Get the dataset

This repo does **not** include the hackathon-provided dataset or participant guide —
they're synthetic materials for the challenge, not ours to redistribute. Place your
own copies in the repo root before starting the backend:

```
CompliX/
  AI-Powered Enterprise Compliance Intelligence System_GuardrailIQ_Dataset_v2.xlsx
  backend/
  frontend/
  admin-frontend/
```

(Or point `GUARDRAILIQ_DATASET_PATH` at wherever you keep it.) Any workbook with the
same sheet shapes (`Governance_Documents`, `Clauses`, `Design_Descriptions`) works —
that's what Judge Mode's live-upload exists to prove.

### 2. Backend
```
cd backend
pip install -r requirements.txt
cp .env.example .env   # fill in an LLM key if you have one -- optional, see below
python -m uvicorn app.main:app --reload
```
Runs on `http://localhost:8000`. On startup it ingests the dataset from step 1 and
runs the full pipeline automatically.

**LLM (optional but recommended):** without one configured, every agent falls back to
a deterministic regex/lexical heuristic (the guide explicitly allows an LLM-free
approach) — the pipeline still runs end-to-end and correctly catches the sample
dataset's seeded duplicate/conflict scenarios. `.env` (git-ignored) takes:
```
GUARDRAILIQ_LLM_BASE_URL=<your OpenAI-compatible chat-completions base URL>
GUARDRAILIQ_LLM_API_KEY=<key>
GUARDRAILIQ_LLM_MODEL=<model name>
```
Tested against Google Gemini's OpenAI-compatibility layer
(`https://generativelanguage.googleapis.com/v1beta/openai`, model `gemini-2.5-flash`)
as a placeholder during development. Swapping in another gateway is a one-file change
(`backend/app/llm/client.py`).

### 3. Main app
```
cd frontend
npm install
npm run dev
```
Runs on `http://localhost:5173`.

### 4. Admin Console
```
cd admin-frontend
npm install
npm run dev
```
Runs on `http://localhost:5174`. Register an account here to decide Conflict Desk
tickets — this is a separate identity from the main app's User Console.

Both frontends default to a backend at `localhost:8000` — set `VITE_API_BASE_URL` (and
`VITE_ADMIN_CONSOLE_URL` in `frontend/`) if that's not where it's running.

### Tests
```
cd backend
python -m pytest tests/ -v
```
Covers dedup (merges true duplicates, preserves all sources, doesn't merge unrelated
clauses or cross-domain), conflict detection (cross-domain conflicts, no false
positives from a shared verb family alone, identical values aren't conflicts), orphan
detection, the citation gate (rejects fabricated guardrail/clause IDs, rejects broken
references, passes real citations through), precedent learning, the ingest-reset
regression (a re-ingested workbook fully replaces the previous one instead of
accumulating), and User/Admin account isolation.

## Assumptions

- The provided `Guardrails` sheet is treated as a **sample target schema**, not ground
  truth to copy — guardrails are derived independently from `Clauses` so the system
  survives a workbook that doesn't ship a pre-built guardrail sheet at all.
- Embeddings use TF-IDF / stemmed content-word Jaccard overlap rather than a
  transformer model — a torch/transformers version conflict made
  `sentence-transformers` unusable in the dev environment, and classical NLP is
  explicitly an accepted approach per the guide. When an LLM is configured, it does the
  semantic heavy lifting instead; the lexical path is the fallback.
- Cross-document conflict detection is **not** domain-scoped, because the seeded
  retention conflict spans Information Security and Privacy documents — scoping to one
  domain would have structurally missed it.
- "Judge Mode" (`/ingest/upload`) runs the identical pipeline against any uploaded
  workbook matching the sheet shapes, live — used to demonstrate the system isn't
  hardcoded to the sample IDs. Every ingest fully replaces the previous one (Documents/
  Clauses/Designs/open tickets), except *decided* Conflict Desk tickets, which persist
  as learned precedent across dataset changes.
- All data used is the synthetic workbook provided for this challenge. No real,
  sensitive, or proprietary content was used.

## Disclosure

LLM/frameworks used: FastAPI, SQLAlchemy, scikit-learn (TF-IDF), React, and — when
configured — an OpenAI-compatible chat-completions LLM gateway (tested against Google
Gemini's compatibility layer). No agent framework (LangChain/CrewAI/etc.) — agents are
hand-rolled Python modules behind one shared `llm/client.py` seam.
