"""
Tests for both MCP directions:
- app/mcp/server.py: CompliX exposed as an MCP server. The @mcp.tool()
  decorator returns the original function unchanged, so these call the tool
  functions directly (bypassing the stdio protocol layer) against an
  in-memory test DB.
- app/mcp/client_manager.py: the backend's own agents calling out to
  *external* MCP servers. Unconfigured by default (GUARDRAILIQ_MCP_SERVERS
  unset), so these mostly verify the no-op fallback path -- the same
  contract llm_client.is_configured() has when no LLM is set up.
"""
import pytest

from app import config
from app.db.models import Clause, Document, Guardrail, GuardrailSource
from app.mcp import client_manager, runtime_servers, server


@pytest.fixture(autouse=True)
def _clear_runtime_servers():
    """runtime_servers holds its attached-integration state at module scope
    (see its own docstring on why -- in-memory, process-wide, never
    persisted), so tests that attach something must not leak it into the
    next test regardless of how they exit."""
    yield
    for provider in list(runtime_servers.connected_providers()):
        runtime_servers.detach(provider)


def _make_guardrail(session, id="GR-mcp-1", statement="Test requirement", domain="Information Security"):
    doc = Document(id=f"DOC-{id}", title=f"Policy {id}", domain=domain)
    clause = Clause(id=f"CL-{id}", clause_text=f"Clause for {id}", document_id=f"DOC-{id}")
    session.add_all([doc, clause])
    session.flush()

    gr = Guardrail(id=id, domain=domain, statement=statement, severity="Mandatory")
    session.add(gr)
    session.flush()
    session.add(GuardrailSource(guardrail_id=id, clause_id=f"CL-{id}", document_id=f"DOC-{id}"))
    session.commit()
    return gr


def test_server_list_guardrails_reuses_route_serialization(session, monkeypatch):
    _make_guardrail(session)
    monkeypatch.setattr(server, "get_session", lambda: session)
    monkeypatch.setattr(session, "close", lambda: None)  # keep the fixture's session open for the caller

    result = server.list_guardrails()

    assert len(result) == 1
    assert result[0]["id"] == "GR-mcp-1"
    assert result[0]["sources"] == [{"clause_id": "CL-GR-mcp-1", "document_id": "DOC-GR-mcp-1"}]


def test_server_get_guardrail_missing_returns_error_dict(session, monkeypatch):
    monkeypatch.setattr(server, "get_session", lambda: session)
    monkeypatch.setattr(session, "close", lambda: None)

    result = server.get_guardrail("GR-does-not-exist")

    assert "error" in result


def test_server_list_domains(session, monkeypatch):
    _make_guardrail(session, id="GR-mcp-2", domain="Privacy")
    monkeypatch.setattr(server, "get_session", lambda: session)
    monkeypatch.setattr(session, "close", lambda: None)

    assert server.list_domains() == ["Privacy"]


def test_client_manager_unconfigured_by_default():
    assert config.MCP_SERVERS == []
    assert client_manager.is_configured() is False
    assert client_manager.list_tools() == []


def test_client_manager_call_tool_rejects_unqualified_name():
    result = client_manager.call_tool("not_qualified", {})
    assert "Error" in result


def test_client_manager_call_tool_unknown_server(monkeypatch):
    monkeypatch.setattr(config, "MCP_SERVERS", [])
    result = client_manager.call_tool("some_server__some_tool", {})
    assert "Error" in result
    assert "some_server" in result


def test_runtime_servers_attach_detach_roundtrip():
    assert runtime_servers.connected_providers() == []
    assert runtime_servers.runtime_mcp_servers() == []

    runtime_servers.attach("jira", "https://team.atlassian.net/", "me@example.com", "tok-123")

    assert runtime_servers.connected_providers() == ["jira"]
    servers = runtime_servers.runtime_mcp_servers()
    assert len(servers) == 1
    assert servers[0]["name"] == "atlassian"
    assert servers[0]["command"] == "uvx"
    assert servers[0]["env"] == {
        "JIRA_URL": "https://team.atlassian.net",  # trailing slash stripped
        "JIRA_USERNAME": "me@example.com",
        "JIRA_API_TOKEN": "tok-123",
    }

    runtime_servers.detach("jira")
    assert runtime_servers.connected_providers() == []
    assert runtime_servers.runtime_mcp_servers() == []


def test_runtime_servers_combines_jira_and_confluence_into_one_server():
    runtime_servers.attach("jira", "https://team.atlassian.net", "me@example.com", "jira-tok")
    runtime_servers.attach("confluence", "https://team.atlassian.net/wiki", "me@example.com", "conf-tok")

    assert runtime_servers.connected_providers() == ["confluence", "jira"]
    servers = runtime_servers.runtime_mcp_servers()
    assert len(servers) == 1  # both providers -> one mcp-atlassian process
    env = servers[0]["env"]
    assert env["JIRA_API_TOKEN"] == "jira-tok"
    assert env["CONFLUENCE_API_TOKEN"] == "conf-tok"


def test_runtime_servers_rejects_unknown_provider():
    with pytest.raises(ValueError):
        runtime_servers.attach("slack", "https://x.com", "me@example.com", "tok")


def test_runtime_servers_rejects_missing_fields():
    with pytest.raises(ValueError):
        runtime_servers.attach("jira", "", "me@example.com", "tok")


def test_client_manager_reflects_runtime_attached_server():
    assert client_manager.is_configured() is False

    runtime_servers.attach("jira", "https://team.atlassian.net", "me@example.com", "tok-123")

    assert client_manager.is_configured() is True

    runtime_servers.detach("jira")
    assert client_manager.is_configured() is False
