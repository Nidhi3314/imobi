"""
Tests for architecture vision evaluation and generation.
"""
import base64
import json
from io import BytesIO

import pytest
from PIL import Image
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.db.models import (
    Clause,
    Document,
    Guardrail,
    GuardrailSource,
)
from app.generate.architecture_generator import (
    generate_reference_architecture,
    render_dot,
    render_mermaid,
)
from app.vision.architecture_agent import (
    ArchitectureFacts,
    ExposureSignal,
    extract_facts,
    evaluate_architecture,
)


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:")
    from app.db.models import Base

    Base.metadata.create_all(bind=engine)
    Session_local = sessionmaker(bind=engine)
    s = Session_local()
    yield s
    s.close()


def _create_guardrail(session, id="GR-1", statement="Test requirement", domain="Information Security", broken=False):
    """Helper to create a guardrail with sources."""
    doc = Document(id=f"DOC-{id}", title=f"Policy {id}", domain=domain)
    clause = Clause(id=f"CL-{id}", clause_text=f"Clause for {id}", document_id=f"DOC-{id}")
    session.add(doc)
    session.add(clause)
    session.flush()

    gr = Guardrail(
        id=id,
        domain=domain,
        statement=statement,
        severity="Mandatory",
        broken_reference=broken,
    )
    session.add(gr)
    session.flush()

    session.add(GuardrailSource(guardrail_id=id, clause_id=f"CL-{id}", document_id=f"DOC-{id}"))
    session.commit()
    return gr


def _create_png_image(text="test") -> bytes:
    """Create a minimal PNG image for testing."""
    img = Image.new("RGB", (100, 100), color="white")
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    return buffer.getvalue()


class TestExposureSignalDetection:
    """Test detection of security exposures in diagrams."""

    def test_detects_exposed_secret_in_ocr_text(self):
        """OCR text with an exposed API key triggers Critical severity."""
        ocr_text = "API endpoint configured with AKIA1234567890ABCDEF key"
        facts = extract_facts("", ocr_text)

        assert len(facts.exposure_signals) > 0
        signal = facts.exposure_signals[0]
        assert signal.signal == "exposed_secret"
        assert "AKIA" in signal.evidence_text

    def test_detects_default_credentials_in_ocr_text(self):
        """Default credentials detected as High/Critical finding."""
        ocr_text = "Admin console: username=admin password=admin"
        facts = extract_facts("", ocr_text)

        assert len(facts.exposure_signals) > 0
        signal = facts.exposure_signals[0]
        assert signal.signal == "default_creds"

    def test_detects_localhost_console_in_ocr_text(self):
        """Localhost/dev console in production architecture flagged."""
        ocr_text = "Production Environment: debug console on 127.0.0.1:9000"
        facts = extract_facts("", ocr_text)

        assert len(facts.exposure_signals) > 0
        signal = facts.exposure_signals[0]
        assert signal.signal == "localhost_console"

    def test_detects_plaintext_http(self):
        """Plaintext HTTP on external boundary flagged."""
        ocr_text = "External API calls use http://api.example.com for communication"
        facts = extract_facts("", ocr_text)

        assert len(facts.exposure_signals) > 0
        signal = facts.exposure_signals[0]
        assert signal.signal == "plaintext_http"

    def test_detects_debug_enabled(self):
        """Debug flag set to true in production flagged."""
        ocr_text = "Environment Config: FLASK_ENV=development, debug=true"
        facts = extract_facts("", ocr_text)

        assert len(facts.exposure_signals) > 0
        # Should detect debug_enabled
        signal_types = {s.signal for s in facts.exposure_signals}
        assert "debug_enabled" in signal_types

    def test_deterministic_extraction_with_no_ocr(self):
        """Deterministic path with empty OCR returns valid ArchitectureFacts."""
        facts = extract_facts("", "")
        assert isinstance(facts, ArchitectureFacts)
        assert facts.exposure_signals == []


class TestArchitectureEvaluation:
    """Test evaluation of architectures against guardrails."""

    def test_exposed_secret_in_diagram_triggers_non_compliant(self, session):
        """Diagram with exposed API key → Non-compliant verdict citing guardrail."""
        # Create a "no exposed secrets" guardrail
        _create_guardrail(
            session,
            id="GR-secret",
            statement="API keys and secrets must never be exposed in architecture diagrams or logs",
            domain="Information Security",
        )

        # Architecture with exposed secret
        ocr_text = "Config: API_KEY=AIza1234567890abcdefghijklmnopqr shown in diagram"
        facts = extract_facts("", ocr_text)

        # Evaluate
        result = evaluate_architecture(facts, session)

        assert result["summary"]["overall"] in ["non_compliant", "gap", "mixed"]
        # Should have at least one result
        assert len(result["results"]) > 0

        # Find the non-compliant result
        non_compliant = [r for r in result["results"] if r["verdict"] == "Non-compliant"]
        if non_compliant:
            finding = non_compliant[0]
            assert finding["guardrail_id"] is not None
            assert finding["severity"] in ["Critical", "High", "Medium", "Low"]
            # Citation should be grounded
            assert finding["source"]["clause_ref"] is not None or finding["source"]["document"] is not None

    def test_localhost_console_flagged_as_high_severity(self, session):
        """Localhost console in production architecture → High NON_COMPLIANT."""
        _create_guardrail(
            session,
            id="GR-no-localhost",
            statement="Development consoles and localhost addresses must not appear in production architecture",
            domain="Information Security",
        )

        ocr_text = "Production Arch: Admin console runs on localhost:8080 for operations"
        facts = extract_facts("", ocr_text)

        result = evaluate_architecture(facts, session)

        non_compliant = [r for r in result["results"] if r["verdict"] == "Non-compliant"]
        if non_compliant:
            finding = non_compliant[0]
            assert finding["severity"] == "High"

    def test_clean_architecture_returns_compliant_or_empty(self, session):
        """Clean architecture with no exposure signals → no fabricated findings."""
        _create_guardrail(
            session,
            id="GR-auth",
            statement="All external access must require authentication",
            domain="Information Security",
        )

        ocr_text = "Gateway → API (HTTPS authenticated) → Database (encrypted)"
        facts = extract_facts("", ocr_text)

        result = evaluate_architecture(facts, session)

        # Should NOT fabricate Non-compliant findings
        non_compliant = [r for r in result["results"] if r["verdict"] == "Non-compliant"]
        # If no signals detected, non_compliant list should be empty or only real matches
        assert len(non_compliant) == 0 or all(
            "gateway" in r["design_evidence"].lower() for r in non_compliant
        )

    def test_unreadable_diagram_parts_recorded(self, session):
        """Unreadable/cropped diagram parts added to unreadable[] without guessing."""
        facts = ArchitectureFacts(
            components=[{"name": "API", "type": "service"}],
            unreadable=["Bottom-right corner cropped", "Text on arrow illegible"],
        )

        result = evaluate_architecture(facts, session)

        # Should record unreadable parts, not make up verdicts for them
        assert result.get("unevaluated_note") or len(result["results"]) <= 1

    def test_citation_gate_validates_all_findings(self, session):
        """Every finding must pass citation gate with real guardrail_id + clause."""
        _create_guardrail(
            session,
            id="GR-real",
            statement="Secrets must be encrypted",
            domain="Information Security",
        )

        ocr_text = "Database password: dbpass123 hardcoded"
        facts = extract_facts("", ocr_text)

        result = evaluate_architecture(facts, session)

        # All results should have citation_gate_passed set
        for finding in result["results"]:
            assert "citation_gate_passed" in finding
            # If verdict is Non-compliant or Gap, a real guardrail must exist
            if finding["verdict"] in ["Non-compliant", "Gap"]:
                # Check that the cited guardrail actually exists
                if finding.get("guardrail_id"):
                    gr = session.get(Guardrail, finding["guardrail_id"])
                    assert gr is not None, f"Cited guardrail {finding['guardrail_id']} does not exist"


class TestArchitectureGeneration:
    """Test generation of compliant architectures from guardrails."""

    def test_generate_with_no_guardrails_returns_default_template(self):
        """When no guardrails provided, return secure default template."""
        spec = generate_reference_architecture("Simple REST API")

        assert spec["title"] is not None
        assert len(spec["nodes"]) > 0
        assert len(spec["edges"]) > 0
        assert len(spec["controls"]) > 0

    def test_generated_architecture_has_citation_structure(self, session):
        """Every control in generated architecture references relevant guardrails."""
        _create_guardrail(
            session,
            id="GR-encrypt",
            statement="All data must be encrypted at rest using AES-256",
            domain="Information Security",
        )
        _create_guardrail(
            session,
            id="GR-auth",
            statement="All access must be authenticated via MFA",
            domain="Information Security",
        )

        spec = generate_reference_architecture("Payment processing system", session=session)

        # Each control should have satisfies field (even if empty)
        for control in spec.get("controls", []):
            assert "satisfies" in control
            assert isinstance(control["satisfies"], list)

    def test_unvalidated_citations_demoted_to_baseline_choices(self, session):
        """Citations to non-existent guardrails → moved to baseline_choices."""
        guardrails = [
            {
                "guardrail_id": "GR-real",
                "statement": "Encryption required",
                "domain": "Information Security",
                "normalized_value": None,
                "sources": [],
            }
        ]

        spec = generate_reference_architecture("System", guardrails=guardrails, session=session)

        # Spec should not cite non-existent guardrails
        for component_list in [spec.get("nodes", []), spec.get("edges", []), spec.get("controls", [])]:
            for component in component_list:
                for citation in component.get("satisfies", []):
                    # All cited guardrails must be in the provided set
                    assert citation["guardrail_id"] in {g["guardrail_id"] for g in guardrails}

    def test_render_mermaid_produces_valid_syntax(self):
        """Mermaid rendering produces syntactically valid diagram."""
        spec = generate_reference_architecture("Test system")
        diagram = render_mermaid(spec)

        assert "graph TB" in diagram or "digraph" in diagram
        # Should have nodes and edges
        assert len(diagram.split("\n")) > 3

    def test_render_dot_produces_graphviz_syntax(self):
        """DOT rendering produces valid Graphviz syntax."""
        spec = generate_reference_architecture("Test system")
        diagram = render_dot(spec)

        assert "digraph" in diagram
        assert "{" in diagram
        assert "}" in diagram

    def test_generated_spec_json_serializable(self):
        """Generated spec is JSON-serializable (no numpy, datetime, etc.)."""
        spec = generate_reference_architecture("Test system")

        try:
            json_str = json.dumps(spec)
            parsed = json.loads(json_str)
            assert parsed["title"] is not None
        except (TypeError, ValueError) as e:
            pytest.fail(f"Generated spec not JSON-serializable: {e}")


class TestArchitectureFactsQueryText:
    """Test that ArchitectureFacts flatten correctly for retrieval."""

    def test_as_query_text_includes_all_fields(self):
        """as_query_text() produces a query string suitable for retrieval."""
        facts = ArchitectureFacts(
            components=[{"name": "API Gateway", "type": "gateway"}],
            data_stores=[{"name": "User DB", "location": "cloud"}],
            identity_flows=[{"component": "API", "auth_method": "oauth2"}],
            data_residency="us-only",
            exposure_signals=[ExposureSignal(signal="plaintext_http", evidence_text="http://api", where="gateway")],
        )

        query = facts.as_query_text()

        assert "API Gateway" in query or "API" in query
        assert "User DB" in query or "DB" in query
        assert "oauth2" in query
        assert "us-only" in query
        assert "plaintext_http" in query

    def test_to_dict_preserves_exposure_signals(self):
        """to_dict() serializes exposure signals correctly."""
        signal = ExposureSignal(signal="exposed_secret", evidence_text="AKIA...", where="config")
        facts = ArchitectureFacts(exposure_signals=[signal])

        d = facts.to_dict()

        assert len(d["exposure_signals"]) == 1
        assert d["exposure_signals"][0]["signal"] == "exposed_secret"
        assert d["exposure_signals"][0]["evidence_text"] == "AKIA..."


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_ocr_text_does_not_crash(self):
        """Empty OCR text handled gracefully."""
        facts = extract_facts("", "")
        assert isinstance(facts, ArchitectureFacts)
        assert facts.components == []

    def test_generate_with_empty_brief_returns_default(self):
        """Empty brief falls back to default template."""
        spec = generate_reference_architecture("")
        assert spec["nodes"] is not None

    def test_evaluate_with_no_guardrails_returns_empty_results(self, session):
        """Architecture evaluated when no guardrails exist returns empty results."""
        facts = ArchitectureFacts()
        result = evaluate_architecture(facts, session)

        assert result["summary"]["overall"] == "compliant"
        assert result["summary"]["counts"]["non_compliant"] == 0
