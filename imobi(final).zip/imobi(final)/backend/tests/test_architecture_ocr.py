"""
Tests for how OCR text is wired into diagram analysis:
- architecture_agent.extract_facts() unions the OCR-only deterministic
  exposure/label detection into whatever the vision LLM returned, and uses
  OCR as the sole signal when no LLM is configured.
- diagram/vision_extractor.extract_design_description() falls back to an
  OCR-derived description instead of hard-failing when no LLM is
  configured (or the LLM call fails), and still raises when there is truly
  no signal (no LLM and no OCR text) -- see VisionNotAvailable.

All LLM/OCR calls are monkeypatched so these run fast and don't depend on a
real Tesseract install or network access.
"""
import pytest

from app.diagram import vision_extractor
from app.llm import client as llm_client
from app.vision import architecture_agent, ocr_extractor


def test_extract_facts_computes_ocr_when_not_supplied(monkeypatch):
    monkeypatch.setattr(llm_client, "is_configured", lambda: False)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: "password=admin")

    facts = architecture_agent.extract_facts("ZmFrZQ==")  # base64("fake")

    assert any(s.evidence_text == "password=admin" for s in facts.exposure_signals)


def test_extract_facts_skips_ocr_when_caller_supplies_text(monkeypatch):
    calls = []
    monkeypatch.setattr(llm_client, "is_configured", lambda: False)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: calls.append(1) or "unused")

    architecture_agent.extract_facts("ZmFrZQ==", ocr_text="password=admin")

    assert calls == []  # OCR never invoked -- the caller-supplied text was used as-is


def test_extract_facts_unions_llm_and_ocr_exposure_signals(monkeypatch):
    """The LLM's own output misses a signal that regex over the OCR text
    would catch (e.g. an exact secret string) -- extract_facts should still
    surface it, not just what the LLM reported."""
    monkeypatch.setattr(llm_client, "is_configured", lambda: True)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: "admin:admin")

    def fake_complete_vision(system, text, image_base64, mime_type, json_schema=None, model=None):
        assert "admin:admin" in text  # OCR text was folded into the prompt as grounding
        return {
            "components": [{"name": "Web Server", "type": "api"}],
            "exposure_signals": [],  # LLM missed the default-creds string
        }

    monkeypatch.setattr(llm_client, "complete_vision", fake_complete_vision)

    facts = architecture_agent.extract_facts("ZmFrZQ==")

    assert facts.components == [{"name": "Web Server", "type": "api"}]
    assert any(s.signal == "default_creds" for s in facts.exposure_signals)


def test_vision_extractor_falls_back_to_ocr_when_llm_unconfigured(monkeypatch):
    monkeypatch.setattr(llm_client, "is_configured", lambda: False)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: "Auth Server\npassword=admin")

    result = vision_extractor.extract_design_description("ZmFrZQ==", "image/png", "diagram.png")

    assert "password=admin" in result["description"] or "default_creds" in result["description"]


def test_vision_extractor_falls_back_to_ocr_when_llm_call_fails(monkeypatch):
    monkeypatch.setattr(llm_client, "is_configured", lambda: True)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: "password=admin")

    def raise_failed(*args, **kwargs):
        raise llm_client.LLMCallFailed("rate limited")

    monkeypatch.setattr(llm_client, "complete_vision", raise_failed)

    result = vision_extractor.extract_design_description("ZmFrZQ==", "image/png", "diagram.png")
    assert result["description"]  # produced something instead of raising


def test_vision_extractor_raises_when_no_llm_and_no_ocr_signal(monkeypatch):
    monkeypatch.setattr(llm_client, "is_configured", lambda: False)
    monkeypatch.setattr(ocr_extractor, "extract_text_from_image", lambda image_bytes: "")

    with pytest.raises(vision_extractor.VisionNotAvailable):
        vision_extractor.extract_design_description("ZmFrZQ==", "image/png", "diagram.png")
