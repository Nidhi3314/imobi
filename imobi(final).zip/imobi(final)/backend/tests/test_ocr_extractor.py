"""
Tests for the OCR extraction seam (app/vision/ocr_extractor.py). The actual
text-reading tests are skipped when Tesseract isn't installed on the test
machine -- OCR is an optional, gracefully-degrading capability the same way
the LLM gateway is, so its tests shouldn't fail a CI box that never
installed the binary.
"""
import io

import pytest
from PIL import Image, ImageDraw

from app.vision import ocr_extractor

_HAS_TESSERACT = ocr_extractor.is_available()


def _render_text_image(text: str) -> bytes:
    img = Image.new("RGB", (700, 120), color="white")
    draw = ImageDraw.Draw(img)
    draw.text((10, 40), text, fill="black")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_is_available_returns_bool_without_raising():
    assert isinstance(ocr_extractor.is_available(), bool)


def test_extract_text_from_empty_bytes_returns_empty_string():
    assert ocr_extractor.extract_text_from_image(b"") == ""


def test_extract_text_from_garbage_bytes_degrades_gracefully():
    """Not a real image at all -- must return "", never raise, the same way
    a failed LLM call degrades to a heuristic rather than crashing."""
    assert ocr_extractor.extract_text_from_image(b"not a real image") == ""


@pytest.mark.skipif(not _HAS_TESSERACT, reason="Tesseract OCR is not installed on this machine")
def test_extract_text_reads_rendered_text():
    image_bytes = _render_text_image("localhost:8080")
    text = ocr_extractor.extract_text_from_image(image_bytes)
    assert "localhost" in text.lower()


@pytest.mark.skipif(not _HAS_TESSERACT, reason="Tesseract OCR is not installed on this machine")
def test_extract_text_from_blank_image_is_empty_or_whitespace():
    img = Image.new("RGB", (200, 100), color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    text = ocr_extractor.extract_text_from_image(buf.getvalue())
    assert text.strip() == ""
