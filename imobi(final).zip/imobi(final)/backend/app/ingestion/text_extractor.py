"""
Extracts plain text from an uploaded design-document file -- .txt/.md need
nothing, .pdf goes through PyPDF2. No OCR: a scanned/image-only PDF will
come back with little or no text, which the caller treats as "not enough
information" the same way any other empty design description would be,
rather than fabricating a description.
"""
from __future__ import annotations

import io

from PyPDF2 import PdfReader


class TextExtractionFailed(RuntimeError):
    pass


def extract_text(contents: bytes, filename: str, content_type: str | None) -> str:
    is_pdf = (content_type == "application/pdf") or filename.lower().endswith(".pdf")
    if is_pdf:
        try:
            reader = PdfReader(io.BytesIO(contents))
            pages = [page.extract_text() or "" for page in reader.pages]
            text = "\n".join(pages).strip()
        except Exception as e:
            raise TextExtractionFailed(f"Could not read '{filename}' as a PDF: {e}") from e
        if not text:
            raise TextExtractionFailed(
                f"'{filename}' has no extractable text (it may be a scanned/image-only PDF)."
            )
        return text

    try:
        return contents.decode("utf-8")
    except UnicodeDecodeError as e:
        raise TextExtractionFailed(f"Could not read '{filename}' as UTF-8 text.") from e
