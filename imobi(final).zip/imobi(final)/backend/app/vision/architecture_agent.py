"""
Architecture Vision Agent: Extract facts from architecture diagrams and evaluate them
against governance guardrails with citation grounding.
"""
from __future__ import annotations

import base64
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy.orm import Session

from app.agents.citation_gate import gate_finding
from app.db.models import Clause, Document
from app.evaluation.retriever import retrieve_candidates
from app.llm import client as llm_client
from app.vision import ocr_extractor
from app.vision.prompts import ARCH_EVALUATION_PROMPT, VISION_EXTRACTION_PROMPT

logger = logging.getLogger("guardrailiq")

# Signal types and their default severity mappings for deterministic path
_SIGNAL_SEVERITY_MAP = {
    "exposed_secret": "Critical",
    "default_creds": "Critical",
    "public_datastore": "Critical",
    "no_auth": "Critical",
    "localhost_console": "High",
    "plaintext_http": "High",
    "debug_enabled": "Medium",
}

# Regex patterns for deterministic exposure detection (used when LLM unavailable).
# Order matters: _extract_facts_deterministic checks these in insertion order,
# and a string like "password=admin" matches both default_creds (specific:
# an actual key=value default) and exposed_secret (generic: the bare word
# "password") -- more specific patterns are listed first so the signal
# recorded is the more actionable one.
_EXPOSURE_PATTERNS = {
    "default_creds": re.compile(
        r"(admin\s*:\s*admin|root\s*:\s*root|password\s*=\s*changeme|password\s*=\s*['\"]?[a-z0-9]+['\"]?)",
        re.IGNORECASE,
    ),
    "exposed_secret": re.compile(
        r"(AKIA[0-9A-Z]{16}|AIza[A-Za-z0-9-_]{35}|\.env|api[_-]?key|api[_-]?token|"
        r"PRIVATE KEY|password|connection[_-]?string|secret[_-]?key|token|apiKey|"
        r"Bearer\s+[A-Za-z0-9\-_.]+)",
        re.IGNORECASE,
    ),
    "localhost_console": re.compile(
        r"(127\.0\.0\.1|localhost|0\.0\.0\.0|dev\s+console|debug\s+console)",
        re.IGNORECASE,
    ),
    "plaintext_http": re.compile(r"http://", re.IGNORECASE),
    "public_datastore": re.compile(
        r"(public\s+internet|exposed\s+(database|bucket|db|admin)|no\s+gateway)",
        re.IGNORECASE,
    ),
    "no_auth": re.compile(
        r"(0\.0\.0\.0/0|no\s+auth|allow\s+all|public\s+access|unauthenticated)",
        re.IGNORECASE,
    ),
    "debug_enabled": re.compile(
        r"(debug\s*=\s*true|FLASK_ENV\s*=\s*development|DEBUG|DEV_MODE)",
        re.IGNORECASE,
    ),
}


@dataclass
class ExposureSignal:
    """Detected security exposure in the architecture diagram."""

    signal: str  # signal type: exposed_secret, localhost_console, etc.
    evidence_text: str  # exact text from diagram
    where: str  # component or edge name


@dataclass
class ArchitectureFacts:
    """Extracted facts from an architecture diagram."""

    components: list[dict[str, str]] = field(default_factory=list)
    data_stores: list[dict[str, str]] = field(default_factory=list)
    trust_boundaries: list[dict[str, str]] = field(default_factory=list)
    network_paths: list[dict[str, str]] = field(default_factory=list)
    identity_flows: list[dict[str, str]] = field(default_factory=list)
    external_parties: list[dict[str, str]] = field(default_factory=list)
    data_residency: str = ""
    labels_text: list[str] = field(default_factory=list)
    unreadable: list[str] = field(default_factory=list)
    exposure_signals: list[ExposureSignal] = field(default_factory=list)

    def as_query_text(self) -> str:
        """Flatten facts into a text query for guardrail retrieval."""
        parts = []
        if self.components:
            parts.append(f"Components: {', '.join(c.get('name', '') for c in self.components)}")
        if self.data_stores:
            parts.append(f"Data stores: {', '.join(d.get('name', '') for d in self.data_stores)}")
        if self.network_paths:
            paths_str = ", ".join(
                "{} between {} and {}".format(
                    p.get("protocol", "unknown"),
                    p.get("from", ""),
                    p.get("to", ""),
                )
                for p in self.network_paths
            )
            parts.append(f"Network paths: {paths_str}")
        if self.identity_flows:
            identity_str = ", ".join(
                "{} for {}".format(
                    i.get("auth_method", "unknown"),
                    i.get("component", ""),
                )
                for i in self.identity_flows
            )
            parts.append(f"Identity: {identity_str}")
        if self.data_residency:
            parts.append(f"Data residency: {self.data_residency}")
        if self.exposure_signals:
            parts.append(
                f"Exposure signals detected: {', '.join(s.signal for s in self.exposure_signals)}"
            )
        if self.labels_text:
            parts.append(f"Labels: {', '.join(self.labels_text)}")
        return " ".join(parts)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "components": self.components,
            "data_stores": self.data_stores,
            "trust_boundaries": self.trust_boundaries,
            "network_paths": self.network_paths,
            "identity_flows": self.identity_flows,
            "external_parties": self.external_parties,
            "data_residency": self.data_residency,
            "labels_text": self.labels_text,
            "unreadable": self.unreadable,
            "exposure_signals": [
                {
                    "signal": s.signal,
                    "evidence_text": s.evidence_text,
                    "where": s.where,
                }
                for s in self.exposure_signals
            ],
        }


def extract_facts(image_base64: str, ocr_text: str | None = None) -> ArchitectureFacts:
    """
    Extract architecture facts from a diagram image.

    OCR always runs first (unless the caller already supplied ocr_text, e.g.
    tests) and serves two roles:
    - When an LLM is configured, its literal text is handed to the vision
      model as grounding, and its own regex-based exposure/label detection is
      unioned into the LLM's structured output -- catching exact strings
      (secrets, IPs, default creds) a vision model can paraphrase or miss.
    - When no LLM is configured, OCR text is the sole input to the
      deterministic extraction path.
    """
    if ocr_text is None:
        ocr_text = ocr_extractor.extract_text_from_image(base64.b64decode(image_base64))

    if llm_client.is_configured():
        try:
            facts = _extract_facts_llm(image_base64, ocr_text)
            return _merge_ocr_signals(facts, ocr_text)
        except llm_client.LLMNotConfigured:
            logger.info("LLM not configured for vision extraction, falling back to deterministic OCR")
        except Exception as e:
            logger.warning(f"Vision LLM call failed: {e}, falling back to deterministic extraction")

    return _extract_facts_deterministic(ocr_text or "")


def _merge_ocr_signals(facts: ArchitectureFacts, ocr_text: str) -> ArchitectureFacts:
    """Union the OCR-only deterministic pass's exposure signals and labels
    into the LLM-derived facts, deduped so the same finding isn't doubled up
    when both paths independently spot it."""
    if not ocr_text:
        return facts

    ocr_facts = _extract_facts_deterministic(ocr_text)

    seen = {(s.signal, s.evidence_text) for s in facts.exposure_signals}
    for signal in ocr_facts.exposure_signals:
        key = (signal.signal, signal.evidence_text)
        if key not in seen:
            seen.add(key)
            facts.exposure_signals.append(signal)

    existing_labels = set(facts.labels_text)
    for label in ocr_facts.labels_text:
        if label not in existing_labels:
            existing_labels.add(label)
            facts.labels_text.append(label)

    return facts


def _extract_facts_llm(image_base64: str, ocr_text: str = "") -> ArchitectureFacts:
    """Call vision LLM to extract architecture facts."""
    prompt = VISION_EXTRACTION_PROMPT
    if ocr_text:
        prompt += (
            "\n\nRaw OCR text detected in the image (for grounding only -- the diagram may "
            "contain visual elements OCR missed, and OCR may contain noise from icons/lines "
            "misread as characters; use your own judgment, but treat exact strings here as "
            "reliable evidence for exposure_signals):\n"
            f"{ocr_text}"
        )

    result = llm_client.complete_vision(
        system="You are an expert at analyzing architecture diagrams and extracting structured information.",
        text=prompt,
        image_base64=image_base64,
        mime_type="image/png",
        json_schema={
            "type": "object",
            "properties": {
                "components": {"type": "array"},
                "data_stores": {"type": "array"},
                "trust_boundaries": {"type": "array"},
                "network_paths": {"type": "array"},
                "identity_flows": {"type": "array"},
                "external_parties": {"type": "array"},
                "data_residency": {"type": "string"},
                "labels_text": {"type": "array"},
                "unreadable": {"type": "array"},
                "exposure_signals": {"type": "array"},
            },
        },
    )

    exposure_signals = []
    for sig in result.get("exposure_signals", []):
        exposure_signals.append(
            ExposureSignal(
                signal=sig.get("signal", "unknown"),
                evidence_text=sig.get("evidence_text", ""),
                where=sig.get("where", "unknown"),
            )
        )

    return ArchitectureFacts(
        components=result.get("components", []),
        data_stores=result.get("data_stores", []),
        trust_boundaries=result.get("trust_boundaries", []),
        network_paths=result.get("network_paths", []),
        identity_flows=result.get("identity_flows", []),
        external_parties=result.get("external_parties", []),
        data_residency=result.get("data_residency", ""),
        labels_text=result.get("labels_text", []),
        unreadable=result.get("unreadable", []),
        exposure_signals=exposure_signals,
    )


def _extract_facts_deterministic(ocr_text: str) -> ArchitectureFacts:
    """
    Deterministic fallback: run regex exposure detectors over OCR text.
    This is a best-effort heuristic when LLM is unavailable.
    """
    facts = ArchitectureFacts()

    if not ocr_text:
        return facts

    # Run exposure detectors
    for signal_type, pattern in _EXPOSURE_PATTERNS.items():
        for match in pattern.finditer(ocr_text):
            evidence_text = match.group(0)
            # Find approximate location in text (for "where")
            start = max(0, match.start() - 30)
            end = min(len(ocr_text), match.end() + 30)
            context = ocr_text[start:end].strip()
            where = context.split()[0] if context.split() else "unknown location"

            facts.exposure_signals.append(
                ExposureSignal(signal=signal_type, evidence_text=evidence_text, where=where)
            )

    # Try to extract some basic structure from labels
    facts.labels_text = re.findall(r"[A-Z][A-Za-z0-9\s\-_]+(?:server|db|api|gateway|storage|auth)", ocr_text)

    return facts


def describe_ocr_text_as_design(ocr_text: str) -> str:
    """Render OCR-only facts as a free-text design description -- used when
    no vision LLM is configured at all, so a diagram upload still produces
    something for the evaluation pipeline instead of hard-failing (see
    diagram/vision_extractor.py). Deliberately conservative: it only states
    what regex actually matched in the OCR'd text, never invents structure
    a vision model would otherwise infer."""
    facts = _extract_facts_deterministic(ocr_text)

    parts = [
        "This description was produced by OCR over an uploaded diagram image (no vision model "
        "output was available for it) -- it only reflects text Tesseract could read from the "
        "image, not the diagram's visual layout or unlabeled components."
    ]
    if facts.labels_text:
        parts.append(f"Text labels detected: {', '.join(facts.labels_text)}.")
    if facts.exposure_signals:
        signal_desc = "; ".join(
            f"{s.signal} ('{s.evidence_text}' near '{s.where}')" for s in facts.exposure_signals
        )
        parts.append(f"Potential exposure signals detected in on-diagram text: {signal_desc}.")
    if not facts.labels_text and not facts.exposure_signals:
        parts.append(
            "No structured labels or exposure signals were detected in the OCR text; the raw "
            f"text read from the image was: {ocr_text[:1000]}"
        )
    return " ".join(parts)


def evaluate_architecture(facts: ArchitectureFacts, session: Session) -> dict[str, Any]:
    """
    Evaluate extracted architecture facts against guardrails.
    Returns structured results with citation grounding and enhanced formatting.
    """
    query_text = facts.as_query_text()
    retrieval = retrieve_candidates(session, _FakeDesign(query_text))

    # Build facts description for better formatting
    facts_description = _build_facts_description(facts)

    if not retrieval.shortlist:
        return {
            "design_id": "architecture_evaluation",
            "facts_description": facts_description,
            "summary": {"overall": "compliant", "counts": {"compliant": 0, "non_compliant": 0, "gap": 0, "unevaluated": 0}},
            "results": [],
            "checked_guardrails_count": 0,
            "note": "No relevant guardrails found for this architecture in the database.",
        }

    # Prepare guardrails for evaluation
    guardrails_for_prompt = [
        {
            "guardrail_id": c.guardrail.id,
            "statement": c.guardrail.statement,
            "domain": c.guardrail.domain,
        }
        for c in retrieval.shortlist
    ]

    # Map guardrail IDs to their full data
    guardrail_map = {c.guardrail.id: c.guardrail for c in retrieval.shortlist}

    results = []
    evaluated_ids = set()
    
    if llm_client.is_configured():
        try:
            results = _evaluate_architecture_llm(facts, guardrails_for_prompt)
            evaluated_ids = {r["guardrail_id"] for r in results}
        except llm_client.LLMNotConfigured:
            pass
        except Exception as e:
            logger.warning(f"Architecture evaluation LLM call failed: {e}, falling back to heuristic")

    if not results:
        results = _evaluate_architecture_deterministic(facts, retrieval.shortlist, session)
        evaluated_ids = {r["guardrail_id"] for r in results}

    # Both extraction paths cite a guardrail by ID but don't know its primary
    # source clause ID (the LLM isn't given it to avoid it fabricating one;
    # the deterministic path doesn't track it either) -- backfill it here
    # from the real guardrail record so the citation gate below has an
    # actual clause_id to verify instead of always failing on a missing one.
    for finding in results:
        guardrail = guardrail_map.get(finding.get("guardrail_id"))
        if guardrail and guardrail.sources:
            finding["clause_id"] = guardrail.sources[0].clause_id

    # Gate each finding
    for finding in results:
        gate_finding(session, finding)

    # Add unevaluated guardrails to results (those that weren't matched)
    for guardrail_id, guardrail in guardrail_map.items():
        if guardrail_id not in evaluated_ids:
            results.append({
                "guardrail_id": guardrail_id,
                "domain": guardrail.domain,
                "verdict": "Unevaluated",
                "severity": None,
                "architecture_evidence": None,
                "guardrail_statement": guardrail.statement,
                "rationale": "Not applicable to the extracted architecture facts.",
                "recommendation": None,
            })

    # Build summary
    compliant_count = len([r for r in results if r["verdict"] == "Compliant"])
    non_compliant_count = len([r for r in results if r["verdict"] == "Non-compliant"])
    gap_count = len([r for r in results if r["verdict"] == "Gap"])
    unevaluated_count = len([r for r in results if r["verdict"] == "Unevaluated"])

    if non_compliant_count > 0:
        overall = "non_compliant"
    elif gap_count > 0:
        overall = "gap"
    else:
        overall = "compliant"

    return {
        "design_id": "architecture_evaluation",
        "facts_description": facts_description,
        "summary": {
            "overall": overall,
            "counts": {"compliant": compliant_count, "non_compliant": non_compliant_count, "gap": gap_count, "unevaluated": unevaluated_count},
        },
        "results": results,
        "checked_guardrails_count": len(retrieval.shortlist),
    }


def _build_facts_description(facts: ArchitectureFacts) -> dict[str, Any]:
    """
    Build a well-formatted description of the extracted architecture facts.
    This is used for frontend display to provide better context about the diagram.
    """
    description = {
        "overview": _generate_overview_text(facts),
        "components": facts.components,
        "data_stores": facts.data_stores,
        "network_paths": facts.network_paths,
        "identity_flows": facts.identity_flows,
        "trust_boundaries": facts.trust_boundaries,
        "external_parties": facts.external_parties,
        "exposure_signals": [
            {
                "signal": s.signal,
                "evidence": s.evidence_text,
                "location": s.where,
                "severity": _SIGNAL_SEVERITY_MAP.get(s.signal, "Medium"),
            }
            for s in facts.exposure_signals
        ],
        "data_residency": facts.data_residency,
    }
    if facts.unreadable:
        description["unreadable_sections"] = facts.unreadable
    return description


def _generate_overview_text(facts: ArchitectureFacts) -> str:
    """
    Generate a human-readable overview of the architecture based on extracted facts.
    """
    parts = []
    
    if facts.components:
        component_names = [c.get("name", "") for c in facts.components]
        parts.append(f"Architecture includes {len(facts.components)} key components: {', '.join(component_names[:5])}" + 
                    (f" and {len(facts.components) - 5} more" if len(facts.components) > 5 else ""))
    
    if facts.data_stores:
        store_names = [d.get("name", "") for d in facts.data_stores]
        parts.append(f"Data is stored in {len(facts.data_stores)} locations: {', '.join(store_names[:3])}" + 
                    (f" and {len(facts.data_stores) - 3} more" if len(facts.data_stores) > 3 else ""))
    
    if facts.network_paths:
        protocols = set(p.get("protocol", "") for p in facts.network_paths if p.get("protocol"))
        parts.append(f"Network communication uses: {', '.join(protocols)}")
    
    if facts.identity_flows:
        auth_methods = set(i.get("auth_method", "") for i in facts.identity_flows if i.get("auth_method"))
        parts.append(f"Identity and access managed via: {', '.join(auth_methods)}")
    
    if facts.exposure_signals:
        severity_signals = [s for s in facts.exposure_signals if _SIGNAL_SEVERITY_MAP.get(s.signal) in ["Critical", "High"]]
        if severity_signals:
            parts.append(f"⚠️ {len(severity_signals)} high-severity exposure signal(s) detected in the diagram")
    
    if not parts:
        return "Architecture diagram extracted. Ready for compliance evaluation."
    
    return " ".join(parts)


def _evaluate_architecture_llm(facts: ArchitectureFacts, guardrails: list[dict]) -> list[dict[str, Any]]:
    """Call LLM to evaluate architecture against guardrails."""
    facts_prompt = f"""Architecture Facts:
{json.dumps(facts.to_dict(), indent=2)}

Guardrails to evaluate:
{json.dumps(guardrails, indent=2)}
"""

    result = llm_client.complete(
        system="You are the Architecture Compliance Agent in GuardrailIQ.",
        user=facts_prompt + "\n\n" + ARCH_EVALUATION_PROMPT,
        json_schema={
            "type": "object",
            "properties": {
                "results": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "guardrail_id": {"type": "string"},
                            "verdict": {"type": "string", "enum": ["Compliant", "Non-compliant", "Gap"]},
                            "severity": {
                                "type": "string",
                                "enum": ["Critical", "High", "Medium", "Low", "null"],
                            },
                            "architecture_evidence": {"type": "string"},
                            "guardrail_statement": {"type": "string"},
                            "rationale": {"type": "string"},
                            "recommendation": {"type": "string"},
                        },
                    },
                }
            },
        },
    )

    formatted_results = []
    for r in result.get("results", []):
        formatted_results.append(
            {
                "guardrail_id": r.get("guardrail_id"),
                "domain": "Information Security",
                "verdict": r.get("verdict", "Gap"),
                "severity": r.get("severity") if r.get("severity") != "null" else None,
                "design_evidence": r.get("architecture_evidence", ""),
                "guardrail_statement": r.get("guardrail_statement", ""),
                "source": {"document": "architecture_diagram", "clause_ref": "", "clause_text": ""},
                "rationale": r.get("rationale", ""),
                "recommendation": r.get("recommendation"),
                "citation_gate_passed": False,  # Will be set by gate_finding
            }
        )

    return formatted_results


def _evaluate_architecture_deterministic(facts: ArchitectureFacts, shortlist, session: Session) -> list[dict[str, Any]]:
    """
    Deterministic fallback: match exposure signals to guardrails by signal type.
    """
    results = []

    # Map each detected signal to the best matching guardrail
    for signal in facts.exposure_signals:
        # Find guardrails mentioning security/exposure keywords related to this signal
        severity = _SIGNAL_SEVERITY_MAP.get(signal.signal, "Medium")

        for considered in shortlist:
            guardrail = considered.guardrail
            # Simple keyword matching: does the guardrail statement mention relevant concepts?
            statement_lower = guardrail.statement.lower()
            signal_keywords = {
                "exposed_secret": ["secret", "credential", "api key", "token", "password"],
                "default_creds": ["default", "credential", "password", "account"],
                "public_datastore": ["public", "internet", "exposed", "database", "bucket"],
                "no_auth": ["authentication", "auth", "access", "permission"],
                "localhost_console": ["localhost", "development", "prod", "console"],
                "plaintext_http": ["http", "encryption", "tls", "ssl", "encrypted"],
                "debug_enabled": ["debug", "development", "production"],
            }

            keywords = signal_keywords.get(signal.signal, [])
            if any(kw in statement_lower for kw in keywords):
                # GuardrailSource.clause_id/document_id are plain strings, not
                # FKs (an orphan reference must stay representable -- see
                # db/models.py), so there's no `.clause`/`.document`
                # relationship to walk; look them up explicitly instead.
                source = guardrail.sources[0] if guardrail.sources else None
                clause = session.get(Clause, source.clause_id) if source else None
                document = session.get(Document, source.document_id) if source and source.document_id else None
                results.append(
                    {
                        "guardrail_id": guardrail.id,
                        "domain": guardrail.domain,
                        "verdict": "Non-compliant",
                        "severity": severity,
                        "design_evidence": f"Exposure signal detected: {signal.evidence_text} at {signal.where}",
                        "guardrail_statement": guardrail.statement,
                        "source": {
                            "document": document.title if document else "",
                            "clause_ref": clause.id if clause else "",
                            "clause_text": clause.clause_text if clause else "",
                        },
                        "rationale": f"The {signal.signal} exposure ({signal.evidence_text}) directly violates this requirement.",
                        "recommendation": f"Remove or remediate the {signal.signal}: {signal.evidence_text}",
                        "citation_gate_passed": False,
                    }
                )
                break  # One match per signal

    return results


class _FakeDesign:
    """Minimal design stand-in for retrieval.retrieve_candidates()."""

    def __init__(self, text: str):
        self.description = text
        self.domain = "Information Security"
