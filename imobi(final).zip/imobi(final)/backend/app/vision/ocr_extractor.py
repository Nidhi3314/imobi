"""
Deterministic OCR over an uploaded architecture-diagram image, using Tesseract
via pytesseract. This is complementary to the vision LLM, not a replacement
for it: a vision model can paraphrase or misread small on-diagram text (an
exact secret, an IP, a port number), while OCR reads the literal pixels. So
when an LLM is configured, its raw text is folded into the vision prompt as
grounding *and* its own regex-based exposure/label detection is unioned into
whatever the LLM extracted (see architecture_agent.py). When no LLM is
configured at all, this is the sole signal driving the deterministic
extraction path.

Like the LLM seam, this degrades gracefully: no Tesseract binary on the
machine just means empty OCR text, not a crash -- the caller already handles
"no ocr_text" the same way it always has.
"""
from __future__ import annotations

import io
import logging

logger = logging.getLogger("guardrailiq")

_checked_available: bool | None = None
_tesseract_cmd_configured = False


def _configure_tesseract_cmd() -> None:
    """Point pytesseract at an explicit binary if one was configured or found
    at a common Windows install path -- pytesseract otherwise only looks on
    PATH, which a fresh Windows install of Tesseract rarely adds itself to."""
    global _tesseract_cmd_configured
    if _tesseract_cmd_configured:
        return
    _tesseract_cmd_configured = True

    import pytesseract

    from app import config

    if config.TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD
        return

    import shutil

    if shutil.which("tesseract"):
        return  # already on PATH, nothing to do

    for candidate in (
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ):
        import os

        if os.path.isfile(candidate):
            pytesseract.pytesseract.tesseract_cmd = candidate
            return


def is_available() -> bool:
    """Cheap, cached check: is pytesseract importable AND does it have a
    working Tesseract binary to call? Logged once so a missing install is
    diagnosable without spamming the log on every diagram upload."""
    global _checked_available
    if _checked_available is not None:
        return _checked_available

    try:
        import pytesseract

        _configure_tesseract_cmd()
        pytesseract.get_tesseract_version()
        _checked_available = True
    except Exception as e:
        logger.info(
            "OCR unavailable (%s) -- diagram analysis will rely on the vision LLM alone. "
            "Install Tesseract OCR and/or set GUARDRAILIQ_TESSERACT_CMD to enable it.",
            e,
        )
        _checked_available = False
    return _checked_available


def _preprocess(image_bytes: bytes):
    """Grayscale + autocontrast + upscale small images -- diagrams are often
    screenshots with small dense labels, which plain Tesseract reads poorly."""
    from PIL import Image, ImageOps

    image = Image.open(io.BytesIO(image_bytes))
    image = image.convert("L")  # grayscale
    image = ImageOps.autocontrast(image)

    max_dim = max(image.size)
    if max_dim < 1600:
        scale = 1600 / max_dim
        new_size = (round(image.width * scale), round(image.height * scale))
        image = image.resize(new_size, Image.LANCZOS)

    return image


def extract_text_from_image(image_bytes: bytes) -> str:
    """Best-effort OCR text extraction. Returns "" (never raises) when OCR
    isn't available or the call fails for any reason -- callers already treat
    an empty ocr_text as "no OCR signal" the same way they treat "no LLM"."""
    if not image_bytes or not is_available():
        return ""

    try:
        import pytesseract

        image = _preprocess(image_bytes)
        text = pytesseract.image_to_string(image)
        return text.strip()
    except Exception as e:
        logger.warning("OCR extraction failed: %s", e)
        return ""
