"""
SQLAlchemy models for the GuardrailIQ queryable knowledge model.

Documents and Clauses are ingested verbatim (ground truth, never regenerated).
Guardrails are derived records produced by the Extraction/Dedup/Conflict/Orphan
agents; every Guardrail always carries its source clause/document IDs through
GuardrailSource, which is why de-duplication can union sources instead of
dropping any of them.
"""
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def utcnow():
    return datetime.now(timezone.utc)


class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True)  # e.g. DOC-0001 (or whatever the source uses)
    title = Column(String, nullable=False)
    domain = Column(String, nullable=False, index=True)
    document_type = Column(String)
    owner_function = Column(String)
    version = Column(String)
    effective_date = Column(String)
    status = Column(String)
    summary = Column(Text)

    clauses = relationship("Clause", back_populates="document")


class Clause(Base):
    __tablename__ = "clauses"

    id = Column(String, primary_key=True)  # e.g. CL-0001
    document_id = Column(String, ForeignKey("documents.id"), nullable=False, index=True)
    clause_ref = Column(String)
    clause_heading = Column(String)
    clause_text = Column(Text, nullable=False)
    seeded_flag = Column(String)

    document = relationship("Document", back_populates="clauses")


class Guardrail(Base):
    __tablename__ = "guardrails"

    id = Column(String, primary_key=True)  # generated, e.g. GR-<uuid8>
    domain = Column(String, nullable=False, index=True)
    category = Column(String)
    statement = Column(Text, nullable=False)  # the requirement, plain language
    severity = Column(String, nullable=False)  # Low/Medium/High/Mandatory etc.
    instruction_type = Column(String)  # Mandatory/Recommended/Principle...
    applicability = Column(Text)
    not_applicable = Column(Text)
    do_instructions = Column(Text)
    dont_instructions = Column(Text)
    trigger_conditions = Column(Text)
    plain_language_guidance = Column(Text)

    # normalized comparable requirement value, e.g. {"metric":"retention_period","operator":"<=","value":12,"unit":"months"}
    normalized_metric = Column(String, nullable=True)
    normalized_value = Column(Float, nullable=True)  # canonical/comparable value
    normalized_raw_value = Column(Float, nullable=True)  # original stated number, for display
    normalized_unit = Column(String, nullable=True)  # original stated unit, for display
    normalized_operator = Column(String, nullable=True)
    normalized_subgroup = Column(String, nullable=True)  # lifecycle | sla_turnaround | recurrence

    broken_reference = Column(Boolean, default=False)  # set by Orphan Agent
    merged_from = Column(Text, nullable=True)  # audit trail: which draft guardrail ids were merged in

    created_at = Column(DateTime, default=utcnow)

    sources = relationship("GuardrailSource", back_populates="guardrail", cascade="all, delete-orphan")


class GuardrailSource(Base):
    """Join table: every clause/document a guardrail is traceable to. Never pruned on merge."""

    __tablename__ = "guardrail_sources"

    id = Column(Integer, primary_key=True, autoincrement=True)
    guardrail_id = Column(String, ForeignKey("guardrails.id"), nullable=False, index=True)
    clause_id = Column(String, nullable=False)  # not an FK on purpose: orphan refs must be representable
    document_id = Column(String, nullable=True)

    guardrail = relationship("Guardrail", back_populates="sources")


class GuardrailRelationship(Base):
    """duplicate_of (Dedup Agent, already applied) or conflicts_with (Conflict Agent, open ticket)."""

    __tablename__ = "guardrail_relationships"

    id = Column(Integer, primary_key=True, autoincrement=True)
    guardrail_id_a = Column(String, ForeignKey("guardrails.id"), nullable=False, index=True)
    guardrail_id_b = Column(String, ForeignKey("guardrails.id"), nullable=False, index=True)
    relationship_type = Column(String, nullable=False)  # "duplicate_of" | "conflicts_with"
    rationale = Column(Text, nullable=True)  # Conflict Agent's reasoning for why they disagree
    created_at = Column(DateTime, default=utcnow)


class ConflictTicket(Base):
    """A Conflict Desk ticket: recommendation + impact analysis, awaiting human decision."""

    __tablename__ = "conflict_tickets"

    id = Column(String, primary_key=True)  # e.g. CFT-<uuid8>
    guardrail_id_a = Column(String, nullable=False)
    guardrail_id_b = Column(String, nullable=False)
    metric = Column(String)
    rationale = Column(Text)  # why the sources disagree
    recommended_resolution = Column(Text)  # e.g. "prefer B: newer document"
    impact_analysis = Column(Text)  # JSON-encoded: which designs flip verdict under A vs B
    status = Column(String, default="open")  # open | approved_a | approved_b | kept_open
    decided_by = Column(String, nullable=True)
    decided_at = Column(DateTime, nullable=True)
    assigned_to = Column(String, nullable=True)  # AdminUser.username -- in-app notification target
    created_at = Column(DateTime, default=utcnow)


class DesignDescription(Base):
    """Raw ingested design descriptions, kept verbatim for demo convenience / self-check."""

    __tablename__ = "design_descriptions"

    id = Column(String, primary_key=True)  # e.g. DSN-0001
    title = Column(String)
    domain = Column(String, index=True)
    description = Column(Text, nullable=False)
    expected_outcome = Column(String, nullable=True)  # self-check only, never trusted at eval time
    scenario_note = Column(String, nullable=True)


class AdminUser(Base):
    """A registered human reviewer. Conflict Desk decisions are attributed to a real
    logged-in admin, not a free-text 'decided_by' string -- the point of requiring
    registration/login here is to make 'a human reviewer stays in control' an actual
    identity, not just a label."""

    __tablename__ = "admin_users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False, index=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)  # "<salt_hex>$<hash_hex>", PBKDF2-HMAC-SHA256
    display_name = Column(String, nullable=True)
    created_at = Column(DateTime, default=utcnow)


class AdminSession(Base):
    __tablename__ = "admin_sessions"

    token = Column(String, primary_key=True)
    admin_id = Column(Integer, ForeignKey("admin_users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, nullable=False)


class User(Base):
    """A registered end user of the main app -- distinct from AdminUser on
    purpose: this identity carries no Conflict Desk decision rights, it's
    just 'who's using CompliX' (chat personalization, a profile in the User
    Console). Registering here never grants admin/reviewer access."""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False, index=True)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)  # "<salt_hex>$<hash_hex>", PBKDF2-HMAC-SHA256
    display_name = Column(String, nullable=True)
    created_at = Column(DateTime, default=utcnow)


class UserSession(Base):
    __tablename__ = "user_sessions"

    token = Column(String, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, nullable=False)


class DocumentUpdateLog(Base):
    """One row per version bump an admin makes to a Document. The main app
    polls for the latest row here to pop a 'this document was updated'
    notification -- a durable, inspectable record rather than a fire-and-
    forget push."""

    __tablename__ = "document_update_log"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(String, nullable=False, index=True)
    document_title = Column(String, nullable=False)
    old_version = Column(String, nullable=True)
    new_version = Column(String, nullable=False)
    updated_by = Column(String, nullable=True)  # AdminUser.username
    created_at = Column(DateTime, default=utcnow)
