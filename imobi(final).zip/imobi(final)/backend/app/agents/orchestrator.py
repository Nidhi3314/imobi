"""
Orchestrator: the chat entry point. Routes natural-language messages to specialist
agents and enriches responses with intelligent LLM reasoning throughout the pipeline.

AGENTIC SOLUTION:
- Small talk: Detected via regex patterns for speed
- Guardrail search: LLM analyzes query intent and composes intelligent responses
- Conflict queries: LLM provides strategic analysis of competing requirements
- Design evaluation: LLM-backed verdict reasoning with deterministic fallback

Every response carries a `trace`: an ordered list of actual agent stages that ran,
so the frontend's workflow view reflects what genuinely happened. This enables
transparent agentic reasoning -- the LLM's role in the decision-making is explicit,
not hidden.

`reply` is composed by the LLM (or Chat Composer) from structured data, and
`citations` is built directly from guardrail/clause records -- never parsed from
the model's prose. That split ensures citations stay trustworthy even if wording
is loose, because the UI never has to trust the model to get an ID right.
"""
from __future__ import annotations

import json
import logging
import random
import re

from sqlalchemy.orm import Session

from app.agents.chat_composer import compose_evaluate_reply, compose_search_reply
from app.agents.response_formatter import (
    format_conflict_response,
    format_evaluate_response,
    format_search_response,
)
from app.conflicts.decision_store import list_tickets
from app.db.models import DesignDescription, Guardrail
from app.evaluation.report import build_report
from app.knowledge.embeddings import TextSimilarityIndex
from app.llm import client as llm_client
from app.mcp import client_manager as mcp_client_manager

logger = logging.getLogger("guardrailiq")

# Small talk never touches the LLM or retrieval -- it's not a governance
# question, so there's nothing to reason about or cite. Matched first and
# only on a short, whole-message match so it doesn't misfire on a real
# question that happens to start with "hi" as part of a longer sentence.
_GREETING_RE = re.compile(
    r"^\s*(hey|hi|hello|howdy|yo|sup|good\s+(morning|afternoon|evening))[\s!.,]*$",
    re.IGNORECASE,
)
_HOW_ARE_YOU_RE = re.compile(
    r"^\s*(how'?s?\s+it\s+going|how\s+are\s+you|what'?s?\s+up|how\s+do\s+you\s+do)[\s?!.,]*$",
    re.IGNORECASE,
)
_THANKS_RE = re.compile(r"^\s*(thanks|thank\s+you|thx|ty|cheers)[\s!.,]*$", re.IGNORECASE)

_GREETING_REPLIES = [
    "Hey! Ask me to search guardrails, evaluate a design, or check open conflicts whenever you're ready.",
    "Hi there. I'm ready when you are -- try asking about a guardrail, a design, or open conflicts.",
    "Hello! I can search guardrails, evaluate a design description, or list open conflicts.",
]
_HOW_ARE_YOU_REPLIES = [
    "Doing well, thanks for asking. What would you like to check -- a guardrail, a design, or open conflicts?",
    "All good on my end. Ready to search guardrails, evaluate a design, or check conflicts whenever you are.",
]
_THANKS_REPLIES = [
    "You're welcome! Anything else you'd like to check?",
    "Happy to help. Let me know if you want to search more guardrails or evaluate another design.",
]

_EVALUATE_RE = re.compile(r"\bevaluate\b|\bcompliance check\b|\bassess\b", re.IGNORECASE)
_CONFLICT_RE = re.compile(r"\bconflicts?\b|\bconflicting\b|\bdisagree\b", re.IGNORECASE)

def _small_talk_reply(message: str) -> str | None:
    if _GREETING_RE.match(message):
        return random.choice(_GREETING_REPLIES)
    if _HOW_ARE_YOU_RE.match(message):
        return random.choice(_HOW_ARE_YOU_REPLIES)
    if _THANKS_RE.match(message):
        return random.choice(_THANKS_REPLIES)
    return None


def _compose_search_with_llm(message: str, ranked_guardrails: list[tuple[Guardrail, float]]) -> str:
    """Use LLM to compose an intelligent guardrail search response. When
    external MCP servers are configured (GUARDRAILIQ_MCP_SERVERS), the model
    may also call their tools while composing this reply -- e.g. an
    organization's own MCP server for extra context on a term in the query.
    This only shapes the prose commentary; the citations returned alongside
    it are built separately, straight from the guardrail records, so nothing
    a tool returns can itself become or alter a citation."""
    if not ranked_guardrails:
        return "I couldn't find any guardrails relevant to that query."

    try:
        # Format guardrails for LLM context
        guardrail_context = "\n".join([
            f"- {g.statement} (severity: {g.severity}, domain: {g.domain})"
            for g, _ in ranked_guardrails[:5]
        ])

        user_prompt = f"""Based on the matching guardrails below, provide a concise, professional summary
explaining how these guardrails relate to the user's question.

User Query: {message}

Matching Guardrails:
{guardrail_context}

Provide a brief, natural response (2-3 sentences) that explains the relevance
of these guardrails to their query."""

        # JSON schema to ensure LLM returns structured response
        response_schema = {
            "type": "object",
            "properties": {
                "response": {"type": "string"}
            },
            "required": ["response"]
        }

        system = "You are a governance compliance assistant providing expert guidance on guardrails."
        tools = mcp_client_manager.list_tools()
        if tools:
            response = llm_client.complete_with_tools(
                system=system, user=user_prompt, tools=tools, json_schema=response_schema,
            )
        else:
            response = llm_client.complete(system=system, user=user_prompt, json_schema=response_schema)
        # LLM returns a dict with 'response' key
        return response.get("response", compose_search_reply(message, ranked_guardrails))
    except llm_client.LLMNotConfigured:
        logger.info("LLM not configured, using fallback search reply")
        return compose_search_reply(message, ranked_guardrails)
    except Exception as e:
        logger.warning(f"LLM-powered search failed: {e}, using fallback")
        return compose_search_reply(message, ranked_guardrails)


def _analyze_conflicts_with_llm(message: str, tickets: list) -> str:
    """Use LLM to provide intelligent analysis of open conflicts. When
    external MCP servers are configured (e.g. Jira/Confluence via
    GUARDRAILIQ_MCP_SERVERS), the model may use their tools while composing
    this commentary -- e.g. checking whether a Jira ticket already tracks a
    given conflict, or filing one. Same scope guarantee as the search path:
    this only shapes prose, never the ticket data/citations themselves,
    which stay sourced from the real ConflictTicket records regardless of
    what a tool returns."""
    if not tickets:
        return "No open conflicts right now."

    try:
        # Format tickets for LLM analysis
        ticket_context = "\n".join([
            f"Ticket {t.id}: Side A (guardrail {t.guardrail_id_a}) vs Side B (guardrail {t.guardrail_id_b})\n"
            f"  Metric: {t.metric}\n"
            f"  Rationale: {t.rationale}"
            for t in tickets[:5]
        ])

        user_prompt = f"""Analyze these conflicting compliance requirements and provide insights.

Open Conflicts:
{ticket_context}

User Context: {message}

Provide a brief, insightful summary (2-3 sentences) of these conflicts and their
implications for governance strategy. If a tool is available to check or track
these in an external system (e.g. Jira, Confluence), use it when the user's
question calls for it -- otherwise just answer directly."""

        # JSON schema to ensure LLM returns structured response
        response_schema = {
            "type": "object",
            "properties": {
                "response": {"type": "string"}
            },
            "required": ["response"]
        }

        system = "You are a governance compliance expert analyzing conflicting requirements."
        tools = mcp_client_manager.list_tools()
        if tools:
            response = llm_client.complete_with_tools(
                system=system, user=user_prompt, tools=tools, json_schema=response_schema,
            )
        else:
            response = llm_client.complete(system=system, user=user_prompt, json_schema=response_schema)
        if response:
            return response.get("response", "")
    except llm_client.LLMNotConfigured:
        logger.info("LLM not configured for conflict analysis, using default summary")
    except Exception as e:
        logger.warning(f"LLM-powered conflict analysis failed: {e}, using fallback")
    
    # Fallback to deterministic summary
    return (
        f"There {'is' if len(tickets) == 1 else 'are'} {len(tickets)} open conflict ticket"
        f"{'' if len(tickets) == 1 else 's'} awaiting a human decision. "
        "Each pits two guardrails against each other on the same requirement."
    )


def handle_message(session: Session, message: str) -> dict:
    small_talk = _small_talk_reply(message)
    if small_talk is not None:
        return {
            "intent": "smalltalk",
            "reply": small_talk,
            "sections": [{"title": "Response", "content": small_talk}],
            "summary": small_talk,
            "data": [],
            "citations": [],
            "trace": [{"agent": "Orchestrator", "action": "Recognized this as small talk -- answered directly, no retrieval or LLM call."}],
        }

    if _CONFLICT_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'conflicts' from the message text."},
            {"agent": "Conflict Agent", "action": "Read open tickets from the Conflict Desk queue."},
        ]
        tickets = list_tickets(session, status="open")
        
        if not tickets:
            return {
                "intent": "conflicts",
                "reply": "No open conflicts right now.",
                "sections": [{"title": "Open Conflicts", "content": "No open conflicts right now."}],
                "summary": "No open conflicts right now.",
                "data": [],
                "citations": [],
                "trace": trace,
            }
        
        # Use LLM for intelligent conflict analysis
        trace.append({"agent": "LLM Analyzer", "action": "Analyzed conflicts using intelligent reasoning to provide strategic insights."})
        intelligent_reply = _analyze_conflicts_with_llm(message, tickets)
        
        citations = []
        for t in tickets:
            citations.append({"guardrail_id": t.guardrail_id_a, "label": f"{t.id} - Side A"})
            citations.append({"guardrail_id": t.guardrail_id_b, "label": f"{t.id} - Side B"})
        
        formatted = format_conflict_response(
            tickets,
            intelligent_reply,
            message,
        )
        
        return {
            **formatted,
            "data": [
                {"id": t.id, "metric": t.metric, "rationale": t.rationale, "status": t.status}
                for t in tickets
            ],
            "citations": citations,
            "trace": trace,
        }

    if _EVALUATE_RE.search(message):
        trace = [
            {"agent": "Orchestrator", "action": "Classified intent as 'evaluate' from the message text."},
        ]
        designs = session.query(DesignDescription).all()
        if not designs:
            return {
                "intent": "evaluate",
                "reply": "No designs are loaded yet.",
                "sections": [{"title": "Design Evaluation", "content": "No designs are loaded yet."}],
                "summary": "No designs are loaded yet.",
                "data": [],
                "citations": [],
                "trace": trace,
            }
        idx = TextSimilarityIndex([d.description for d in designs] + [message])
        sim = idx.pairwise_similarity()
        best_i = max(range(len(designs)), key=lambda i: sim[-1, i])
        design = designs[best_i]
        trace.append({"agent": "Orchestrator", "action": f"Matched the message to design '{design.id}' ({design.title})."})
        trace.append({"agent": "Retriever", "action": "Ranked all guardrails by relevance to this design (domain-boosted similarity)."})
        report = build_report(session, design.id)
        mode_summary = report.get("analysis_mode_summary", {"mode": "heuristic"})
        eval_action = {
            "llm": "Produced a verdict per candidate guardrail via LLM-backed reasoning.",
            "heuristic": "LLM unavailable (rate-limited or not configured) -- fell back to deterministic keyword analysis.",
            "mixed": "Produced verdicts via LLM-backed reasoning, with a deterministic keyword fallback for the guardrails the LLM call missed.",
        }[mode_summary["mode"]]
        trace.append({"agent": "Evaluation Agent", "action": eval_action})
        trace.append({"agent": "Auditor Agent", "action": "Independently re-checked each verdict's evidence before it could be shown."})
        trace.append({"agent": "Citation Gate", "action": "Verified every citation against the database; rejects are shown as Unverified."})
        trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language summary of the findings above."})
        reply = compose_evaluate_reply(design, report["findings"], report.get("overall_verdict"), mode_summary)
        citations = [
            {"guardrail_id": f["guardrail_id"], "clause_id": f["clause_id"], "label": f["verdict"]}
            for f in report["findings"]
            if f["clause_id"]
        ]
        
        # Format response with detailed sections
        formatted = format_evaluate_response(
            design.title,
            design.id,
            report["findings"],
            report.get("overall_verdict", {}).get("status", "unknown"),
            analysis_mode=mode_summary.get("mode", "heuristic"),
        )
        
        return {
            **formatted,
            "data": report,
            "citations": citations,
            "trace": trace,
        }

    trace = [
        {"agent": "Orchestrator", "action": "No 'evaluate' or 'conflict' intent detected -- treated as a guardrail search."},
        {"agent": "Retriever", "action": "Ranked all guardrails by text similarity to the message."},
    ]
    guardrails = session.query(Guardrail).all()
    if not guardrails:
        return {
            "intent": "search",
            "reply": "No guardrails are loaded yet.",
            "sections": [{"title": "Search Results", "content": "No guardrails are loaded yet."}],
            "summary": "No guardrails are loaded yet.",
            "data": [],
            "citations": [],
            "trace": trace,
        }
    
    idx = TextSimilarityIndex([g.statement for g in guardrails] + [message])
    sim = idx.pairwise_similarity()[-1][:-1]
    ranked = sorted(zip(guardrails, sim), key=lambda p: p[1], reverse=True)[:5]
    ranked = [(g, s) for g, s in ranked if s > 0]
    
    if not ranked:
        return {
            "intent": "search",
            "reply": f"No guardrails matched your query: \"{message}\"",
            "sections": [{"title": "Search Results", "content": f"No guardrails matched your query: \"{message}\""}],
            "summary": f"No guardrails matched your query: \"{message}\"",
            "data": [],
            "citations": [],
            "trace": trace,
        }
    
    # Use LLM for intelligent search response composition
    trace.append({"agent": "LLM Analyzer", "action": "Used intelligent reasoning to compose a contextually relevant response."})
    reply = _compose_search_with_llm(message, ranked)
    
    citations = [{"guardrail_id": g.id, "label": g.severity} for g, _ in ranked]
    
    # Format response with detailed sections
    formatted = format_search_response(
        message,
        ranked,
        reply,
    )
    
    return {
        **formatted,
        "data": [
            {"id": g.id, "statement": g.statement, "severity": g.severity, "domain": g.domain, "similarity": round(float(s), 3)}
            for g, s in ranked
        ],
        "citations": citations,
        "trace": trace,
    }
