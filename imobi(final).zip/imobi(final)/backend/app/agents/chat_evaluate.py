"""
Shared "evaluate this new ad-hoc design and shape it as a chat reply" path,
used by every way a design can enter the conversation: a typed message that
matches a *known* design (orchestrator.py), a freshly typed/uploaded design
that isn't in the dataset at all (routes_chat.py's /evaluate-text), or an
uploaded architecture diagram image (routes_chat.py's /attach, after the
Diagram Agent turns it into text). One code path means the trust chain
(Retriever -> Evaluation Agent -> Auditor Agent -> Citation Gate -> Chat
Composer) is identical regardless of how the design text arrived.
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy.orm import Session

from app.agents.chat_composer import compose_evaluate_reply
from app.db.models import DesignDescription
from app.evaluation.report import build_report
from app.llm import client as llm_client

logger = logging.getLogger("guardrailiq")


def explain_architecture(description: str, title: str, question: str = "") -> tuple[str, bool]:
    """Produce a detailed, plain-language walkthrough of an architecture
    description -- answering a specific question (e.g. an ELI5 request) if
    one was asked, or otherwise covering what the system does, its
    components, data flow, and security/governance posture in depth. Used
    to replace a bare parroting of the raw diagram-extraction text with an
    actual, detailed answer.

    Also returns whether the content actually looks like a system/
    architecture description at all -- so callers can skip running a full
    guardrail evaluation against, say, a photo of a cat and instead say so
    plainly, rather than reporting a confusing "13 Gap findings" against
    content with nothing architectural in it."""
    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Title: {title}\n\nDescription:\n{description}\n\n"
                + (
                    f"User's question: {question.strip()}"
                    if question.strip()
                    else "Give a detailed walkthrough of this architecture: what it does, its main "
                    "components and their role, how data flows between them, and what security/"
                    "governance controls are in place."
                )
            )
            result = llm_client.complete(
                "You are the CompliX chat assistant. First decide: does this description actually "
                "depict a system/software/data architecture (components, data flow, infrastructure, "
                "or similar), even a simple or incomplete one? Set is_architecture=false only if it "
                "clearly depicts something unrelated (a photo, a person, an unrelated document, etc.) "
                "with nothing architectural in it. Then answer the user's question about this "
                "architecture thoroughly and in clear language -- use an ELI5 (explain like I'm 5) "
                "style, with simple analogies, if that's what's asked for. Otherwise give a "
                "well-structured, detailed walkthrough covering components, data flow, and "
                "security/governance controls. If is_architecture is false, the answer should just "
                "explain what the content actually appears to be instead. Use only what's in the "
                "description; don't invent details that aren't there. Plain text only -- short "
                "paragraphs, 6-10 sentences.",
                user_prompt,
                {
                    "type": "object",
                    "properties": {
                        "is_architecture": {"type": "boolean"},
                        "answer": {"type": "string"},
                    },
                    "required": ["is_architecture", "answer"],
                },
            )
            answer = (result or {}).get("answer", "").strip()
            is_architecture = bool((result or {}).get("is_architecture", True))
            if answer:
                return answer, is_architecture
        except Exception as e:
            logger.warning("Explain architecture: LLM call failed, using raw description: %s", e)
    return description, True


def evaluate_adhoc_design(session: Session, title: str, domain: str, description: str, id_prefix: str) -> dict:
    design_id = f"__{id_prefix}_{uuid.uuid4().hex[:8]}__"
    design = DesignDescription(id=design_id, title=title, domain=domain, description=description)
    session.add(design)
    session.commit()

    report = build_report(session, design_id)
    mode_summary = report.get("analysis_mode_summary", {"mode": "heuristic"})
    eval_action = {
        "llm": "Produced a verdict per candidate guardrail via LLM-backed reasoning.",
        "heuristic": "LLM unavailable (rate-limited or not configured) -- fell back to deterministic keyword analysis.",
        "mixed": "Produced verdicts via LLM-backed reasoning, with a deterministic keyword fallback for the guardrails the LLM call missed.",
    }[mode_summary["mode"]]

    trace = [
        {"agent": "Retriever", "action": "Ranked all guardrails by relevance to this design."},
        {"agent": "Evaluation Agent", "action": eval_action},
        {"agent": "Auditor Agent", "action": "Independently re-checked each verdict's evidence before it could be shown."},
        {"agent": "Citation Gate", "action": "Verified every citation against the database."},
        {"agent": "Chat Composer", "action": "Wrote a plain-language summary of the findings."},
    ]
    reply = compose_evaluate_reply(design, report["findings"], report.get("overall_verdict"), mode_summary)
    citations = [
        {"guardrail_id": f["guardrail_id"], "clause_id": f["clause_id"], "label": f["verdict"]}
        for f in report["findings"]
        if f["clause_id"]
    ]
    return {"data": report, "trace": trace, "reply": reply, "citations": citations}


def explain_design(design: DesignDescription, question: str) -> str:
    """Answer a plain-language follow-up question about an already-attached
    design/diagram (e.g. "ELI5 this diagram") -- reuses the stored description
    instead of re-running the guardrail evaluation pipeline."""
    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Title: {design.title}\n\n"
                f"Description:\n{design.description}\n\n"
                f"User's question: {question.strip() or 'Explain this in simple terms (ELI5).'}"
            )
            result = llm_client.complete(
                "You are the CompliX chat assistant. Answer the user's question about this "
                "architecture in clear, simple language -- explain-like-I'm-5 style when asked. "
                "Use only the description given; don't invent components or data flows that "
                "aren't mentioned. Plain text only, 3-6 sentences.",
                user_prompt,
                {"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]},
            )
            answer = (result or {}).get("answer", "").strip()
            if answer:
                return answer
        except Exception as e:
            logger.warning("Explain: LLM call failed, using fallback: %s", e)
    return (
        f"Here's '{design.title}' in plain terms: {design.description} "
        "(The LLM wasn't available to simplify this further, so this is the description on file.)"
    )

