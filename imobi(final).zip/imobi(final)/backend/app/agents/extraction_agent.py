"""
Extraction Agent: Clause -> GuardrailDraft.

Tries the configured LLM gateway first (structured JSON output matching
GuardrailDraft); falls back to a deterministic modal-verb + numeric-value
heuristic when no LLM is configured or the call fails, so the pipeline never
silently produces nothing. Every draft always carries the literal clause and
document ID it came from -- extraction never invents a source.
"""
from __future__ import annotations

import logging
import re

from app.agents.schema import GuardrailDraft
from app.db.models import Clause
from app.knowledge.numeric import extract_numeric_requirement
from app.llm import client as llm_client

logger = logging.getLogger("guardrailiq")

_GUARDRAIL_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "statement": {"type": "string"},
        "category": {"type": "string"},
        "severity": {"type": "string", "enum": ["Low", "Medium", "High", "Mandatory"]},
        "instruction_type": {"type": "string"},
        "applicability": {"type": "string"},
        "not_applicable": {"type": "string"},
        "do_instructions": {"type": "string"},
        "dont_instructions": {"type": "string"},
        "trigger_conditions": {"type": "string"},
        "plain_language_guidance": {"type": "string"},
    },
    "required": ["statement", "severity"],
}

_SYSTEM_PROMPT = (
    "You are the Extraction Agent in GuardrailIQ, a governance-guardrail platform. "
    "Given one clause of a governance document, produce a single structured guardrail "
    "record: a plain-language requirement statement, its severity (Low/Medium/High/"
    "Mandatory, inferred from modal language like 'must'=Mandatory, 'should'="
    "Recommended/Medium, 'may'=Low), category, applicability, and do/don't guidance. "
    "Never invent a requirement that isn't supported by the clause text. Output only "
    "the JSON object described by the schema."
)

_BATCH_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "results": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "clause_id": {"type": "string"},
                    "statement": {"type": "string"},
                    "category": {"type": "string"},
                    "severity": {"type": "string", "enum": ["Low", "Medium", "High", "Mandatory"]},
                    "instruction_type": {"type": "string"},
                    "applicability": {"type": "string"},
                    "not_applicable": {"type": "string"},
                    "do_instructions": {"type": "string"},
                    "dont_instructions": {"type": "string"},
                    "trigger_conditions": {"type": "string"},
                    "plain_language_guidance": {"type": "string"},
                },
                "required": ["clause_id", "statement", "severity"],
            },
        },
    },
    "required": ["results"],
}

_BATCH_SYSTEM_PROMPT = (
    "You are the Extraction Agent in GuardrailIQ, a governance-guardrail platform. "
    "Given a list of clauses from governance documents, produce ONE structured "
    "guardrail record per clause: a plain-language requirement statement, its "
    "severity (Low/Medium/High/Mandatory, inferred from modal language like "
    "'must'=Mandatory, 'should'=Recommended/Medium, 'may'=Low), category, "
    "applicability, and do/don't guidance. Never invent a requirement that isn't "
    "supported by the clause text. Return one result per clause_id given, in the "
    "same order. Output only the JSON object described by the schema."
)

_MANDATORY_WORDS = re.compile(r"\bmust\b|\bshall\b|\brequired\b|\bmandatory\b", re.IGNORECASE)
_RECOMMENDED_WORDS = re.compile(r"\bshould\b|\brecommended\b", re.IGNORECASE)


def _heuristic_extract(clause: Clause) -> GuardrailDraft:
    text = clause.clause_text or ""
    if _MANDATORY_WORDS.search(text):
        severity, instruction_type = "Mandatory", "Mandatory"
    elif _RECOMMENDED_WORDS.search(text):
        severity, instruction_type = "Medium", "Recommended"
    else:
        severity, instruction_type = "Low", "Principle"

    numeric = extract_numeric_requirement(text)

    return GuardrailDraft(
        statement=text.strip(),
        domain=clause.document.domain if clause.document else "Unspecified",
        category=clause.clause_heading,
        severity=severity,
        instruction_type=instruction_type,
        applicability=clause.clause_heading,
        source_clause_id=clause.id,
        source_document_id=clause.document_id,
        normalized_metric_group=numeric["metric_group"] if numeric else None,
        normalized_value=numeric["value"] if numeric else None,
        normalized_raw_value=numeric["raw_value"] if numeric else None,
        normalized_unit=numeric["unit"] if numeric else None,
        normalized_label=numeric["label"] if numeric else None,
        normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
    )


def extract_guardrail(clause: Clause) -> GuardrailDraft:
    domain = clause.document.domain if clause.document else "Unspecified"
    numeric = extract_numeric_requirement(clause.clause_text or "")

    if llm_client.is_configured():
        try:
            user_prompt = (
                f"Clause heading: {clause.clause_heading}\n"
                f"Clause text: {clause.clause_text}\n"
                f"Domain: {domain}"
            )
            result = llm_client.complete(_SYSTEM_PROMPT, user_prompt, _GUARDRAIL_JSON_SCHEMA)
            return GuardrailDraft(
                statement=result.get("statement", clause.clause_text),
                domain=domain,
                category=result.get("category"),
                severity=result.get("severity", "Low"),
                instruction_type=result.get("instruction_type"),
                applicability=result.get("applicability"),
                not_applicable=result.get("not_applicable"),
                do_instructions=result.get("do_instructions"),
                dont_instructions=result.get("dont_instructions"),
                trigger_conditions=result.get("trigger_conditions"),
                plain_language_guidance=result.get("plain_language_guidance"),
                source_clause_id=clause.id,
                source_document_id=clause.document_id,
                normalized_metric_group=numeric["metric_group"] if numeric else None,
                normalized_value=numeric["value"] if numeric else None,
                normalized_raw_value=numeric["raw_value"] if numeric else None,
                normalized_unit=numeric["unit"] if numeric else None,
                normalized_label=numeric["label"] if numeric else None,
                normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
            )
        except Exception as e:
            logger.warning("Extraction Agent: LLM call failed for clause %s, using heuristic fallback: %s", clause.id, e)
            return _heuristic_extract(clause)

    return _heuristic_extract(clause)


def _draft_from_llm_item(clause: Clause, item: dict, numeric: dict | None) -> GuardrailDraft:
    domain = clause.document.domain if clause.document else "Unspecified"
    return GuardrailDraft(
        statement=item.get("statement", clause.clause_text),
        domain=domain,
        category=item.get("category"),
        severity=item.get("severity", "Low"),
        instruction_type=item.get("instruction_type"),
        applicability=item.get("applicability"),
        not_applicable=item.get("not_applicable"),
        do_instructions=item.get("do_instructions"),
        dont_instructions=item.get("dont_instructions"),
        trigger_conditions=item.get("trigger_conditions"),
        plain_language_guidance=item.get("plain_language_guidance"),
        source_clause_id=clause.id,
        source_document_id=clause.document_id,
        normalized_metric_group=numeric["metric_group"] if numeric else None,
        normalized_value=numeric["value"] if numeric else None,
        normalized_raw_value=numeric["raw_value"] if numeric else None,
        normalized_unit=numeric["unit"] if numeric else None,
        normalized_label=numeric["label"] if numeric else None,
        normalized_subgroup=numeric["semantic_subgroup"] if numeric else None,
    )


def extract_guardrails_batch(clauses: list[Clause]) -> list[GuardrailDraft]:
    """Same LLM-first, heuristic-fallback contract as extract_guardrail(), but
    as ONE LLM call for every clause instead of one call per clause -- this is
    the difference between ~50 requests and 1 against a rate-limited gateway,
    and it's what actually determines whether real LLM reasoning is available
    at all once a design-evaluation chat request comes in afterward."""
    if not clauses:
        return []

    numerics = {c.id: extract_numeric_requirement(c.clause_text or "") for c in clauses}

    if llm_client.is_configured():
        try:
            clause_block = "\n\n".join(
                f"clause_id: {c.id}\nclause_heading: {c.clause_heading}\nclause_text: {c.clause_text}\n"
                f"domain: {c.document.domain if c.document else 'Unspecified'}"
                for c in clauses
            )
            user_prompt = f"Clauses to extract from ({len(clauses)} total):\n\n{clause_block}"
            result = llm_client.complete(_BATCH_SYSTEM_PROMPT, user_prompt, _BATCH_JSON_SCHEMA)
            by_id = {item.get("clause_id"): item for item in result.get("results", []) if item.get("clause_id")}
            drafts = []
            for c in clauses:
                item = by_id.get(c.id)
                if item:
                    drafts.append(_draft_from_llm_item(c, item, numerics[c.id]))
                else:
                    logger.warning("Extraction Agent: batch response missing clause %s, using heuristic fallback.", c.id)
                    drafts.append(_heuristic_extract(c))
            return drafts
        except Exception as e:
            logger.warning("Extraction Agent: batch LLM call failed, using heuristic fallback for all %d clauses: %s", len(clauses), e)

    return [_heuristic_extract(c) for c in clauses]
