from __future__ import annotations

import base64

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.agents.chat_evaluate import evaluate_adhoc_design, explain_architecture, explain_design
from app.agents.orchestrator import handle_message
from app.agents.response_formatter import (
    build_summary_from_report,
    format_diagram_evaluation_response,
    format_not_architecture_response,
)
from app.db.models import DesignDescription
from app.db.session import get_session
from app.diagram.vision_extractor import VisionNotAvailable, extract_design_description
from app.ingestion.text_extractor import TextExtractionFailed, extract_text
from app.llm.client import LLMCallFailed
from app.mcp import runtime_servers

router = APIRouter(prefix="/chat", tags=["chat"])

_MAX_IMAGE_BYTES = 8 * 1024 * 1024  # 8MB
_MAX_TEXT_FILE_BYTES = 2 * 1024 * 1024  # 2MB
_ALLOWED_IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp", "image/gif"}


class ChatRequest(BaseModel):
    message: str


@router.post("")
def chat(req: ChatRequest):
    session = get_session()
    try:
        return handle_message(session, req.message)
    finally:
        session.close()


@router.post("/attach")
async def chat_attach(
    file: UploadFile = File(...),
    domain: str = Form("Information Security"),
    message: str = Form(""),
):
    """Attach an architecture diagram image to the conversation: the Diagram
    Agent describes it, and that description is evaluated exactly like a
    typed design -- same retrieval, same Evaluation/Auditor Agents, same
    citation gate. No sample diagram exists in the dataset; this only ever
    runs against what a user actually uploads. An optional `message` is the
    user's own question typed alongside the attachment -- it's folded into
    the design text so retrieval/evaluation can focus on what they asked."""
    if file.content_type not in _ALLOWED_IMAGE_TYPES:
        raise HTTPException(400, f"Unsupported image type '{file.content_type}'. Use PNG, JPEG, WEBP, or GIF.")
    contents = await file.read()
    if len(contents) > _MAX_IMAGE_BYTES:
        raise HTTPException(400, "Image too large (max 8MB).")

    trace = [{"agent": "Diagram Agent", "action": f"Analyzing the attached image '{file.filename}'..."}]
    try:
        extracted = extract_design_description(base64.b64encode(contents).decode("ascii"), file.content_type, file.filename)
    except VisionNotAvailable as e:
        return {"intent": "diagram", "reply": str(e), "data": None, "citations": [], "trace": trace}
    except LLMCallFailed as e:
        return {
            "intent": "diagram",
            "reply": f"The vision model is temporarily unavailable ({e}), so I couldn't read this diagram. "
            "Please try again shortly, or describe the architecture as text instead.",
            "data": None,
            "citations": [],
            "trace": trace,
        }

    trace[0]["action"] = f"Described the attached diagram '{file.filename}' in plain language."

    design_text = extracted["description"]
    if message.strip():
        trace.append({"agent": "Orchestrator", "action": f"Focused the evaluation on your question: \"{message.strip()}\""})
        design_text = f"{design_text}\n\nUser question about this diagram: {message.strip()}"

    session = get_session()
    try:
        overview, is_architecture = explain_architecture(extracted["description"], extracted["title"], message)
        if not is_architecture:
            trace.append({"agent": "Chat Composer", "action": "Determined this doesn't depict a system/architecture -- skipped guardrail evaluation."})
            return {**format_not_architecture_response(overview), "data": None, "citations": [], "trace": trace}

        result = evaluate_adhoc_design(session, extracted["title"], domain, design_text, "chat_attach")
        report = result["data"]
        summary, reasoning, checked_count, combined_results = build_summary_from_report(report)
        trace.append({"agent": "Chat Composer", "action": "Wrote a detailed explanation of the architecture."})

        # Format with structured sections
        formatted = format_diagram_evaluation_response(
            {"overview": overview},
            summary,
            combined_results,
            checked_count,
            verdict_reasoning=reasoning,
        )

        return {
            **formatted,
            "design_id": report.get("design_id"),
            "diagram_description": extracted["description"],
            "data": result["data"],
            "citations": result["citations"],
            "trace": trace + result["trace"],
        }
    finally:
        session.close()


class EvaluateTextRequest(BaseModel):
    title: str | None = None
    domain: str = "Information Security"
    description: str


@router.post("/evaluate-text")
def chat_evaluate_text(req: EvaluateTextRequest):
    """The 'describe your architecture' / 'upload a text file' path: evaluates
    the given text directly, rather than trying to match it against one of
    the sample designs the way a typed chat message asking to 'evaluate the
    X design' does."""
    if not req.description.strip():
        raise HTTPException(400, "Description is empty.")
    session = get_session()
    try:
        overview, is_architecture = explain_architecture(req.description, req.title or "Untitled design", "")
        if not is_architecture:
            return {**format_not_architecture_response(overview), "data": None, "citations": [], "trace": []}

        result = evaluate_adhoc_design(session, req.title or "Untitled design", req.domain, req.description, "chat_text")
        report = result["data"]
        summary, reasoning, checked_count, combined_results = build_summary_from_report(report)

        # Format with structured sections
        formatted = format_diagram_evaluation_response(
            {"overview": overview},
            summary,
            combined_results,
            checked_count,
            verdict_reasoning=reasoning,
        )

        return {
            **formatted,
            "design_id": report.get("design_id"),
            "data": result["data"],
            "citations": result["citations"],
            "trace": result["trace"],
        }
    finally:
        session.close()


@router.post("/attach-text-file")
async def chat_attach_text_file(
    file: UploadFile = File(...),
    domain: str = Form("Information Security"),
    message: str = Form(""),
):
    """A design document attached as a file -- plain text/markdown is read
    directly, PDF goes through text_extractor.py. No vision call needed."""
    is_pdf = (file.content_type == "application/pdf") or file.filename.lower().endswith(".pdf")
    is_text = (file.content_type or "").startswith("text/") or file.filename.lower().endswith((".txt", ".md"))
    if not is_pdf and not is_text:
        raise HTTPException(400, "Only plain text files (.txt, .md) or PDFs (.pdf) are supported for direct upload.")
    contents = await file.read()
    if len(contents) > _MAX_TEXT_FILE_BYTES:
        raise HTTPException(400, "File too large (max 2MB).")
    try:
        text = extract_text(contents, file.filename, file.content_type)
    except TextExtractionFailed as e:
        raise HTTPException(400, str(e))

    trace_prefix = []
    design_text = text
    if message.strip():
        trace_prefix.append({"agent": "Orchestrator", "action": f"Focused the evaluation on your question: \"{message.strip()}\""})
        design_text = f"{text}\n\nUser question about this document: {message.strip()}"

    session = get_session()
    try:
        overview, is_architecture = explain_architecture(text, file.filename, message)
        if not is_architecture:
            return {**format_not_architecture_response(overview), "data": None, "citations": [], "trace": trace_prefix}

        result = evaluate_adhoc_design(session, file.filename, domain, design_text, "chat_file")
        report = result["data"]
        summary, reasoning, checked_count, combined_results = build_summary_from_report(report)

        formatted = format_diagram_evaluation_response(
            {"overview": overview},
            summary,
            combined_results,
            checked_count,
            verdict_reasoning=reasoning,
        )

        return {
            **formatted,
            "design_id": report.get("design_id"),
            "data": result["data"],
            "citations": result["citations"],
            "trace": trace_prefix + result["trace"],
        }
    finally:
        session.close()


class ExplainRequest(BaseModel):
    design_id: str
    question: str = ""


@router.post("/explain")
def chat_explain(req: ExplainRequest):
    """Follow-up questions about an already-attached/described design (e.g. an
    'ELI5 this diagram' message with no new attachment) -- reuses the stored
    DesignDescription instead of re-running the full guardrail evaluation."""
    session = get_session()
    try:
        design = session.get(DesignDescription, req.design_id)
        if design is None:
            raise HTTPException(404, "That diagram/design isn't available anymore -- try attaching it again.")

        trace = [{"agent": "Orchestrator", "action": f"Answering a follow-up question about '{design.title}'."}]
        explanation = explain_design(design, req.question)
        trace.append({"agent": "Chat Composer", "action": "Wrote a plain-language explanation of the architecture."})

        return {
            "intent": "explain",
            "reply": explanation,
            "sections": [{"title": "Architecture Explained", "content": explanation}],
            "design_id": design.id,
            "data": None,
            "citations": [],
            "trace": trace,
        }
    finally:
        session.close()


class MCPIntegrationRequest(BaseModel):
    provider: str  # "jira" | "confluence"
    base_url: str
    email: str
    api_token: str


@router.get("/integrations")
def list_integrations():
    """Which external MCP integrations (Jira/Confluence) are currently
    attached -- provider names only, credentials never round-trip back to
    the frontend once submitted."""
    return {"connected": runtime_servers.connected_providers()}


@router.post("/integrations/attach")
def attach_integration(req: MCPIntegrationRequest):
    """Attach a Jira or Confluence connection live, so the chat Orchestrator's
    LLM calls can use it as a tool (see app/mcp/runtime_servers.py) -- e.g.
    "is this already tracked in Jira?" gets a real answer instead of a guess.
    In-memory only: the credentials are never written to disk, the database,
    or a log line, and are gone on backend restart."""
    try:
        runtime_servers.attach(req.provider, req.base_url, req.email, req.api_token)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"connected": runtime_servers.connected_providers()}


@router.post("/integrations/{provider}/detach")
def detach_integration(provider: str):
    runtime_servers.detach(provider)
    return {"connected": runtime_servers.connected_providers()}
