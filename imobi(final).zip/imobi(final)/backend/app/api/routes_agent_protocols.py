"""Exposes CompliX as a callable agent over two interoperability protocols,
in addition to the MCP server exposure in app/mcp/server.py:

- A2A (Agent2Agent, google-a2a): discovery via a well-known Agent Card, tasks
  submitted over a minimal JSON-RPC `tasks/send`.
- ACP (Agent Communication Protocol): discovery via GET /acp/agents, tasks
  submitted as a REST "run" via POST /acp/runs.

Both directions exist so any external agentic platform -- an A2A client, an
ACP-native orchestrator like BeeAI, a LangGraph/CrewAI adapter for either --
can add CompliX as a tool in its own multi-agent workflow, the same way a
person uses it through the chat UI. Both handlers call the exact same
Orchestrator.handle_message() the web UI's POST /chat uses: an external
platform never gets a different answer or a looser citation guarantee than a
human using the chat window (see the Citation Gate note in the README).
"""
from __future__ import annotations

import time
import uuid

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from app.agents.orchestrator import handle_message
from app.db.session import get_session

router = APIRouter(tags=["agent-protocols"])

_SKILLS = [
    {
        "id": "guardrail-search",
        "name": "Search guardrails",
        "description": "Find compliance guardrails by domain, severity, or keyword; every result cites its source clause.",
        "tags": ["compliance", "search", "information-security"],
        "examples": ["Show mandatory Information Security guardrails about encryption"],
    },
    {
        "id": "evaluate-design",
        "name": "Evaluate a design or architecture",
        "description": "Evaluate a described system design or architecture against the guardrail model; every verdict cites the guardrail/clause it came from.",
        "tags": ["compliance", "evaluation", "architecture"],
        "examples": ["Evaluate the public customer file share design"],
    },
    {
        "id": "conflict-check",
        "name": "Check open guardrail conflicts",
        "description": "List cross-document guardrail conflicts awaiting a human reviewer decision.",
        "tags": ["compliance", "conflicts"],
        "examples": ["Show me open conflicts"],
    },
]

_DESCRIPTION = (
    "Citation-gated compliance intelligence agent: answers guardrail questions, evaluates "
    "designs/architectures, and surfaces cross-document conflicts. Every verdict traces back "
    "to a real guardrail and source clause in the underlying document set -- no ungrounded answers."
)


def _agent_card(base_url: str) -> dict:
    return {
        "name": "CompliX Compliance Agent",
        "description": _DESCRIPTION,
        "url": f"{base_url}a2a",
        "version": "0.1.0",
        "provider": {"organization": "CompliX", "url": base_url},
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes": ["text"],
        "defaultOutputModes": ["text"],
        "skills": _SKILLS,
    }


@router.get("/.well-known/agent.json")
def a2a_agent_card(request: Request):
    """A2A discovery document. Any A2A-compatible client points at this URL
    (or at `{base_url}` directly, per the spec's well-known-path convention)
    to discover CompliX's skills and where to send tasks."""
    return _agent_card(str(request.base_url))


class A2APart(BaseModel):
    type: str = "text"
    text: str = ""


class A2ARpcRequest(BaseModel):
    jsonrpc: str = "2.0"
    id: str | int | None = None
    method: str
    params: dict | None = None


def _extract_text_from_parts(parts: list) -> str:
    return "\n".join(
        (p.get("text") or "") for p in parts if isinstance(p, dict) and p.get("type", "text") == "text"
    ).strip()


@router.post("/a2a")
def a2a_endpoint(req: A2ARpcRequest):
    """Minimal synchronous A2A task runner: only `tasks/send`, matching the
    non-streaming capabilities declared in the Agent Card. No task store --
    each call is answered and returned in the same request, which is all a
    single-turn compliance question needs."""
    if req.method != "tasks/send":
        return {
            "jsonrpc": "2.0",
            "id": req.id,
            "error": {"code": -32601, "message": f"Method '{req.method}' not supported here (only tasks/send)."},
        }

    params = req.params or {}
    message = params.get("message") or {}
    text = _extract_text_from_parts(message.get("parts") or [])
    if not text:
        return {
            "jsonrpc": "2.0",
            "id": req.id,
            "error": {"code": -32602, "message": "params.message.parts must include at least one non-empty text part."},
        }

    task_id = params.get("id") or str(uuid.uuid4())
    session = get_session()
    try:
        result = handle_message(session, text)
    finally:
        session.close()

    return {
        "jsonrpc": "2.0",
        "id": req.id,
        "result": {
            "id": task_id,
            "sessionId": params.get("sessionId"),
            "status": {"state": "completed", "timestamp": time.time()},
            "artifacts": [
                {
                    "index": 0,
                    "parts": [{"type": "text", "text": result["reply"]}],
                    "metadata": {"citations": result.get("citations", []), "intent": result.get("intent")},
                }
            ],
            "history": [message],
        },
    }


class ACPPart(BaseModel):
    content_type: str = "text/plain"
    content: str = ""


class ACPMessage(BaseModel):
    parts: list[ACPPart]


class ACPRunRequest(BaseModel):
    agent_name: str
    input: list[ACPMessage]
    session_id: str | None = None


@router.get("/acp/agents")
def acp_agents(request: Request):
    """ACP discovery: same underlying agent as the A2A card above, described
    in ACP's manifest shape for ACP-native orchestrators to discover."""
    base_url = str(request.base_url)
    return {
        "agents": [
            {
                "name": "complix",
                "description": _DESCRIPTION,
                "input_content_types": ["text/plain"],
                "output_content_types": ["text/plain"],
                "metadata": {"skills": _SKILLS, "citation_gated": True, "provider_url": base_url},
            }
        ]
    }


@router.post("/acp/runs")
def acp_runs(req: ACPRunRequest):
    """ACP run creation. Synchronous -- returns status "completed" directly
    rather than a polling handle, since a chat answer here is always fast."""
    if req.agent_name != "complix":
        raise HTTPException(404, f"Unknown agent '{req.agent_name}'. Only 'complix' is available on this server.")

    text = "\n".join(part.content for msg in req.input for part in msg.parts if part.content.strip()).strip()
    if not text:
        raise HTTPException(400, "input must include at least one non-empty text part.")

    session = get_session()
    try:
        result = handle_message(session, text)
    finally:
        session.close()

    return {
        "run_id": str(uuid.uuid4()),
        "agent_name": "complix",
        "session_id": req.session_id,
        "status": "completed",
        "output": [
            {
                "parts": [{"content_type": "text/plain", "content": result["reply"]}],
                "metadata": {"citations": result.get("citations", []), "intent": result.get("intent")},
            }
        ],
    }
