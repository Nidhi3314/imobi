"""
Routes for architecture evaluation and generation.
"""
from __future__ import annotations

import base64
import logging
from typing import Any

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

from app.api.upload_utils import read_and_extract
from app.db.session import get_session
from app.generate.architecture_generator import (
    generate_reference_architecture,
    render_dot,
    render_mermaid,
)
from app.agents.response_formatter import format_diagram_evaluation_response
from app.vision.architecture_agent import evaluate_architecture, extract_facts

logger = logging.getLogger("guardrailiq")

router = APIRouter(prefix="/architecture", tags=["architecture"])


class ArchitectureEvaluateRequest(BaseModel):
    """Request for diagram evaluation with optional OCR text."""

    ocr_text: str | None = None


class ArchitectureGenerateRequest(BaseModel):
    """Request for reference architecture generation."""

    brief: str
    fmt: str = "mermaid"  # "mermaid" or "dot"


@router.post("/evaluate")
async def evaluate_diagram(file: UploadFile = File(...), ocr_text: str | None = None):
    """
    Evaluate an architecture diagram for compliance against guardrails.

    `ocr_text` is optional and only meant as a manual override (e.g. tests, or
    a caller that already ran its own OCR) -- left unset, extract_facts()
    runs Tesseract over the uploaded image itself.

    Returns:
        {
          "facts": ArchitectureFacts dict,
          "summary": {overall, counts},
          "results": [evaluation results with citations]
        }
    """
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "File must be an image (PNG, JPEG, WebP)")

    # Read and encode image
    image_bytes = await file.read()
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")

    # Extract facts from diagram (OCR runs automatically when ocr_text is None)
    facts = extract_facts(image_base64, ocr_text)

    # Evaluate against guardrails
    session = get_session()
    try:
        evaluation = evaluate_architecture(facts, session)
        
        # Format with enhanced response structure
        formatted = format_diagram_evaluation_response(
            evaluation.get("facts_description", {}),
            evaluation.get("summary", {}),
            evaluation.get("results", []),
            evaluation.get("checked_guardrails_count", 0),
        )
        
        return {
            **formatted,
            "facts_extracted": facts.to_dict(),
            "checked_guardrails_count": evaluation.get("checked_guardrails_count", 0),
        }
    finally:
        session.close()


@router.post("/generate")
def generate_architecture(req: ArchitectureGenerateRequest):
    """
    Generate a compliant-by-construction reference architecture from a brief
    (free text describing the system, or a set of parameters written as
    prose -- "a public web app with a Postgres database and S3 file storage
    in the EU" works the same way a full paragraph does).

    Returns both render formats regardless of `fmt` (cheap: no LLM call, just
    string building) so the frontend can show the live Mermaid diagram and
    still offer a DOT/Graphviz export -- e.g. for import into draw.io --
    without a second round trip.

    Returns:
        {
          "spec": architecture specification (nodes/edges/controls, each
                  citing the guardrail_id/clause_ref that justifies it),
          "format": "mermaid" or "dot" (echoes the request),
          "diagram": rendered diagram in the requested format,
          "diagram_mermaid": Mermaid syntax,
          "diagram_dot": Graphviz DOT syntax
        }
    """
    session = get_session()
    try:
        logger.info(f"Generate request received: brief={req.brief[:50]}, fmt={req.fmt}")

        # Generate from brief with guardrails retrieved from DB
        spec = generate_reference_architecture(req.brief, session=session)
        logger.info(f"Spec generated with {len(spec.get('nodes', []))} nodes")

        diagram_mermaid = render_mermaid(spec)
        diagram_dot = render_dot(spec)
        diagram = diagram_dot if req.fmt == "dot" else diagram_mermaid

        result = {
            "spec": spec,
            "format": req.fmt,
            "diagram": diagram,
            "diagram_mermaid": diagram_mermaid,
            "diagram_dot": diagram_dot,
        }
        logger.info("Returning result")

        return result
    except Exception as e:
        logger.exception(f"Error generating architecture: {e}")
        raise HTTPException(500, f"Architecture generation failed: {str(e)}")
    finally:
        session.close()


@router.post("/extract-brief")
async def extract_brief(file: UploadFile = File(...)):
    """
    Reads a .txt/.md/.pdf document and returns its text, so the Architecture
    Generator can prefill its brief from an uploaded doc instead of typed
    parameters -- extraction only, generation is still the separate,
    explicit POST /architecture/generate above (same pattern as
    /guardrails/admin/extract-file, minus the admin gate: this doesn't touch
    guardrail data, it's just a text-extraction convenience).
    """
    text = await read_and_extract(file)
    return {"text": text}
