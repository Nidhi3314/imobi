"""
Document listing (public read) and admin document management: adding a new
governance document, and bumping an existing one to a newer version. A
version bump writes a DocumentUpdateLog row, which the main app polls to pop
a "this document was updated" notification -- see routes_documents.updates_latest.
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, File, Header, HTTPException, UploadFile
from pydantic import BaseModel

from app import auth
from app.api.upload_utils import read_and_extract
from app.db.models import Clause, Document, DocumentUpdateLog
from app.db.session import get_session

router = APIRouter(prefix="/documents", tags=["documents"])
admin_router = APIRouter(prefix="/admin/documents", tags=["admin"])


def _serialize_document(d: Document) -> dict:
    return {
        "id": d.id,
        "title": d.title,
        "domain": d.domain,
        "document_type": d.document_type,
        "owner_function": d.owner_function,
        "version": d.version,
        "effective_date": d.effective_date,
        "status": d.status,
        "summary": d.summary,
    }


@router.get("")
def list_documents():
    session = get_session()
    try:
        return [_serialize_document(d) for d in session.query(Document).order_by(Document.title).all()]
    finally:
        session.close()


def _serialize_clause(c: Clause) -> dict:
    return {
        "id": c.id,
        "document_id": c.document_id,
        "clause_ref": c.clause_ref,
        "clause_heading": c.clause_heading,
        "clause_text": c.clause_text,
    }


@router.get("/{document_id}/clauses")
def list_document_clauses(document_id: str):
    """So an admin adding a guardrail can see which clause IDs are actually
    citable under a given document -- including any they've just hand-added
    below -- instead of guessing an ID that happens to exist."""
    session = get_session()
    try:
        rows = session.query(Clause).filter(Clause.document_id == document_id).order_by(Clause.id).all()
        return [_serialize_clause(c) for c in rows]
    finally:
        session.close()


@router.get("/updates/latest")
def latest_update():
    """Polled by the main app to decide whether to pop a 'document updated'
    notification -- compares this row's `id` against the last one the
    viewer has already seen (tracked client-side)."""
    session = get_session()
    try:
        row = session.query(DocumentUpdateLog).order_by(DocumentUpdateLog.id.desc()).first()
        if row is None:
            return None
        return {
            "id": row.id,
            "document_id": row.document_id,
            "document_title": row.document_title,
            "old_version": row.old_version,
            "new_version": row.new_version,
            "updated_by": row.updated_by,
            "created_at": row.created_at.isoformat() if row.created_at else None,
        }
    finally:
        session.close()


class CreateDocumentRequest(BaseModel):
    title: str
    domain: str
    document_type: str | None = None
    owner_function: str | None = None
    version: str = "1.0"
    effective_date: str | None = None
    status: str = "Active"
    summary: str | None = None


@admin_router.post("/extract-file")
async def extract_document_file(file: UploadFile = File(...), authorization: str | None = Header(default=None)):
    """Reads a .txt/.md/.pdf file and returns its text to prefill the Add
    Document form's summary field -- extraction only, the document itself
    is still created via the separate, explicit POST below."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
    finally:
        session.close()

    text = await read_and_extract(file)
    return {"text": text, "suggested_title": file.filename.rsplit(".", 1)[0]}


@admin_router.post("")
def create_document(req: CreateDocumentRequest, authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        doc = Document(
            id=f"DOC-{uuid.uuid4().hex[:8]}",
            title=req.title,
            domain=req.domain,
            document_type=req.document_type,
            owner_function=req.owner_function or admin.username,
            version=req.version,
            effective_date=req.effective_date,
            status=req.status,
            summary=req.summary,
        )
        session.add(doc)
        session.commit()
        return _serialize_document(doc)
    finally:
        session.close()


class CreateClauseRequest(BaseModel):
    clause_ref: str | None = None
    clause_heading: str | None = None
    clause_text: str


@admin_router.post("/{document_id}/clauses")
def create_clause(document_id: str, req: CreateClauseRequest, authorization: str | None = Header(default=None)):
    """Adds a real, citable clause under a document -- closing the loop so a
    hand-added document isn't just metadata with nothing a guardrail can
    actually cite. The returned clause_id is what to paste into Add
    Guardrail's source clause IDs field."""
    session = get_session()
    try:
        auth.require_admin(session, authorization)
        doc = session.get(Document, document_id)
        if doc is None:
            raise HTTPException(404, f"No document '{document_id}'")
        if not req.clause_text.strip():
            raise HTTPException(400, "Clause text is required.")

        clause = Clause(
            id=f"CL-{uuid.uuid4().hex[:8]}",
            document_id=document_id,
            clause_ref=req.clause_ref,
            clause_heading=req.clause_heading,
            clause_text=req.clause_text,
        )
        session.add(clause)
        session.commit()
        return _serialize_clause(clause)
    finally:
        session.close()


class VersionBumpRequest(BaseModel):
    new_version: str
    effective_date: str | None = None


@admin_router.post("/{document_id}/version")
def bump_version(document_id: str, req: VersionBumpRequest, authorization: str | None = Header(default=None)):
    session = get_session()
    try:
        admin = auth.require_admin(session, authorization)
        doc = session.get(Document, document_id)
        if doc is None:
            raise HTTPException(404, f"No document '{document_id}'")

        old_version = doc.version
        doc.version = req.new_version
        if req.effective_date:
            doc.effective_date = req.effective_date
        session.add(
            DocumentUpdateLog(
                document_id=doc.id,
                document_title=doc.title,
                old_version=old_version,
                new_version=req.new_version,
                updated_by=admin.username,
            )
        )
        session.commit()
        return _serialize_document(doc)
    finally:
        session.close()
