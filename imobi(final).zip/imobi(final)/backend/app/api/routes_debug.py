"""
A deliberately exposed hook onto the deterministic citation gate, for the
"inject a fake citation live" demo beat -- anyone (a judge included) can
type any guardrail_id/clause_id, including a made-up one, and see the gate's
real verdict. Read-only; never mutates anything.
"""
from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel

from app import config
from app.agents.citation_gate import check_citation
from app.agents.precedent_agent import learning_summary
from app.db.session import get_session
from app.llm import client as llm_client
from app.mcp import client_manager as mcp_client_manager

router = APIRouter(prefix="/debug", tags=["debug"])


class CitationCheckRequest(BaseModel):
    guardrail_id: str
    clause_id: str


@router.post("/citation-gate-check")
def citation_gate_check(req: CitationCheckRequest):
    session = get_session()
    try:
        ok, reason = check_citation(session, req.guardrail_id, req.clause_id)
        return {"passed": ok, "reason": reason}
    finally:
        session.close()


@router.get("/llm-status")
def llm_status():
    """Read-only visibility into which reasoning mode agents are actually
    running in -- deliberately not an editable settings endpoint (changing
    models/providers live would be one more thing to break during a demo).

    Three independent axes are reported: `mode` (LLM-backed vs. deterministic
    heuristic fallback for extraction/evaluation), `learning` (how much
    precedent from past human Conflict Desk decisions the Conflict Agent has
    actually accumulated and can draw on -- grows over time as reviewers
    decide tickets), and `mcp_servers` (external MCP servers -- e.g. Jira,
    Confluence via GUARDRAILIQ_MCP_SERVERS -- the chat Orchestrator's LLM
    calls can use as tools; names only, never the env/credentials)."""
    configured = llm_client.is_configured()
    session = get_session()
    try:
        learning = learning_summary(session)
    finally:
        session.close()
    return {
        "configured": configured,
        "mode": "llm" if configured else "heuristic_fallback",
        "model": config.LLM_MODEL if configured else None,
        "learning": learning,
        "mcp_servers": [s.get("name") for s in config.MCP_SERVERS],
    }
