from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    routes_admin,
    routes_agent_protocols,
    routes_architecture,
    routes_clauses,
    routes_conflicts,
    routes_dashboard,
    routes_debug,
    routes_documents,
    routes_evaluate,
    routes_guardrails,
    routes_ingest,
    routes_chat,
    routes_user,
)
from app.config import DEFAULT_DATASET_PATH
from app.db.models import Document
from app.db.session import get_session, init_db
from app.mcp.server import mcp as mcp_server
from app.pipeline import run_full_pipeline

logger = logging.getLogger("guardrailiq")

app = FastAPI(title="CompliX", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_guardrails.router)
app.include_router(routes_evaluate.router)
app.include_router(routes_evaluate.admin_router)
app.include_router(routes_conflicts.router)
app.include_router(routes_ingest.router)
app.include_router(routes_chat.router)
app.include_router(routes_debug.router)
app.include_router(routes_admin.router)
app.include_router(routes_dashboard.router)
app.include_router(routes_clauses.router)
app.include_router(routes_user.router)
app.include_router(routes_documents.router)
app.include_router(routes_documents.admin_router)
app.include_router(routes_architecture.router)
app.include_router(routes_agent_protocols.router)

# Same MCP server app/mcp/server.py exposes over stdio (see mcp_server.py for
# that entrypoint) -- also mounted here over SSE so a network-reachable MCP
# client (not just a host that can spawn a local subprocess) can connect
# directly to this running backend at /mcp/sse. Same tool functions, same
# DB/agent code either way -- no separate, looser path for "reached over the
# network" vs. "spawned as a local process."
app.mount("/mcp", mcp_server.sse_app())


@app.on_event("startup")
def startup():
    init_db()
    session = get_session()
    try:
        # A dev server restarts on every file save (--reload); re-running the
        # full LLM-backed ingestion pipeline each time burns through a
        # rate-limited gateway's quota before any real chat request gets a
        # turn. Once the default dataset is already loaded, skip straight to
        # serving it. Judge Mode's upload endpoint (routes_ingest.py) always
        # calls run_full_pipeline directly for a genuinely new file, so that
        # path is unaffected by this skip.
        if session.query(Document).count() > 0:
            logger.info("Startup: dataset already ingested, skipping re-ingestion.")
            return
        result = run_full_pipeline(session, DEFAULT_DATASET_PATH)
        logger.info("Startup ingestion of default dataset: %s", result)
    except Exception:
        logger.exception("Startup ingestion failed -- the app will still serve, but /guardrails may be empty.")
    finally:
        session.close()


@app.get("/health")
def health():
    return {"status": "ok"}
