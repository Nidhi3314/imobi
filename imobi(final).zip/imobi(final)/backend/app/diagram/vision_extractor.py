"""
Turns an uploaded architecture-diagram image into a design-description-
shaped text blob, then hands off to the exact same evaluation pipeline text
designs go through -- no separate evaluation logic for images. There's no
sample diagram in the provided dataset, so this only ever runs against
whatever a user actually attaches in chat.

OCR (app/vision/ocr_extractor.py) runs first and plays two roles here:
- When a vision LLM is configured, the OCR'd text is folded into its prompt
  as grounding, so exact on-diagram strings (secrets, IPs, default creds)
  aren't left to the model's paraphrase.
- When no LLM is configured, OCR text drives a conservative, deterministic
  description instead of hard-failing -- diagram analysis degrades to
  "read the labels" rather than "unavailable". Only when OCR *also* finds
  nothing (no Tesseract install, or a genuinely textless image) does this
  raise, because at that point there is no signal of any kind to evaluate.
"""
from __future__ import annotations

import base64
import logging

from app.llm import client as llm_client
from app.vision import ocr_extractor
from app.vision.architecture_agent import describe_ocr_text_as_design

logger = logging.getLogger("guardrailiq")


class VisionNotAvailable(RuntimeError):
    pass


_SYSTEM_PROMPT = (
    "You are the Diagram Agent in CompliX. You are given an architecture diagram image. "
    "Describe the system it depicts in plain language, as if writing a design description "
    "for a governance review: components, data flows, where data is hosted, what "
    "authentication/encryption/access-control measures are shown or implied, and any "
    "third parties or public-facing elements. Be concrete and only describe what is "
    "actually visible or clearly labeled in the diagram -- do not invent components. "
    "Output only the JSON object described by the schema."
)

_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "description": {"type": "string"},
    },
    "required": ["description"],
}


def extract_design_description(image_base64: str, mime_type: str, filename: str) -> dict:
    ocr_text = ocr_extractor.extract_text_from_image(base64.b64decode(image_base64))

    if llm_client.is_configured():
        text_prompt = f"Diagram file: {filename}. Describe it for a compliance review."
        if ocr_text:
            text_prompt += (
                "\n\nRaw OCR text detected in the image (grounding only -- treat exact strings "
                "here, like secrets/IPs/hostnames, as reliable even if the visual layout suggests "
                f"otherwise):\n{ocr_text}"
            )
        try:
            result = llm_client.complete_vision(_SYSTEM_PROMPT, text_prompt, image_base64, mime_type, _JSON_SCHEMA)
            return {
                "title": result.get("title") or filename,
                "description": result.get("description", ""),
            }
        except llm_client.LLMCallFailed as e:
            if not ocr_text:
                raise
            logger.warning("Vision LLM call failed for '%s' (%s) -- falling back to OCR-only description.", filename, e)

    if ocr_text:
        logger.info("No vision LLM configured for '%s' -- falling back to OCR-only description.", filename)
        return {
            "title": filename,
            "description": describe_ocr_text_as_design(ocr_text),
        }

    raise VisionNotAvailable(
        "Diagram analysis needs a connected vision-capable LLM, and none is configured right now. "
        "OCR was also unable to read any text from this image (Tesseract may not be installed), "
        "so there's nothing to evaluate."
    )
