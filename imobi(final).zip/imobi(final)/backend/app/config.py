import json as _json
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")  # local, git-ignored -- see .env.example

DB_PATH = os.environ.get("GUARDRAILIQ_DB_PATH", str(BASE_DIR / "guardrailiq.db"))
DATABASE_URL = f"sqlite:///{DB_PATH}"

# LLM gateway ("LLmass" or any OpenAI-compatible chat-completions endpoint).
# Left unset -> LLMClient falls back to deterministic regex/heuristic extraction,
# so the pipeline still runs end-to-end without live model access.
LLM_BASE_URL = os.environ.get("GUARDRAILIQ_LLM_BASE_URL", "")
LLM_API_KEY = os.environ.get("GUARDRAILIQ_LLM_API_KEY", "")
LLM_MODEL = os.environ.get("GUARDRAILIQ_LLM_MODEL", "gemini-3.6-flash")
LLM_VISION_MODEL = os.environ.get("GUARDRAILIQ_LLM_VISION_MODEL", LLM_MODEL)

# Optional explicit path to the Tesseract binary (see app/vision/ocr_extractor.py).
# Left unset -> pytesseract looks on PATH, then a couple of common Windows
# install locations; if none of those resolve, OCR is silently unavailable
# and diagram analysis falls back to the vision LLM alone.
TESSERACT_CMD = os.environ.get("GUARDRAILIQ_TESSERACT_CMD", "")

# Alternative gateway: LLMaaS, which trades a static API key for a short-lived
# OAuth2 client-credentials token plus a separate client-identifying header.
# Takes priority over LLM_BASE_URL/LLM_API_KEY above when both client id and
# secret are present (see app/llm/client.py for the token exchange).
LLMAAS_CLIENT_ID = os.environ.get("GUARDRAILIQ_LLMAAS_CLIENT_ID", "")
LLMAAS_CLIENT_SECRET = os.environ.get("GUARDRAILIQ_LLMAAS_CLIENT_SECRET", "")
LLMAAS_API_CLIENT_KEY = os.environ.get("GUARDRAILIQ_LLMAAS_API_CLIENT_KEY", "")
LLMAAS_TOKEN_URL = os.environ.get(
    "GUARDRAILIQ_LLMAAS_TOKEN_URL",
    "https://idp.cloud.vwgroup.com/auth/realms/kums-mfa/protocol/openid-connect/token",
)
LLMAAS_BASE_URL = os.environ.get("GUARDRAILIQ_LLMAAS_BASE_URL", "https://llmapi.ai.vwgroup.com")


# Dedup / conflict thresholds for the lexical (content-word-overlap) fallback used
# when no LLM is configured. Calibrated empirically against this dataset's short,
# single-sentence clauses (true duplicates and unrelated-but-topically-adjacent
# pairs both land in a narrow band for bag-of-words methods on sentence-length
# text) -- expect this fallback to be lower-recall than the LLM path, especially
# for conflicts phrased in very different vocabulary (see conflict_agent.py, which
# leans primarily on the normalized-metric/subgroup taxonomy rather than raw
# lexical similarity for exactly that reason).
DEDUP_SIMILARITY_THRESHOLD = float(os.environ.get("GUARDRAILIQ_DEDUP_THRESHOLD", "0.19"))
CONFLICT_TOPIC_SIMILARITY_THRESHOLD = float(os.environ.get("GUARDRAILIQ_CONFLICT_THRESHOLD", "0.06"))
RETRIEVAL_TOP_K = int(os.environ.get("GUARDRAILIQ_RETRIEVAL_TOP_K", "8"))

# External MCP servers the backend's own agents may call out to as tools
# during chat composition (app/mcp/client_manager.py) -- distinct from
# app/mcp/server.py, which exposes CompliX *as* an MCP server. A JSON array
# of {"name": str, "command": str, "args": [str], "env": {str: str}?}.
# Left unset (the default) -> no-op, same fallback pattern as the LLM itself.
_raw_mcp_servers = os.environ.get("GUARDRAILIQ_MCP_SERVERS", "")
try:
    MCP_SERVERS: list = _json.loads(_raw_mcp_servers) if _raw_mcp_servers.strip() else []
    if not isinstance(MCP_SERVERS, list):
        raise ValueError("GUARDRAILIQ_MCP_SERVERS must be a JSON array")
except Exception:
    MCP_SERVERS = []

DEFAULT_DATASET_PATH = os.environ.get(
    "GUARDRAILIQ_DATASET_PATH",
    str(BASE_DIR.parent / "AI-Powered Enterprise Compliance Intelligence System_GuardrailIQ_Dataset_v2.xlsx"),
)
