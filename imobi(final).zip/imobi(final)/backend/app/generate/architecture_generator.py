"""
Architecture Generation Agent: Generate compliant-by-construction architectures
from policy guardrails with citation grounding and diagram rendering.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from sqlalchemy.orm import Session

from app.db.models import Clause, Guardrail
from app.evaluation.retriever import retrieve_candidates
from app.llm import client as llm_client
from app.generate.prompts import ARCH_GENERATION_PROMPT

logger = logging.getLogger("guardrailiq")

# Default secure architecture template used when LLM unavailable
_DEFAULT_SECURE_TEMPLATE = {
    "title": "Default Secure Architecture",
    "description": "Baseline secure design with authentication gateway, HTTPS/mTLS on all boundaries, encryption-at-rest, managed secrets, audit logging.",
    "nodes": [
        {
            "id": "auth_gateway",
            "name": "Authentication Gateway",
            "type": "gateway",
            "description": "Entry point for all external requests; enforces authentication/MFA",
            "satisfies": [],
        },
        {
            "id": "api_service",
            "name": "API Service",
            "type": "service",
            "description": "Core business logic",
            "satisfies": [],
        },
        {
            "id": "data_db",
            "name": "Data Store",
            "type": "database",
            "description": "Persistent data with encryption-at-rest",
            "satisfies": [],
        },
        {
            "id": "secret_store",
            "name": "Secret Management",
            "type": "storage",
            "description": "Centralized credential/key storage",
            "satisfies": [],
        },
        {
            "id": "audit_log",
            "name": "Audit Log",
            "type": "storage",
            "description": "Immutable audit trail",
            "satisfies": [],
        },
    ],
    "boundaries": [
        {
            "id": "boundary_external",
            "name": "External Boundary",
            "description": "Separates internet from internal systems",
            "inside": ["api_service", "data_db", "secret_store", "audit_log"],
            "outside": ["auth_gateway"],
        }
    ],
    "edges": [
        {
            "id": "edge_client_to_gateway",
            "from": "client",
            "to": "auth_gateway",
            "protocol": "https",
            "encryption": "required",
            "authentication": "required",
            "description": "Client to auth gateway",
            "satisfies": [],
        },
        {
            "id": "edge_gateway_to_api",
            "from": "auth_gateway",
            "to": "api_service",
            "protocol": "https",
            "encryption": "required",
            "authentication": "required",
            "description": "Authenticated gateway to API (mTLS)",
            "satisfies": [],
        },
        {
            "id": "edge_api_to_db",
            "from": "api_service",
            "to": "data_db",
            "protocol": "tcp",
            "encryption": "required",
            "authentication": "required",
            "description": "API to database (encrypted connection)",
            "satisfies": [],
        },
    ],
    "controls": [
        {
            "id": "ctrl_encryption_rest",
            "name": "Encryption at Rest",
            "description": "All data stores use AES-256 encryption",
            "applied_to": ["data_db", "secret_store", "audit_log"],
            "satisfies": [],
        },
        {
            "id": "ctrl_mfa",
            "name": "Multi-Factor Authentication",
            "description": "MFA required for privileged access",
            "applied_to": ["auth_gateway", "secret_store"],
            "satisfies": [],
        },
        {
            "id": "ctrl_audit",
            "name": "Audit Logging",
            "description": "All sensitive operations logged with user/timestamp/action",
            "applied_to": ["api_service", "secret_store", "data_db"],
            "satisfies": [],
        },
        {
            "id": "ctrl_secret_management",
            "name": "Secret Management",
            "description": "All credentials stored in centralized secret manager, rotated regularly",
            "applied_to": ["secret_store"],
            "satisfies": [],
        },
    ],
    "baseline_choices": [
        {
            "concern": "Database encryption algorithm",
            "options": ["AES-256", "AES-192"],
            "rationale": "Both meet NIST standards; AES-256 preferred for higher security",
            "guardrail_references": [],
        }
    ],
    "gaps": [],
}


# (regex, node id, display name, type) -- matched against the brief when no
# LLM is available, so the deterministic path's diagram complexity actually
# tracks how much the brief describes instead of always returning the same
# fixed 5-node template regardless of input. Ordered so a more specific term
# (e.g. "postgres") is tried before a generic one that could also match it.
_COMPONENT_KEYWORDS: list[tuple[str, str, str, str]] = [
    (r"\bpostgres(?:ql)?\b", "db_postgres", "PostgreSQL Database", "database"),
    (r"\bmysql\b", "db_mysql", "MySQL Database", "database"),
    (r"\bmongo(?:db)?\b", "db_mongo", "MongoDB", "database"),
    (r"\bdynamo(?:db)?\b", "db_dynamo", "DynamoDB", "database"),
    (r"\b(?:oracle|mssql|sql server)\b", "db_sql", "SQL Database", "database"),
    (r"\bdata\s*warehouse\b", "data_warehouse", "Data Warehouse", "database"),
    (r"\bredis\b", "cache_redis", "Redis Cache", "cache"),
    (r"\b(?:memcached|in-memory cache)\b", "cache_generic", "Cache", "cache"),
    (r"\b(?:kafka|rabbitmq|sqs|message queue|event bus)\b", "queue", "Message Queue", "queue"),
    (r"\b(?:s3|blob storage|object storage|file storage)\b", "file_storage", "File Storage", "storage"),
    (r"\bcdn\b", "cdn", "CDN", "storage"),
    (r"\bpayments?\s*(?:microservice|service)?\b", "payments_service", "Payments Service", "service"),
    (r"\banalytics\s*(?:pipeline|service)?\b", "analytics_service", "Analytics Pipeline", "service"),
    (r"\bnotification\s*(?:service)?\b", "notification_service", "Notification Service", "service"),
    (r"\bsearch\s*(?:service|index)?\b", "search_service", "Search Service", "service"),
    (r"\bthird[- ]party\s*api\b", "external_api", "Third-Party API", "external"),
    (r"\badmin\s*console\b", "admin_console", "Admin Console", "client"),
    (r"\bmobile\s*(?:app|backend)\b", "mobile_client", "Mobile App", "client"),
    (r"\bweb\s*app\b", "web_client", "Web App", "client"),
]

# Generic "<Name> (micro)?service" catch-all for a service the keyword table
# above doesn't know by name -- lets a detailed brief with custom service
# names (e.g. "a fraud-scoring microservice") still show up as its own node
# instead of being silently dropped.
_GENERIC_SERVICE_RE = re.compile(r"\b([A-Za-z][A-Za-z0-9\-]{2,24})\s+microservice\b", re.IGNORECASE)

_MFA_RE = re.compile(r"\b(?:mfa|multi-?factor|sso|oauth2?|saml)\b", re.IGNORECASE)


def _slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")


def _generate_architecture_deterministic(brief: str) -> dict[str, Any]:
    """
    Parse the brief for recognizable components and assemble a spec whose
    size/shape actually reflects what was described, instead of returning
    the same fixed template regardless of input. This is the LLM-free path
    (see generate_reference_architecture) -- citations are attached
    separately by _cite_default_template, which works on any spec shaped
    like this one (matches controls by name, not by template identity).
    """
    nodes: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    def add_node(node_id: str, name: str, node_type: str) -> str:
        if node_id in seen_ids:
            return node_id
        seen_ids.add(node_id)
        nodes.append({"id": node_id, "name": name, "type": node_type, "description": "", "satisfies": []})
        return node_id

    client_ids = []
    if re.search(r"\bmobile\s*(?:app|backend)\b", brief, re.IGNORECASE):
        client_ids.append(add_node("mobile_client", "Mobile App", "client"))
    if re.search(r"\bweb\s*app\b", brief, re.IGNORECASE) or not client_ids:
        client_ids.append(add_node("client", "client", "client"))
    if re.search(r"\badmin\s*console\b", brief, re.IGNORECASE):
        client_ids.append(add_node("admin_console", "Admin Console", "client"))

    auth_gateway = add_node("auth_gateway", "Authentication Gateway", "gateway")
    api_service = add_node("api_service", "API Service", "service")

    backend_ids: list[str] = []
    for pattern, node_id, name, node_type in _COMPONENT_KEYWORDS:
        if node_type == "client":
            continue  # already handled above
        if re.search(pattern, brief, re.IGNORECASE):
            backend_ids.append(add_node(node_id, name, node_type))

    existing_names_lower = {n["name"].lower() for n in nodes}
    for match in _GENERIC_SERVICE_RE.finditer(brief):
        custom_name = match.group(1)
        node_id = f"svc_{_slugify(custom_name)}"
        # Skip anything the keyword table above already added (e.g. "payments
        # microservice" matches both the specific "payments" entry and this
        # generic catch-all -- don't double them up into two nodes).
        already_covered = node_id in seen_ids or any(
            custom_name.lower() in existing_name for existing_name in existing_names_lower
        )
        if already_covered or len(backend_ids) >= 8:
            continue
        backend_ids.append(add_node(node_id, f"{custom_name.title()} Microservice", "service"))

    # A datastore is always present -- every system persists something,
    # even a brief that doesn't name a specific technology.
    if not any(n["type"] in ("database", "cache") for n in nodes):
        backend_ids.append(add_node("data_db", "Data Store", "database"))

    secret_store = add_node("secret_store", "Secret Management", "storage")
    audit_log = add_node("audit_log", "Audit Log", "storage")

    edges: list[dict[str, Any]] = []

    def add_edge(from_id: str, to_id: str, protocol: str, encrypted: bool) -> None:
        edges.append(
            {
                "id": f"edge_{from_id}_{to_id}",
                "from": from_id,
                "to": to_id,
                "protocol": protocol,
                "encryption": "required" if encrypted else "optional",
                "authentication": "required",
                "description": "",
                "satisfies": [],
            }
        )

    for cid in client_ids:
        add_edge(cid, auth_gateway, "https", True)
    add_edge(auth_gateway, api_service, "https", True)
    for bid in backend_ids:
        node_type = next(n["type"] for n in nodes if n["id"] == bid)
        protocol = "https" if node_type in ("storage", "external", "service") else "tcp"
        add_edge(api_service, bid, protocol, True)
    add_edge(api_service, secret_store, "tcp", True)
    add_edge(api_service, audit_log, "tcp", True)

    # The gateway sits at the boundary itself (it's what the boundary
    # exists to enforce), not inside it -- same as the static template's
    # own boundary, which lists the gateway under "outside".
    external_service_ids = [n["id"] for n in nodes if n["type"] == "external"]
    outside_ids = set(client_ids) | set(external_service_ids) | {auth_gateway}
    internal_ids = [n["id"] for n in nodes if n["id"] not in outside_ids]

    boundaries = [
        {
            "id": "boundary_external",
            "name": "External Boundary",
            "description": "Separates internet-facing actors from internal systems",
            "inside": internal_ids,
            "outside": list(outside_ids),
        }
    ]

    controls = [
        {
            "id": "ctrl_encryption_rest",
            "name": "Encryption at Rest",
            "description": "All data stores use AES-256 encryption",
            "applied_to": [n["id"] for n in nodes if n["type"] in ("database", "cache", "storage")],
            "satisfies": [],
        },
        {
            "id": "ctrl_mfa",
            "name": "Multi-Factor Authentication",
            "description": "MFA required for privileged access",
            "applied_to": [auth_gateway] + [n["id"] for n in nodes if n["id"] == "admin_console"],
            "satisfies": [],
        },
        {
            "id": "ctrl_audit",
            "name": "Audit Logging",
            "description": "All sensitive operations logged with user/timestamp/action",
            "applied_to": [api_service, secret_store],
            "satisfies": [],
        },
        {
            "id": "ctrl_secret_management",
            "name": "Secret Management",
            "description": "All credentials stored in centralized secret manager, rotated regularly",
            "applied_to": [secret_store],
            "satisfies": [],
        },
    ]

    gaps = []
    if not _MFA_RE.search(brief):
        gaps.append(
            "The brief doesn't mention an authentication method (MFA/SSO/OAuth2) -- "
            "MFA is included as a default-secure baseline, not a cited requirement."
        )

    return {
        "title": "Reference Architecture",
        "description": (
            f"Assembled deterministically from the brief's own wording (no LLM available): "
            f"{len(nodes)} components identified across {len(backend_ids) + len(client_ids)} "
            "described entities, plus the standard secret-management/audit baseline."
        ),
        "nodes": nodes,
        "boundaries": boundaries,
        "edges": edges,
        "controls": controls,
        "baseline_choices": [
            {
                "concern": "Database encryption algorithm",
                "options": ["AES-256", "AES-192"],
                "rationale": "Both meet NIST standards; AES-256 preferred for higher security",
                "guardrail_references": [],
            }
        ],
        "gaps": gaps,
    }


def generate_reference_architecture(
    brief: str, guardrails: list[dict] | None = None, session: Session | None = None
) -> dict[str, Any]:
    """
    Generate a reference architecture from a brief and guardrails.
    Falls back to deterministic default-secure template if LLM unavailable.

    Args:
        brief: System description and requirements
        guardrails: List of guardrail dicts with id, statement, domain, etc.
                   If None, retrieves from database using brief as query.
        session: SQLAlchemy session for retrieval (required if guardrails is None)

    Returns:
        Spec dict with nodes, edges, controls, satisfies citations.
    """
    if guardrails is None and session is not None:
        # Retrieve guardrails from database using brief as query
        retrieval = retrieve_candidates(session, _FakeDesign(brief))
        guardrails = []
        for c in retrieval.shortlist:
            sources = []
            for s in c.guardrail.sources:
                clause = session.get(Clause, s.clause_id)
                doc_title = clause.document.title if clause and clause.document else s.document_id
                sources.append(
                    {
                        "document": doc_title,
                        "clause_ref": s.clause_id,
                        "clause_text": clause.clause_text if clause else "",
                    }
                )
            guardrails.append(
                {
                    "guardrail_id": c.guardrail.id,
                    "statement": c.guardrail.statement,
                    "domain": c.guardrail.domain,
                    "normalized_value": c.guardrail.normalized_value,
                    "sources": sources,
                }
            )
    elif guardrails is None:
        guardrails = []

    # Try LLM-based generation if configured -- attempted even with zero
    # retrieved guardrails (a generic/novel brief may just not match any
    # guardrail text well), since the LLM can still design a reasonable
    # architecture from the brief alone; _validate_citations below demotes
    # anything it cites that isn't actually in `guardrails` to baseline_choices
    # rather than trusting an uncited claim.
    if llm_client.is_configured():
        try:
            spec = _generate_architecture_llm(brief, guardrails)
            if session:
                spec = _validate_citations(spec, session, guardrails)
            spec["generation_mode"] = "llm"
            return spec
        except llm_client.LLMNotConfigured:
            pass
        except Exception as e:
            logger.warning(f"Architecture generation LLM call failed: {e}, using default template")

    # Deterministic fallback: parse the brief itself for recognizable
    # components (see _generate_architecture_deterministic) rather than
    # always returning the same fixed template regardless of input -- a
    # one-line brief still gets the secure baseline, a detailed one gets a
    # visibly bigger diagram. Citations still come from real guardrails
    # where the control names match (same logic the old static template
    # used, generalized -- it just matches on control name, not template
    # identity, so it works on this dynamically-built spec too).
    spec = _generate_architecture_deterministic(brief) if brief.strip() else json.loads(json.dumps(_DEFAULT_SECURE_TEMPLATE))
    if guardrails and session:
        spec = _cite_default_template(spec, guardrails, session)
    spec["generation_mode"] = "heuristic"
    return spec


def _generate_architecture_llm(brief: str, guardrails: list[dict]) -> dict[str, Any]:
    """Call LLM to generate architecture from brief and guardrails."""
    guardrails_text = json.dumps(guardrails, indent=2)
    prompt = f"""Brief:
{brief}

Available Guardrails:
{guardrails_text}

{ARCH_GENERATION_PROMPT}"""

    result = llm_client.complete(
        system="You are an expert security architect designing a compliant-by-construction system.",
        user=prompt,
        json_schema={
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "description": {"type": "string"},
                "nodes": {"type": "array"},
                "boundaries": {"type": "array"},
                "edges": {"type": "array"},
                "controls": {"type": "array"},
                "baseline_choices": {"type": "array"},
                "gaps": {"type": "array"},
            },
        },
    )

    return result


def _cite_default_template(spec: dict, guardrails: list[dict], session: Session) -> dict[str, Any]:
    """
    Augment default template with guardrail citations from database.
    """
    guardrail_map = {g["guardrail_id"]: g for g in guardrails}
    guardrail_db_map = {}
    for gr_id in guardrail_map:
        gr = session.get(Guardrail, gr_id)
        if gr:
            guardrail_db_map[gr_id] = gr

    # Find encryption/auth/audit guardrails and cite them
    for gr_id, gr_dict in guardrail_map.items():
        gr_db = guardrail_db_map.get(gr_id)
        if not gr_db or not gr_db.sources:
            continue

        statement_lower = gr_dict.get("statement", "").lower()
        domain = gr_dict.get("domain", "")

        # Map guardrails to default controls by keyword
        if any(kw in statement_lower for kw in ["encrypt", "aes", "cryptograph"]):
            # Encryption guardrail -> encryption-at-rest control
            for ctrl in spec.get("controls", []):
                if "encrypt" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

        if any(kw in statement_lower for kw in ["auth", "mfa", "multifactor"]):
            # Auth guardrail -> MFA control
            for ctrl in spec.get("controls", []):
                if "mfa" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

        if any(kw in statement_lower for kw in ["audit", "log", "logging"]):
            # Audit guardrail -> audit control
            for ctrl in spec.get("controls", []):
                if "audit" in ctrl.get("name", "").lower():
                    if "satisfies" not in ctrl:
                        ctrl["satisfies"] = []
                    source = gr_db.sources[0]
                    clause = session.get(Clause, source.clause_id)
                    doc_title = clause.document.title if clause and clause.document else source.document_id
                    ctrl["satisfies"].append(
                        {
                            "guardrail_id": gr_id,
                            "clause_ref": source.clause_id,
                            "document": doc_title,
                        }
                    )
                    break

    return spec


def _validate_citations(spec: dict, session: Session, provided_guardrails: list[dict]) -> dict[str, Any]:
    """
    Validate that all citations in the spec exist in provided_guardrails.
    Demote unvalidated citations to baseline_choices.
    """
    provided_ids = {g["guardrail_id"] for g in provided_guardrails}

    for component_list in [spec.get("nodes", []), spec.get("edges", []), spec.get("controls", [])]:
        for component in component_list:
            satisfies = component.get("satisfies", [])
            valid_satisfies = []
            invalid_satisfies = []

            for citation in satisfies:
                if citation.get("guardrail_id") in provided_ids:
                    valid_satisfies.append(citation)
                else:
                    invalid_satisfies.append(citation)

            component["satisfies"] = valid_satisfies

            # Move invalid citations to baseline_choices (no guardrail backing)
            if invalid_satisfies:
                concern = f"{component.get('name', 'Unknown')}: {component.get('description', '')}"
                spec.setdefault("baseline_choices", []).append(
                    {
                        "concern": concern,
                        "options": ["See architectural description"],
                        "rationale": "No matching guardrail in provided set; requires separate review",
                        "guardrail_references": invalid_satisfies,
                    }
                )

    return spec



# Mermaid node-shape delimiters per component type, chosen to echo the
# shape vocabulary a draw.io network/security stencil set uses (cylinder for
# datastores, hexagon for gateways/edge components, flag for storage,
# stadium for an external actor) rather than one generic box for everything.
_MERMAID_SHAPE = {
    "gateway": ("{{", "}}"),
    "auth": ("{{", "}}"),
    "database": ("[(", ")]"),
    "cache": ("[(", ")]"),
    "storage": ("[/", "/]"),
    "queue": ("[/", "/]"),
    "client": ("([", "])"),
    "external": ("([", "])"),
}
_MERMAID_DEFAULT_SHAPE = ("(", ")")  # service and anything unrecognized

# Every type shares one neutral style -- shape (see _MERMAID_SHAPE above) is
# what distinguishes a component's role, the way an uncolored draw.io
# stencil diagram relies on outline/icon rather than a fill-color key.
_MERMAID_NEUTRAL_STYLE = "fill:#f9fafb,stroke:#374151,stroke-width:1.5px,color:#111827"


def _mermaid_node_line(node_id: str, name: str, node_type: str) -> str:
    open_shape, close_shape = _MERMAID_SHAPE.get(node_type, _MERMAID_DEFAULT_SHAPE)
    safe_name = name.replace('"', "'")
    return f'    {node_id}{open_shape}"{safe_name}"{close_shape}'


def render_mermaid(spec: dict) -> str:
    """
    Render architecture spec to Mermaid diagram syntax for frontend
    rendering -- styled like a draw.io security/network board: a distinct
    shape and color per component type, trust boundaries drawn as grouped
    container boxes (Mermaid subgraphs) instead of flattening everything
    into one undifferentiated lane, and edges that visually flag an
    unencrypted hop instead of treating every connection the same.
    """
    lines = ["graph TB"]

    node_types: dict[str, str] = {}
    boundary_members: set[str] = set()

    # Trust boundaries first, as subgraph containers -- draw.io's equivalent
    # of a dashed "zone" box grouping the components inside it.
    for boundary in spec.get("boundaries", []):
        b_id = boundary.get("id", "boundary")
        b_name = boundary.get("name", "Boundary")
        inside_ids = set(boundary.get("inside", []))
        nodes_by_id = {n.get("id"): n for n in spec.get("nodes", [])}

        # No emoji in the subgraph title: Mermaid's label-width estimate
        # undercounts emoji width and clips the text at the box edge -- the
        # dashed border + lock-styled edges already signal "trust boundary"
        # without it. (The title can still clip a couple characters on a
        # narrow box -- a known Mermaid sizing quirk with subgraph titles,
        # not fixed by padding; cosmetic only.)
        lines.append(f'    subgraph {b_id} ["{b_name}"]')
        for node_id in inside_ids:
            node = nodes_by_id.get(node_id)
            if node is None:
                continue
            node_type = node.get("type", "service")
            node_types[node_id] = node_type
            boundary_members.add(node_id)
            lines.append(_mermaid_node_line(node_id, node.get("name", node_id), node_type))
        lines.append("    end")

    # Every node not already placed inside a boundary subgraph.
    for node in spec.get("nodes", []):
        node_id = node.get("id", "")
        if node_id in boundary_members:
            continue
        node_type = node.get("type", "service")
        node_types[node_id] = node_type
        lines.append(_mermaid_node_line(node_id, node.get("name", node_id), node_type))

    # Edges -- solid + lock for an encrypted/authenticated hop, dashed +
    # warning for one that isn't, so a compliance gap is visible in the
    # diagram itself rather than only in the findings list beside it.
    edge_lines: list[str] = []
    for edge in spec.get("edges", []):
        from_id = edge.get("from", "")
        to_id = edge.get("to", "")
        if from_id not in node_types and from_id:
            node_types[from_id] = "client"
            lines.append(_mermaid_node_line(from_id, from_id, "client"))
        if to_id not in node_types and to_id:
            node_types[to_id] = "service"
            lines.append(_mermaid_node_line(to_id, to_id, "service"))

        protocol = edge.get("protocol", "tcp").upper()
        encrypted = edge.get("encryption") == "required"
        label = f"{protocol} {'🔒' if encrypted else '⚠️ unencrypted'}"
        arrow = "-->" if encrypted else "-.->"
        edge_lines.append(f"    {from_id} {arrow}|{label}| {to_id}")

    lines.extend(edge_lines)

    # One neutral classDef applied to every node -- shape alone carries the
    # type distinction (see _MERMAID_SHAPE), applied last so it isn't
    # shadowed by subgraph declaration order.
    lines.append(f"    classDef default {_MERMAID_NEUTRAL_STYLE};")
    for node_id in node_types:
        lines.append(f"    class {node_id} default;")

    return "\n".join(lines)


def render_dot(spec: dict) -> str:
    """
    Render architecture spec to Graphviz DOT syntax (for PNG/SVG export).
    """
    lines = [
        "digraph architecture {",
        '  rankdir=TB;',
        '  node [shape=box, style=rounded];',
        '  edge [fontsize=10];',
        "",
    ]

    # Add nodes with labels
    for node in spec.get("nodes", []):
        node_id = node.get("id", "")
        name = node.get("name", "")
        node_type = node.get("type", "service")

        # Shape and color by type
        if node_type in ("gateway", "auth"):
            shape = "component"
            color = "#ffcccc"
        elif node_type in ("database", "cache"):
            shape = "cylinder"
            color = "#ccffcc"
        elif node_type in ("storage", "queue"):
            shape = "box"
            color = "#ffffcc"
        elif node_type in ("client", "external"):
            shape = "ellipse"
            color = "#e5e5e5"
        else:
            shape = "box"
            color = "#ccccff"

        satisfies_count = len(node.get("satisfies", []))
        label = f"{name}" + (f"\\n[{satisfies_count} cites]" if satisfies_count else "")
        lines.append(
            f'  {node_id} [label="{label}", shape={shape}, fillcolor="{color}", style="rounded,filled"];'
        )

    lines.append("")

    # Add edges with labels
    for edge in spec.get("edges", []):
        from_id = edge.get("from", "")
        to_id = edge.get("to", "")
        protocol = edge.get("protocol", "tcp").upper()
        encryption = "ENC" if edge.get("encryption") == "required" else ""
        label = f"{protocol}\\n{encryption}".strip()

        lines.append(f'  {from_id} -> {to_id} [label="{label}"];')

    lines.append("}")
    return "\n".join(lines)


class _FakeDesign:
    """Minimal design stand-in for retrieval.retrieve_candidates()."""

    def __init__(self, text: str):
        self.description = text
        self.domain = "Information Security"
