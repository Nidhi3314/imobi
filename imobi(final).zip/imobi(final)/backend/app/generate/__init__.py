"""Architecture generation module."""
