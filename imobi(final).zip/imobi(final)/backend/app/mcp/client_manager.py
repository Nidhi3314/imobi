"""
Lets the backend's own agents call out to *external* MCP servers as tools
during chat composition -- the mirror image of app/mcp/server.py, which
exposes CompliX itself as an MCP server.

Config-driven and optional by design, the same way the LLM gateway is:
GUARDRAILIQ_MCP_SERVERS unset means list_tools() returns [] and every
caller's existing "no tools" code path runs unchanged (see
llm/client.py's complete_with_tools and orchestrator.py's
_compose_search_with_llm).

Deliberately scoped away from anything that produces a compliance verdict
or citation: this only feeds prose composition (e.g. "search results"
commentary), never the Evaluation/Auditor/Citation-Gate chain, so an
external tool's output can never itself become an ungrounded finding --
citations still come straight from guardrail/clause records, never from
tool output or model prose.

Each call spins up a fresh stdio subprocess per configured server rather
than holding a long-lived connection across the sync request lifecycle --
simpler and correct, at the cost of per-call startup latency, which is an
acceptable trade for a hackathon-scoped feature over a persistent connection
pool.
"""
import asyncio
import json
import logging
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from app import config
from app.mcp import runtime_servers

logger = logging.getLogger("guardrailiq")

_TOOL_NAME_SEP = "__"  # "<server_name>__<tool_name>" -- qualifies tools across servers


def _all_servers() -> list[dict[str, Any]]:
    """Static env-configured servers plus whatever's been attached live from
    the chat UI (see app/mcp/runtime_servers.py) -- both feed the same
    tool-calling path identically."""
    return [*config.MCP_SERVERS, *runtime_servers.runtime_mcp_servers()]


def is_configured() -> bool:
    return bool(_all_servers())


def _server_params(server_cfg: dict) -> StdioServerParameters:
    return StdioServerParameters(
        command=server_cfg["command"],
        args=server_cfg.get("args", []),
        env=server_cfg.get("env") or None,
    )


async def _list_tools_for_server(server_cfg: dict) -> list[dict[str, Any]]:
    name = server_cfg["name"]
    try:
        async with stdio_client(_server_params(server_cfg)) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.list_tools()
                return [
                    {
                        "type": "function",
                        "function": {
                            "name": f"{name}{_TOOL_NAME_SEP}{tool.name}",
                            "description": tool.description or "",
                            "parameters": tool.inputSchema or {"type": "object", "properties": {}},
                        },
                    }
                    for tool in result.tools
                ]
    except Exception as e:
        logger.warning("MCP server '%s' unreachable, skipping its tools: %s", name, e)
        return []


async def _call_tool_async(qualified_name: str, arguments: dict) -> str:
    if _TOOL_NAME_SEP not in qualified_name:
        return f"Error: '{qualified_name}' is not a valid qualified MCP tool name."
    server_name, tool_name = qualified_name.split(_TOOL_NAME_SEP, 1)
    server_cfg = next((s for s in _all_servers() if s["name"] == server_name), None)
    if server_cfg is None:
        return f"Error: no configured MCP server named '{server_name}'."

    try:
        async with stdio_client(_server_params(server_cfg)) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                parts = [c.text for c in result.content if getattr(c, "type", None) == "text"]
                return "\n".join(parts) if parts else json.dumps([c.model_dump() for c in result.content])
    except Exception as e:
        logger.warning("MCP tool call '%s' failed: %s", qualified_name, e)
        return f"Error calling '{qualified_name}': {e}"


def list_tools() -> list[dict[str, Any]]:
    """OpenAI tool-calling-shaped schemas for every tool on every configured
    server. [] when unconfigured or every server is unreachable -- callers
    treat that exactly like "no tools" (see llm/client.py)."""
    servers = _all_servers()
    if not servers:
        return []
    tools: list[dict[str, Any]] = []
    for server_cfg in servers:
        tools.extend(asyncio.run(_list_tools_for_server(server_cfg)))
    return tools


def call_tool(qualified_name: str, arguments: dict) -> str:
    """Synchronous wrapper: dispatches a "<server>__<tool>" call and returns
    its text content (or an "Error: ..." string on failure -- never raises,
    since this feeds back into an LLM tool-call loop that should be able to
    react to a failed call rather than crash the whole request)."""
    return asyncio.run(_call_tool_async(qualified_name, arguments))
