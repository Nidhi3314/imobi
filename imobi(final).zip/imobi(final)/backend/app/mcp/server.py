"""
Exposes CompliX as an MCP server: an MCP client (Claude Desktop, Claude Code,
or any other MCP host) can list guardrails, evaluate a design description,
check open Conflict Desk tickets, and ask the same Orchestrator chat handles
in the web app -- all as tools, over stdio.

This is a thin wrapper, not a parallel implementation: every tool below
calls straight into the same agent/DB code the FastAPI routes use (reusing
their `_serialize` helpers where one already exists), so an MCP client and
the web UI never see different shapes of the same data, and every finding
still comes from the same citation-gated pipeline -- there is no separate,
looser code path for "when a tool calls it."

Run with `python mcp_server.py` from `backend/` (see that file), or
`python -m app.mcp.server`. Point an MCP host's config at that command; the
DB path/LLM config come from the same .env this backend already uses.

Deliberately does NOT use `from __future__ import annotations`: the
installed mcp version's tool introspection calls `issubclass()` directly on
parameter annotations, which breaks if they're postponed-evaluation strings
instead of real type objects.
"""
import logging

from mcp.server.fastmcp import FastMCP

from app.agents.chat_evaluate import evaluate_adhoc_design
from app.agents.orchestrator import handle_message
from app.api.routes_conflicts import _serialize as _serialize_ticket
from app.api.routes_guardrails import _serialize as _serialize_guardrail
from app.conflicts.decision_store import list_tickets
from app.db.models import Guardrail
from app.db.session import get_session, init_db

logger = logging.getLogger("guardrailiq")

mcp = FastMCP(
    name="complix",
    instructions=(
        "CompliX turns governance documents into a traceable guardrail model and evaluates "
        "design descriptions against it -- every finding cites the exact guardrail and source "
        "clause it came from. Use list_guardrails/get_guardrail to browse the knowledge model, "
        "evaluate_design to check a design description for compliance (Compliant/Non-compliant/"
        "Gap, each with a citation), list_open_conflicts for cross-document requirement clashes "
        "awaiting human review, and ask_complix for anything else in natural language."
    ),
)


@mcp.tool()
def list_guardrails(domain: str | None = None, severity: str | None = None, query: str | None = None) -> list[dict]:
    """List guardrails, optionally filtered by domain, severity, or a text search over the statement."""
    session = get_session()
    try:
        q = session.query(Guardrail)
        if domain:
            q = q.filter(Guardrail.domain == domain)
        if severity:
            q = q.filter(Guardrail.severity == severity)
        guardrails = q.all()
        if query:
            ql = query.lower()
            guardrails = [g for g in guardrails if ql in (g.statement or "").lower()]
        return [_serialize_guardrail(g) for g in guardrails]
    finally:
        session.close()


@mcp.tool()
def get_guardrail(guardrail_id: str) -> dict:
    """Fetch one guardrail by ID, including its source clauses/documents and merge history."""
    session = get_session()
    try:
        g = session.get(Guardrail, guardrail_id)
        if g is None:
            return {"error": f"No guardrail '{guardrail_id}'."}
        return _serialize_guardrail(g)
    finally:
        session.close()


@mcp.tool()
def list_domains() -> list[str]:
    """List every domain guardrails are grouped under (e.g. Information Security, Privacy)."""
    session = get_session()
    try:
        rows = session.query(Guardrail.domain).distinct().all()
        return sorted({r[0] for r in rows})
    finally:
        session.close()


@mcp.tool()
def evaluate_design(title: str, domain: str, description: str) -> dict:
    """Evaluate a design description against CompliX guardrails. Runs the full
    Retriever -> Evaluation Agent -> Auditor Agent -> Citation Gate pipeline and
    returns a per-guardrail verdict (Compliant/Non-compliant/Gap), each with the
    source clause it's grounded in -- no ungrounded verdicts."""
    if not description.strip():
        return {"error": "description is empty."}
    session = get_session()
    try:
        result = evaluate_adhoc_design(session, title, domain, description, "mcp")
        report = result["data"]
        return {
            "design_id": report.get("design_id"),
            "overall_verdict": report.get("overall_verdict"),
            "findings": report.get("findings"),
            "summary": result.get("reply"),
        }
    finally:
        session.close()


@mcp.tool()
def list_open_conflicts() -> list[dict]:
    """List open Conflict Desk tickets: cross-document guardrails that disagree
    on the same requirement, awaiting a human reviewer's decision."""
    session = get_session()
    try:
        return [_serialize_ticket(t, session) for t in list_tickets(session, status="open")]
    finally:
        session.close()


@mcp.tool()
def ask_complix(message: str) -> dict:
    """Ask CompliX's chat Orchestrator a natural-language question -- it routes to
    guardrail search, conflict listing, or design evaluation as appropriate, the
    same way the web app's chat does."""
    session = get_session()
    try:
        result = handle_message(session, message)
        return {
            "reply": result.get("reply"),
            "intent": result.get("intent"),
            "citations": result.get("citations"),
        }
    finally:
        session.close()


def main() -> None:
    logging.basicConfig(level=logging.WARNING)  # stdio transport: keep stdout clean for the protocol
    init_db()
    mcp.run()


if __name__ == "__main__":
    main()
