"""
Lets a user attach an external MCP integration (Jira, Confluence) live from
the chat UI, instead of only via the static GUARDRAILIQ_MCP_SERVERS env var
set at backend startup (see app/config.py). In-memory only -- credentials
are never written to disk, the database, or a log line, and are cleared on
backend restart, the same trust boundary the LLMaaS token cache in
app/llm/client.py already uses. Appropriate for a local/demo deployment;
a real multi-user production deployment would need this scoped per user
session and stored somewhere more durable than process memory, not shared
process-wide the way it is here.

Both providers map onto the same underlying MCP server
(sooperset/mcp-atlassian, see README's MCP section) -- attaching Jira and/or
Confluence just changes which JIRA_*/CONFLUENCE_* env vars that one server
gets started with.
"""
from __future__ import annotations

import threading
from typing import Any

PROVIDERS = {"jira", "confluence"}

_lock = threading.Lock()
_credentials: dict[str, dict[str, str]] = {}  # provider -> {base_url, email, api_token}


def attach(provider: str, base_url: str, email: str, api_token: str) -> None:
    if provider not in PROVIDERS:
        raise ValueError(f"Unknown provider '{provider}'. Expected one of: {sorted(PROVIDERS)}.")
    if not base_url.strip() or not email.strip() or not api_token.strip():
        raise ValueError("Site URL, email, and API token are all required.")
    with _lock:
        _credentials[provider] = {
            "base_url": base_url.strip().rstrip("/"),
            "email": email.strip(),
            "api_token": api_token,
        }


def detach(provider: str) -> None:
    with _lock:
        _credentials.pop(provider, None)


def connected_providers() -> list[str]:
    with _lock:
        return sorted(_credentials.keys())


def runtime_mcp_servers() -> list[dict[str, Any]]:
    """Builds the single mcp-atlassian server entry (see
    app/mcp/client_manager.py's config shape) from whichever Jira/Confluence
    credentials are currently attached, or [] if none are."""
    with _lock:
        creds = {k: dict(v) for k, v in _credentials.items()}
    if not creds:
        return []

    env: dict[str, str] = {}
    if "jira" in creds:
        env["JIRA_URL"] = creds["jira"]["base_url"]
        env["JIRA_USERNAME"] = creds["jira"]["email"]
        env["JIRA_API_TOKEN"] = creds["jira"]["api_token"]
    if "confluence" in creds:
        env["CONFLUENCE_URL"] = creds["confluence"]["base_url"]
        env["CONFLUENCE_USERNAME"] = creds["confluence"]["email"]
        env["CONFLUENCE_API_TOKEN"] = creds["confluence"]["api_token"]

    return [{"name": "atlassian", "command": "uvx", "args": ["mcp-atlassian"], "env": env}]
