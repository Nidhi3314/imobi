#!/usr/bin/env python3
"""
Quick test to demonstrate enhanced response formatting across all endpoints.
"""
import json
import requests

BASE_URL = "http://127.0.0.1:8000"

def test_chat_search():
    """Test formatted guardrail search response."""
    print("\n" + "="*70)
    print("TEST 1: Guardrail Search (Formatted Response)")
    print("="*70)
    
    response = requests.post(f"{BASE_URL}/chat", json={"message": "encryption requirements"})
    if response.status_code == 200:
        data = response.json()
        print(f"\n✅ Intent: {data.get('intent')}")
        print(f"✅ Has sections: {bool(data.get('sections'))}")
        print(f"✅ Summary: {data.get('summary')[:100]}...")
        if data.get('sections'):
            for section in data['sections']:
                print(f"\n📋 Section: {section.get('title')}")
                content = section.get('content', '')
                if isinstance(content, list):
                    for item in content[:2]:
                        print(f"   {item[:70]}...")
                else:
                    print(f"   {str(content)[:100]}...")
    else:
        print(f"❌ Error: {response.status_code}")

def test_chat_conflicts():
    """Test formatted conflict response."""
    print("\n" + "="*70)
    print("TEST 2: Conflict Analysis (Formatted Response)")
    print("="*70)
    
    response = requests.post(f"{BASE_URL}/chat", json={"message": "check conflicts"})
    if response.status_code == 200:
        data = response.json()
        print(f"\n✅ Intent: {data.get('intent')}")
        print(f"✅ Has sections: {bool(data.get('sections'))}")
        print(f"✅ Summary: {data.get('summary')[:100]}...")
        if data.get('sections'):
            for section in data['sections'][:2]:
                print(f"\n📋 Section: {section.get('title')}")
                content = section.get('content', '')
                print(f"   {str(content)[:100]}...")
    else:
        print(f"❌ Error: {response.status_code}")

def test_chat_smalltalk():
    """Test formatted small talk response."""
    print("\n" + "="*70)
    print("TEST 3: Small Talk (Formatted Response)")
    print("="*70)
    
    response = requests.post(f"{BASE_URL}/chat", json={"message": "hey there"})
    if response.status_code == 200:
        data = response.json()
        print(f"\n✅ Intent: {data.get('intent')}")
        print(f"✅ Has sections: {bool(data.get('sections'))}")
        print(f"✅ Summary: {data.get('summary')}")
        if data.get('sections'):
            for section in data['sections']:
                print(f"\n📋 Section: {section.get('title')}")
                print(f"   {section.get('content')}")
    else:
        print(f"❌ Error: {response.status_code}")

def test_health():
    """Test health endpoint."""
    print("\n" + "="*70)
    print("SYSTEM HEALTH CHECK")
    print("="*70)
    
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=3)
        if response.status_code == 200:
            print("✅ Backend is running at http://127.0.0.1:8000")
        else:
            print(f"❌ Backend returned status {response.status_code}")
    except Exception as e:
        print(f"❌ Cannot connect to backend: {e}")
        print("   Make sure to start backend with: python -m uvicorn app.main:app --host 127.0.0.1 --port 8000")

if __name__ == "__main__":
    print("\n🚀 Testing Enhanced Response Formatting")
    print("All responses now have consistent, well-formatted structure\n")
    
    test_health()
    test_chat_smalltalk()
    test_chat_search()
    test_chat_conflicts()
    
    print("\n" + "="*70)
    print("✅ Enhanced formatting applied to all response types:")
    print("   • Structured sections with titles and content")
    print("   • Detailed information based on query type")
    print("   • Consistent emoji-based visual hierarchy")
    print("   • Summary alongside detailed findings")
    print("="*70 + "\n")
