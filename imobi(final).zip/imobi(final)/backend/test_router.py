import sys
sys.path.insert(0, '.')

from fastapi import FastAPI
app = FastAPI(title="Test")

try:
    from app.api import routes_architecture
    print(f"✓ routes_architecture imported")
    print(f"  Router: {routes_architecture.router}")
    app.include_router(routes_architecture.router)
    print(f"✓ Router included")
except Exception as e:
    print(f"✗ Error: {type(e).__name__}: {e}")
    import traceback
    traceback.print_exc()

# Check routes
print(f"\nAll routes after inclusion:")
for r in app.routes:
    if hasattr(r, 'path'):
        methods = getattr(r, 'methods', '?')
        print(f"  {r.path} - {methods}")
    else:
        print(f"  {type(r).__name__}")

arch_routes = [r for r in app.routes if hasattr(r, 'path') and 'architecture' in r.path]
print(f"\nArchitecture routes found: {len(arch_routes)}")

