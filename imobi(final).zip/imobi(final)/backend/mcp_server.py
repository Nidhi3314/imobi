"""
Entrypoint for CompliX's MCP server: `python mcp_server.py` from `backend/`
(with the same virtualenv/.env this backend already uses). Point an MCP
host's config (e.g. Claude Desktop's claude_desktop_config.json, or Claude
Code's `claude mcp add`) at this command over stdio. See app/mcp/server.py
for the exposed tools.
"""
from app.mcp.server import main

if __name__ == "__main__":
    main()
