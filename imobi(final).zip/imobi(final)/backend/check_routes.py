from app.main import app

found_architecture = False
for route in app.routes:
    if hasattr(route, 'path') and 'architecture' in route.path:
        methods = getattr(route, 'methods', '?')
        print(f'Found: {route.path} - Methods: {methods}')
        found_architecture = True

if not found_architecture:
    print('No /architecture routes found')
    print('\nAll routes:')
    for route in app.routes[:10]:
        if hasattr(route, 'path'):
            print(f'  {route.path}')
