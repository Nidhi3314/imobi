import requests
import time

# Give backend time to start
time.sleep(2)

# Test health first
print("=" * 70)
print("LLMaaS INTEGRATION TEST")
print("=" * 70)

try:
    resp = requests.get('http://127.0.0.1:8000/health', timeout=5)
    print(f'✓ Backend health: {resp.status_code}')
except Exception as e:
    print(f'✗ Backend not ready: {e}')
    exit(1)

# Test architecture generation with LLMaaS
print('\nTesting /architecture/generate with LLMaaS credentials...')
try:
    resp = requests.post(
        'http://127.0.0.1:8000/architecture/generate',
        json={'brief': 'Secure payment gateway with encryption', 'fmt': 'mermaid'},
        timeout=30
    )
    
    if resp.status_code == 200:
        data = resp.json()
        print(f'✓ Status: {resp.status_code}')
        print(f'✓ Response format: valid JSON')
        nodes_count = len(data.get("spec", {}).get("nodes", []))
        controls_count = len(data.get("spec", {}).get("controls", []))
        diagram_len = len(data.get("diagram", ""))
        generation_mode = data.get("spec", {}).get("generation_mode", "unknown")
        print(f'✓ Nodes: {nodes_count}')
        print(f'✓ Controls: {controls_count}')
        print(f'✓ Diagram length: {diagram_len} chars')

        # generation_mode is the authoritative signal, not node count --
        # the deterministic fallback also parses the brief for real
        # components now (see architecture_generator.py), so a high node
        # count alone no longer proves the LLM path ran.
        if generation_mode == "llm":
            print(f'\n✓ LLMaaS INTEGRATION IS WORKING -- this used live LLM reasoning.')
        else:
            print(f'\n⚠ Call succeeded but generation_mode="{generation_mode}": the deterministic')
            print(f'  brief-parsing fallback ran, not LLMaaS. Check backend logs for the actual')
            print(f'  LLM call error (token exchange failure, bad credentials, network, etc.)')
            print(f'  via GET /debug/llm-status or the uvicorn console output.')
    else:
        print(f'✗ Status: {resp.status_code}')
        print(f'  Response: {resp.text[:300]}')
except requests.exceptions.Timeout:
    print('⚠ Request timed out (LLMaaS endpoint may be slow or unreachable)')
    print('  Checking if deterministic fallback was used...')
    try:
        resp = requests.post(
            'http://127.0.0.1:8000/architecture/generate',
            json={'brief': 'Test', 'fmt': 'mermaid'},
            timeout=5
        )
        if resp.status_code == 200:
            print('  ✓ Fallback to deterministic template working')
    except:
        pass
except Exception as e:
    print(f'✗ Error: {type(e).__name__}: {e}')

print("\n" + "=" * 70)
