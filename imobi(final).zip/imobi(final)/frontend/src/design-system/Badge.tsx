import { CheckCircle2, XCircle, HelpCircle, AlertTriangle, Circle } from "lucide-react";
import "./Badge.scss";

const VERDICT_ICON: Record<string, typeof CheckCircle2> = {
  Compliant: CheckCircle2,
  "Non-compliant": XCircle,
  Gap: HelpCircle,
  Unverified: AlertTriangle,
  Incomplete: AlertTriangle,
};

export function VerdictBadge({ verdict }: { verdict: string }) {
  const cls = verdict.toLowerCase().replace(/[^a-z]/g, "-");
  const Icon = VERDICT_ICON[verdict] ?? Circle;
  return (
    <span className={`badge badge-verdict badge-${cls}`}>
      <Icon size={13} aria-hidden="true" /> {verdict}
    </span>
  );
}

export function SeverityBadge({ severity, title }: { severity: string; title?: string }) {
  const cls = severity.toLowerCase();
  return (
    <span className={`badge badge-severity badge-sev-${cls}`} title={title}>
      {severity}
    </span>
  );
}

export function Chip({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <span className="chip" onClick={onClick} role={onClick ? "button" : undefined}>
      {children}
    </span>
  );
}
