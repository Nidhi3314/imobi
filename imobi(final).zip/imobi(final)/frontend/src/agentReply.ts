/**
 * The chat Orchestrator's search intent falls back to a fixed template
 * (see backend/app/agents/chat_composer.py's _fallback_search_reply) when no
 * LLM is available: "I found N guardrails relevant to '<message>'...". That
 * reads fine for a short, natural typed question, but several features
 * (Conflict Desk's tradeoff summary, Guardrail Explorer's "explain this")
 * compose long, context-stuffed prompts programmatically -- echoed back
 * verbatim inside that template, it reads as a wall of garbled text instead
 * of an explanation. Detecting the fixed opening phrase lets those features
 * swap in an honest "live reasoning isn't available" message instead of
 * showing the raw echo.
 */
const FALLBACK_PREFIXES = ["I found ", "I couldn't find any guardrails relevant to"];

export function isDeterministicSearchFallback(reply: string): boolean {
  return FALLBACK_PREFIXES.some((p) => reply.startsWith(p));
}

export const LIVE_REASONING_UNAVAILABLE_MESSAGE =
  "Live AI reasoning isn't available right now (rate-limited, or no LLM configured), so I can't compose a tailored answer for this yet -- the structured details above already show everything I'd otherwise be citing. Try again shortly.";
