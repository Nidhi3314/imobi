import { useEffect, useRef, useState } from "react";
import { ExternalLink, Scale, Sparkles, CheckCircle2, Clock } from "lucide-react";
import { api, type ConflictTicket } from "../api/client";
import { isDeterministicSearchFallback, LIVE_REASONING_UNAVAILABLE_MESSAGE } from "../agentReply";
import "./ConflictDesk.scss";

const ADMIN_CONSOLE_URL = import.meta.env.VITE_ADMIN_CONSOLE_URL || "http://localhost:5174";

function useCountUp(value: number, durationMs = 700): number {
  const [display, setDisplay] = useState(value);
  const fromRef = useRef(value);
  useEffect(() => {
    const from = fromRef.current;
    const delta = value - from;
    if (delta === 0) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(from + delta * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return display;
}

function StatTile({ value, label }: { value: number; label: string }) {
  const shown = useCountUp(value);
  return (
    <div className="desk-stat">
      <span className="desk-stat-value">{shown}</span>
      <span className="desk-stat-label">{label}</span>
    </div>
  );
}

/** When both sides carry a normalized numeric value, a bar comparison makes
 * the magnitude of the disagreement immediately legible -- "90 vs 365 days"
 * reads faster as two bars than as two paragraphs of prose. */
function ValueBars({ a, b }: { a: number | null; b: number | null }) {
  if (a == null || b == null) return null;
  const max = Math.max(Math.abs(a), Math.abs(b), 1);
  return (
    <div className="ticket-value-bars">
      <div className="ticket-value-bar-row">
        <span className="ticket-value-bar-label">A</span>
        <span className="ticket-value-bar-track">
          <span className="ticket-value-bar-fill ticket-value-bar-fill-a" style={{ width: `${(Math.abs(a) / max) * 100}%` }} />
        </span>
        <span className="ticket-value-bar-number">{a}</span>
      </div>
      <div className="ticket-value-bar-row">
        <span className="ticket-value-bar-label">B</span>
        <span className="ticket-value-bar-track">
          <span className="ticket-value-bar-fill ticket-value-bar-fill-b" style={{ width: `${(Math.abs(b) / max) * 100}%` }} />
        </span>
        <span className="ticket-value-bar-number">{b}</span>
      </div>
    </div>
  );
}

// The chat Orchestrator regex-routes on "conflict(s)"/"disagree" anywhere in
// the message to its generic "N open tickets" summary intent (see
// orchestrator.py's _CONFLICT_RE) -- fine for a short typed query like "show
// conflicts", but it also fires on those words showing up incidentally deep
// inside a long context-rich prompt, hijacking what should route to a
// specific-answer intent instead. The ticket's own `rationale` text
// legitimately uses "conflict" ("a structurally similar conflict was already
// resolved..."), so it has to be neutralized before being interpolated in,
// not just avoided in the hand-written parts of the prompt.
function neutralizeConflictRouting(text: string): string {
  return text.replace(/\bconflicts?\b/gi, "mismatch").replace(/\bconflicting\b/gi, "mismatched").replace(/\bdisagree\b/gi, "differ");
}

function AskAgent({ ticket }: { ticket: ConflictTicket }) {
  const [state, setState] = useState<{ text: string; loading: boolean } | null>(null);

  async function ask() {
    if (state?.loading) return;
    setState({ text: state?.text ?? "", loading: true });
    try {
      const res = await api.chat(
        `Two governance rules state different values for the same requirement (metric: ${ticket.metric}). ` +
          `Rule A (${ticket.guardrail_a?.id}): "${ticket.guardrail_a?.statement}". ` +
          `Rule B (${ticket.guardrail_b?.id}): "${ticket.guardrail_b?.statement}". ` +
          `System's rationale for flagging this mismatch: ${neutralizeConflictRouting(ticket.rationale)}. ` +
          `Summarize the tradeoff in plain language and note anything a human reviewer should weigh before choosing between them.`,
      );
      setState({
        text: isDeterministicSearchFallback(res.reply) ? LIVE_REASONING_UNAVAILABLE_MESSAGE : res.reply,
        loading: false,
      });
    } catch (e) {
      setState({ text: `Couldn't reach the agent: ${(e as Error).message}`, loading: false });
    }
  }

  if (!state) {
    return (
      <button type="button" className="ticket-ask-btn" onClick={ask}>
        <Sparkles size={12} /> Ask the agent to summarize the tradeoff
      </button>
    );
  }

  return (
    <div className="ticket-ask-answer">
      <Sparkles size={12} />
      {state.loading ? (
        <span className="desk-loading">
          <span className="desk-loading-dot" /> Weighing both sides…
        </span>
      ) : (
        <p>{state.text}</p>
      )}
    </div>
  );
}

export function ConflictDesk() {
  const [tickets, setTickets] = useState<ConflictTicket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .listConflicts()
      .then(setTickets)
      .finally(() => setLoading(false));
  }, []);

  const open = tickets.filter((t) => t.status === "open");
  const decided = tickets.filter((t) => t.status !== "open");
  const designsAffected = new Set(
    tickets.flatMap((t) => t.impact_analysis?.designs_that_flip.map((d) => d.design_id) ?? []),
  ).size;

  return (
    <div className="conflict-desk">
      <div className="desk-grid-bg" aria-hidden="true" />

      <h1>Conflict Desk</h1>
      <p className="desk-sub">
        CompliX <strong>never</strong> silently picks a side when two sources disagree. Each ticket below shows
        both sources, why the Conflict Agent thinks they disagree, and which designs would flip verdict under each
        resolution.
      </p>

      <div className="desk-stats">
        <StatTile value={open.length} label="Open tickets" />
        <StatTile value={decided.length} label="Decided" />
        <StatTile value={designsAffected} label="Designs affected" />
      </div>

      <div className="desk-admin-banner">
        <span>
          Approving, rejecting, or keeping a ticket open requires a signed-in admin reviewer — that happens in the
          dedicated Admin Console, not here.
        </span>
        <a className="btn-primary desk-admin-link" href={ADMIN_CONSOLE_URL} target="_blank" rel="noreferrer">
          Open Admin Console <ExternalLink size={14} />
        </a>
      </div>

      {loading && (
        <p className="desk-loading">
          <span className="desk-loading-dot" /> Loading…
        </p>
      )}

      {!loading && open.length === 0 && <p className="desk-empty">No open conflicts right now.</p>}

      {open.map((t) => (
        <div key={t.id} className="conflict-ticket">
          <div className="ticket-header">
            <span className="ticket-id">{t.id}</span>
            <span className="ticket-metric">{t.metric}</span>
            <span className="ticket-status ticket-status-open">
              <Clock size={12} /> Awaiting human decision
            </span>
          </div>

          <div className="ticket-sides">
            <div className="ticket-side ticket-side-a">
              <div className="ticket-side-label">Side A</div>
              <div className="ticket-side-id">{t.guardrail_a?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_a?.statement}</div>
            </div>
            <div className="ticket-vs">
              <Scale size={14} />
              <span>VS</span>
            </div>
            <div className="ticket-side ticket-side-b">
              <div className="ticket-side-label">Side B</div>
              <div className="ticket-side-id">{t.guardrail_b?.id}</div>
              <div className="ticket-side-statement">{t.guardrail_b?.statement}</div>
            </div>
          </div>

          <ValueBars a={t.guardrail_a?.value ?? null} b={t.guardrail_b?.value ?? null} />

          <p className="ticket-rationale">
            <strong>Why the Conflict Agent flagged this:</strong> {t.rationale}
          </p>
          <p className="ticket-recommendation">
            <strong>Recommendation:</strong> {t.recommended_resolution}
          </p>

          {t.impact_analysis && (
            <div className="ticket-impact">
              <strong>Impact analysis</strong> <span className="impact-note">({t.impact_analysis.note})</span>
              {t.impact_analysis.designs_that_flip.length === 0 ? (
                <p className="impact-empty">No existing designs would flip verdict under either resolution.</p>
              ) : (
                <ul>
                  {t.impact_analysis.designs_that_flip.map((d) => (
                    <li key={d.design_id}>
                      <strong>{d.design_id}</strong> ({d.design_title}): observed value {d.observed_value} —{" "}
                      {d.verdict_under_a} under A, {d.verdict_under_b} under B
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <AskAgent ticket={t} />
        </div>
      ))}

      {decided.length > 0 && (
        <>
          <h2 className="desk-decided-heading">Decided</h2>
          {decided.map((t) => (
            <div key={t.id} className="conflict-ticket conflict-ticket-decided">
              <div className="ticket-header">
                <span className="ticket-id">{t.id}</span>
                <span className="ticket-metric">{t.metric}</span>
                <span className="ticket-status ticket-status-decided">
                  <CheckCircle2 size={12} /> {t.status.replace("_", " ")}
                </span>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
