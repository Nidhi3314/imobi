import { useEffect, useRef, useState } from "react";
import {
  UploadCloud,
  FileSpreadsheet,
  Sparkles,
  ShieldCheck,
  ShieldX,
  Gavel,
  Copy,
  AlertTriangle,
} from "lucide-react";
import { api, type EvaluationReport, type IngestResult } from "../api/client";
import { VerdictBadge } from "../design-system/Badge";
import "./JudgeMode.scss";

const PIPELINE_STAGES = ["Extraction Agent", "Dedup Agent", "Orphan Agent", "Conflict Agent"];

function useCountUp(value: number, durationMs = 900): number {
  const [display, setDisplay] = useState(0);
  const fromRef = useRef(0);
  useEffect(() => {
    const from = fromRef.current;
    const delta = value - from;
    if (delta === 0) {
      setDisplay(value);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(from + delta * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return display;
}

function ResultTile({ value, label, tone }: { value: number; label: string; tone?: "amber" | "alert" }) {
  const shown = useCountUp(value);
  return (
    <div className={`judge-tile ${tone ? `judge-tile-${tone}` : ""}`}>
      <span className="judge-tile-value">{shown}</span>
      <span className="judge-tile-label">{label}</span>
    </div>
  );
}

function StepBadge({ n }: { n: number }) {
  return <span className="judge-step-badge">{n}</span>;
}

export function JudgeMode() {
  const [uploadResult, setUploadResult] = useState<IngestResult | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [stagePhrase, setStagePhrase] = useState(PIPELINE_STAGES[0]);

  const [domain, setDomain] = useState("Information Security");
  const [description, setDescription] = useState(
    "A new microservice stores customer support tickets, including free-text notes that sometimes contain customer emails, in a public cloud bucket with default settings.",
  );
  const [adhocReport, setAdhocReport] = useState<EvaluationReport | null>(null);
  const [evaluating, setEvaluating] = useState(false);

  const [gGuardrail, setGGuardrail] = useState("GR-does-not-exist");
  const [gClause, setGClause] = useState("CL-9999");
  const [gateResult, setGateResult] = useState<{ passed: boolean; reason: string } | null>(null);
  const [gateChecking, setGateChecking] = useState(false);

  useEffect(() => {
    if (!uploading) return;
    let i = 0;
    setStagePhrase(PIPELINE_STAGES[0]);
    const id = setInterval(() => {
      i = (i + 1) % PIPELINE_STAGES.length;
      setStagePhrase(PIPELINE_STAGES[i]);
    }, 900);
    return () => clearInterval(id);
  }, [uploading]);

  async function handleUpload(file: File) {
    if (!file.name.endsWith(".xlsx")) {
      setUploadError("Please upload an .xlsx workbook matching the GuardrailIQ sheet shapes.");
      return;
    }
    setUploading(true);
    setUploadError(null);
    setUploadResult(null);
    try {
      const result = await api.ingestUpload(file);
      setUploadResult(result);
    } catch (e) {
      setUploadError((e as Error).message);
    } finally {
      setUploading(false);
    }
  }

  async function runAdhoc() {
    setEvaluating(true);
    setAdhocReport(null);
    try {
      const report = await api.evaluateText({ domain, description });
      setAdhocReport(report);
    } finally {
      setEvaluating(false);
    }
  }

  async function checkGate() {
    setGateChecking(true);
    try {
      setGateResult(await api.citationGateCheck(gGuardrail, gClause));
    } finally {
      setGateChecking(false);
    }
  }

  function tryFakeId() {
    setGGuardrail(`GR-${Math.random().toString(36).slice(2, 10)}`);
    setGClause(`CL-${Math.floor(Math.random() * 9000 + 1000)}`);
    setGateResult(null);
  }

  return (
    <div className="judge-mode">
      <div className="judge-grid-bg" aria-hidden="true" />

      <h1>Judge Mode</h1>
      <p className="judge-sub">
        Three ways to stress-test the "not hardcoded to the sample IDs" claim, live — no need to take our word for it.
      </p>

      <section className="judge-section">
        <h2>
          <StepBadge n={1} /> Upload your own workbook
        </h2>
        <p>
          Upload any .xlsx with the same sheet shapes (<code>Governance_Documents</code>, <code>Clauses</code>,{" "}
          <code>Design_Descriptions</code>) — including a modified copy with different IDs, new documents, or new
          duplicates/conflicts — and watch the identical pipeline run against it, live.
        </p>

        <label
          className={`judge-dropzone ${dragOver ? "drag-over" : ""} ${uploading ? "busy" : ""}`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) handleUpload(f);
          }}
        >
          <input
            type="file"
            accept=".xlsx"
            hidden
            disabled={uploading}
            onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
          />
          {uploading ? (
            <span className="judge-dropzone-status">
              <span className="judge-loading-dot" /> Running {stagePhrase}…
            </span>
          ) : (
            <span className="judge-dropzone-status">
              <UploadCloud size={20} /> Drop an .xlsx here, or click to browse
            </span>
          )}
        </label>

        {uploadError && (
          <p className="judge-error">
            <AlertTriangle size={13} /> {uploadError}
          </p>
        )}

        {uploadResult && (
          <div className="judge-upload-result">
            <div className="judge-pipeline-trace">
              {PIPELINE_STAGES.map((s) => (
                <span key={s} className="judge-pipeline-stage">
                  <ShieldCheck size={12} /> {s}
                </span>
              ))}
            </div>
            <div className="judge-tiles">
              <ResultTile value={uploadResult.ingested.documents} label="Documents" />
              <ResultTile value={uploadResult.ingested.clauses} label="Clauses" />
              <ResultTile value={uploadResult.guardrails_created} label="Guardrails" />
              <ResultTile value={uploadResult.duplicates_merged} label="Duplicates merged" tone={uploadResult.duplicates_merged > 0 ? "amber" : undefined} />
              <ResultTile value={uploadResult.broken_references} label="Broken refs" tone={uploadResult.broken_references > 0 ? "alert" : undefined} />
              <ResultTile value={uploadResult.conflict_tickets_opened} label="Conflicts opened" tone={uploadResult.conflict_tickets_opened > 0 ? "amber" : undefined} />
            </div>
            <p className="judge-upload-source">
              <FileSpreadsheet size={12} /> Ingested from <code>{uploadResult.source}</code> — this replaced the
              previous dataset entirely (decided Conflict Desk tickets persisted as precedent).
            </p>
          </div>
        )}
      </section>

      <section className="judge-section">
        <h2>
          <StepBadge n={2} /> Evaluate a design we've never seen
        </h2>
        <p>Type (or paste) any design description — not one of the sample designs — and get a fully cited report.</p>
        <input className="judge-input" value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="Domain" />
        <textarea
          className="judge-textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
        />
        <button className="btn-primary" onClick={runAdhoc} disabled={evaluating || !description.trim()}>
          {evaluating ? (
            <>
              <span className="judge-loading-dot" /> Evaluating…
            </>
          ) : (
            <>
              <Sparkles size={14} /> Evaluate
            </>
          )}
        </button>

        {adhocReport && (
          <div className="judge-adhoc-results">
            <div className="judge-adhoc-banner">
              <VerdictBadge verdict={adhocReport.overall_verdict.status} />
              <span>{adhocReport.overall_verdict.summary}</span>
            </div>
            {adhocReport.findings.slice(0, 8).map((f, i) => (
              <div key={i} className="judge-finding">
                <VerdictBadge verdict={f.verdict} />
                <div>
                  <strong>{f.guardrail_id}</strong> — {f.plain_language}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="judge-section">
        <h2>
          <StepBadge n={3} /> Try to fool the citation gate
        </h2>
        <p>
          Type any guardrail ID and clause ID — including ones you make up — and see whether the deterministic gate
          lets it through. It never does unless both are real and actually linked.
        </p>
        <div className="judge-gate-row">
          <input className="judge-input" value={gGuardrail} onChange={(e) => setGGuardrail(e.target.value)} placeholder="Guardrail ID" />
          <input className="judge-input" value={gClause} onChange={(e) => setGClause(e.target.value)} placeholder="Clause ID" />
          <button className="btn-ghost judge-fake-btn" type="button" onClick={tryFakeId} title="Fill in a random fake ID pair">
            <Copy size={13} /> Random fake
          </button>
          <button className="btn-primary" onClick={checkGate} disabled={gateChecking}>
            {gateChecking ? "Checking…" : "Check"}
          </button>
        </div>
        {gateResult && (
          <div className={`judge-gate-result ${gateResult.passed ? "gate-pass" : "gate-fail"}`}>
            {gateResult.passed ? <ShieldCheck size={22} /> : <ShieldX size={22} />}
            <div>
              <strong>{gateResult.passed ? "Passed" : "Rejected"}</strong>
              <p>{gateResult.reason}</p>
            </div>
          </div>
        )}
      </section>

      <p className="judge-footnote">
        <Gavel size={12} /> Every check above hits the same live pipeline the rest of the app uses — nothing here is
        a canned demo path.
      </p>
    </div>
  );
}
