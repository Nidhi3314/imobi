import type { ArchitectureCitation } from "../../api/client";

export type ShapeKind = "rect" | "hexagon" | "cylinder" | "parallelogram" | "stadium";

// Mirrors the backend's _MERMAID_SHAPE table (app/generate/architecture_generator.py)
// so the interactive canvas and the exported Mermaid/DOT text always agree on
// which component type gets which shape.
const SHAPE_BY_TYPE: Record<string, ShapeKind> = {
  gateway: "hexagon",
  auth: "hexagon",
  database: "cylinder",
  cache: "cylinder",
  storage: "parallelogram",
  queue: "parallelogram",
  client: "stadium",
  external: "stadium",
};

export function shapeForType(type: string): ShapeKind {
  return SHAPE_BY_TYPE[type] ?? "rect";
}

// Keys must be `width`/`height` -- dagre reads these exact property names
// off the value object passed to setNode() for its own layout math, not
// just to echo back.
export const SHAPE_SIZE: Record<ShapeKind, { width: number; height: number }> = {
  rect: { width: 168, height: 58 },
  hexagon: { width: 180, height: 66 },
  cylinder: { width: 148, height: 74 },
  parallelogram: { width: 180, height: 60 },
  stadium: { width: 156, height: 56 },
};

export const PALETTE_ITEMS: { shape: ShapeKind; componentType: string; label: string }[] = [
  { shape: "rect", componentType: "service", label: "Service" },
  { shape: "hexagon", componentType: "gateway", label: "Gateway / Auth" },
  { shape: "cylinder", componentType: "database", label: "Database" },
  { shape: "parallelogram", componentType: "storage", label: "Storage / Queue" },
  { shape: "stadium", componentType: "external", label: "External actor" },
];

export interface ComponentNodeData extends Record<string, unknown> {
  kind: "component";
  label: string;
  shape: ShapeKind;
  componentType: string;
  description?: string;
  satisfies?: ArchitectureCitation[];
}

export interface BoundaryNodeData extends Record<string, unknown> {
  kind: "boundary";
  label: string;
  description?: string;
}

export type ArchNodeData = ComponentNodeData | BoundaryNodeData;
