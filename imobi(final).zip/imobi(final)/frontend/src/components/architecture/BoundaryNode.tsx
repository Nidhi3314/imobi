import { useState } from "react";
import { NodeResizer, useReactFlow, type NodeProps, type Node } from "@xyflow/react";
import type { BoundaryNodeData } from "./types";

export function BoundaryNode({ id, data, selected }: NodeProps<Node<BoundaryNodeData>>) {
  const { updateNodeData } = useReactFlow();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(data.label);

  function commit() {
    setEditing(false);
    const trimmed = draft.trim();
    if (trimmed && trimmed !== data.label) updateNodeData(id, { label: trimmed });
    else setDraft(data.label);
  }

  return (
    <div className="arch-boundary">
      <NodeResizer isVisible={selected} minWidth={200} minHeight={120} lineClassName="arch-node-resize-line" handleClassName="arch-node-resize-handle" />
      <div className="arch-boundary-label">
        {editing ? (
          <input
            className="arch-node-label-input"
            value={draft}
            autoFocus
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") commit();
              if (e.key === "Escape") {
                setDraft(data.label);
                setEditing(false);
              }
            }}
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span onDoubleClick={() => setEditing(true)} title="Double-click to rename">
            {data.label}
          </span>
        )}
      </div>
    </div>
  );
}
