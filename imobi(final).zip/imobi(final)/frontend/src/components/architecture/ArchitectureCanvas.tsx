import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  ConnectionMode,
  useNodesState,
  useEdgesState,
  addEdge,
  useReactFlow,
  type Node,
  type Edge,
  type Connection,
  type OnConnect,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { toPng } from "html-to-image";
import { Download, Copy as CopyIcon, Redo2, Undo2, LayoutGrid, RotateCcw, Maximize2, Minimize2 } from "lucide-react";
import { ShapeNode } from "./ShapeNode";
import { BoundaryNode } from "./BoundaryNode";
import { ShapePalette, PALETTE_DRAG_TYPE, PALETTE_BOUNDARY_DRAG_TYPE } from "./ShapePalette";
import { PropertiesPanel } from "./PropertiesPanel";
import { layoutSpec, relayoutGraph } from "./layout";
import type { ComponentNodeData } from "./types";
import type { ArchitectureGenerateResult, Citation } from "../../api/client";
import "./ArchitectureCanvas.scss";

const nodeTypes = { component: ShapeNode, boundary: BoundaryNode };

interface Props {
  result: ArchitectureGenerateResult | null;
  loading: boolean;
  thinkingPhrase: string;
  onOpenCitation: (citation: Citation) => void;
  onStartOver: () => void;
  canStartOver: boolean;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
}

let manualNodeCounter = 0;

interface Snapshot {
  nodes: Node[];
  edges: Edge[];
}

function CanvasInner({ result, loading, thinkingPhrase, onOpenCitation, onStartOver, canStartOver, isFullscreen, onToggleFullscreen }: Props) {
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const { screenToFlowPosition, fitView, zoomIn, zoomOut } = useReactFlow();
  const lastSignatureRef = useRef<string | null>(null);

  const past = useRef<Snapshot[]>([]);
  const future = useRef<Snapshot[]>([]);
  // The setter alone is enough to force a re-render when undo/redo's
  // enabled state (read straight from the refs below) needs to update --
  // the counter value itself is never read.
  const [, setHistoryTick] = useState(0);
  const suppressHistoryRef = useRef(false);

  const pushHistory = useCallback(() => {
    if (suppressHistoryRef.current) return;
    past.current.push({ nodes, edges });
    if (past.current.length > 40) past.current.shift();
    future.current = [];
    setHistoryTick((t) => t + 1);
  }, [nodes, edges]);

  function undo() {
    const prev = past.current.pop();
    if (!prev) return;
    future.current.push({ nodes, edges });
    suppressHistoryRef.current = true;
    setNodes(prev.nodes);
    setEdges(prev.edges);
    suppressHistoryRef.current = false;
    setHistoryTick((t) => t + 1);
  }

  function redo() {
    const next = future.current.pop();
    if (!next) return;
    past.current.push({ nodes, edges });
    suppressHistoryRef.current = true;
    setNodes(next.nodes);
    setEdges(next.edges);
    suppressHistoryRef.current = false;
    setHistoryTick((t) => t + 1);
  }

  // Reset the canvas from a freshly generated/regenerated spec. Keyed on a
  // content signature rather than object identity so a genuine regeneration
  // (new title/node-count/description) always redraws, but this effect
  // doesn't fight manual canvas edits in between chat turns.
  const specSignature = useMemo(
    () => (result ? `${result.spec.title}|${result.spec.nodes.length}|${result.spec.edges.length}|${result.spec.description}` : null),
    [result],
  );

  useEffect(() => {
    if (specSignature === lastSignatureRef.current) return;
    lastSignatureRef.current = specSignature;
    past.current = [];
    future.current = [];
    if (!result) {
      setNodes([]);
      setEdges([]);
      return;
    }
    const { nodes: n, edges: e } = layoutSpec(result.spec);
    setNodes(n);
    setEdges(e);
    setSelectedNodeId(null);
    setSelectedEdgeId(null);
    requestAnimationFrame(() => fitView({ padding: 0.2, duration: 300 }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [specSignature]);

  const onConnect: OnConnect = useCallback(
    (connection: Connection) => {
      pushHistory();
      setEdges((eds) => addEdge({ ...connection, type: "smoothstep", label: "connection" }, eds));
    },
    [pushHistory, setEdges],
  );

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const position = screenToFlowPosition({ x: e.clientX, y: e.clientY });

      const boundaryFlag = e.dataTransfer.getData(PALETTE_BOUNDARY_DRAG_TYPE);
      if (boundaryFlag) {
        pushHistory();
        const id = `boundary-${Date.now()}-${manualNodeCounter++}`;
        setNodes((nds) =>
          nds.concat({
            id,
            type: "boundary",
            position,
            style: { width: 320, height: 220 },
            data: { kind: "boundary", label: "New trust boundary" },
            zIndex: -1,
          }),
        );
        return;
      }

      const raw = e.dataTransfer.getData(PALETTE_DRAG_TYPE);
      if (!raw) return;
      const payload = JSON.parse(raw) as { shape: ComponentNodeData["shape"]; componentType: string; label: string };
      pushHistory();
      const id = `manual-${Date.now()}-${manualNodeCounter++}`;
      setNodes((nds) =>
        nds.concat({
          id,
          type: "component",
          position,
          data: { kind: "component", label: payload.label, shape: payload.shape, componentType: payload.componentType },
        }),
      );
    },
    [screenToFlowPosition, pushHistory, setNodes],
  );

  function renameNode(id: string, label: string) {
    setNodes((nds) => nds.map((n) => (n.id === id ? { ...n, data: { ...n.data, label } } : n)));
  }

  function renameEdge(id: string, label: string) {
    setEdges((eds) => eds.map((e) => (e.id === id ? { ...e, label } : e)));
  }

  function deleteNode(id: string) {
    pushHistory();
    setNodes((nds) => nds.filter((n) => n.id !== id && n.parentId !== id));
    setEdges((eds) => eds.filter((e) => e.source !== id && e.target !== id));
    setSelectedNodeId(null);
  }

  function deleteEdge(id: string) {
    pushHistory();
    setEdges((eds) => eds.filter((e) => e.id !== id));
    setSelectedEdgeId(null);
  }

  function autoArrange() {
    pushHistory();
    setNodes((nds) => relayoutGraph(nds, edges));
    requestAnimationFrame(() => fitView({ padding: 0.2, duration: 300 }));
  }

  async function exportPng() {
    const viewport = wrapperRef.current?.querySelector(".react-flow__viewport") as HTMLElement | null;
    if (!viewport) return;
    const dataUrl = await toPng(viewport, { backgroundColor: "#ffffff", pixelRatio: 2 });
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = `${result?.spec.title || "architecture"}.png`;
    a.click();
  }

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) ?? null;
  const selectedEdge = edges.find((e) => e.id === selectedEdgeId) ?? null;

  return (
    <div className="arch-rf-board">
      <div className="arch-canvas-toolbar">
        <span className="arch-canvas-title">{result?.spec.title ?? "Untitled Diagram"}</span>
        <div className="arch-canvas-toolbar-actions">
          <button type="button" onClick={undo} disabled={past.current.length === 0} title="Undo">
            <Undo2 size={13} />
          </button>
          <button type="button" onClick={redo} disabled={future.current.length === 0} title="Redo">
            <Redo2 size={13} />
          </button>
          <span className="arch-canvas-toolbar-sep" />
          <button type="button" onClick={() => zoomOut({ duration: 150 })} title="Zoom out">
            <span className="arch-zoom-symbol">−</span>
          </button>
          <button type="button" onClick={() => zoomIn({ duration: 150 })} title="Zoom in">
            <span className="arch-zoom-symbol">+</span>
          </button>
          <button type="button" onClick={() => fitView({ padding: 0.2, duration: 200 })} title="Fit to view">
            <LayoutGrid size={13} />
          </button>
          <button type="button" onClick={autoArrange} disabled={nodes.length === 0} title="Auto-arrange (re-run layout)">
            <LayoutGrid size={13} /> Arrange
          </button>
          {result && (
            <>
              <span className="arch-canvas-toolbar-sep" />
              <button type="button" onClick={exportPng}>
                <Download size={13} /> PNG
              </button>
              <button type="button" onClick={() => navigator.clipboard.writeText(result.diagram_mermaid)}>
                <CopyIcon size={13} /> Mermaid
              </button>
              <button
                type="button"
                onClick={() => navigator.clipboard.writeText(result.diagram_dot)}
                title="Graphviz DOT -- importable into draw.io via Extras -> Edit Diagram -> Advanced"
              >
                <CopyIcon size={13} /> DOT
              </button>
            </>
          )}
          <span className="arch-canvas-toolbar-sep" />
          <button type="button" onClick={onToggleFullscreen} title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}>
            {isFullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          </button>
          <button type="button" onClick={onStartOver} title="Start a new diagram" disabled={!canStartOver}>
            <RotateCcw size={13} /> New
          </button>
        </div>
      </div>

      <div className="arch-rf-body">
        <ShapePalette />
        <div className="arch-rf-canvas-wrap" ref={wrapperRef} onDragOver={onDragOver} onDrop={onDrop}>
            <ReactFlow
              nodes={nodes}
              edges={edges}
              nodeTypes={nodeTypes}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              connectionMode={ConnectionMode.Loose}
              onNodeDragStop={pushHistory}
              onNodeClick={(_, n) => {
                setSelectedNodeId(n.id);
                setSelectedEdgeId(null);
              }}
              onEdgeClick={(_, e) => {
                setSelectedEdgeId(e.id);
                setSelectedNodeId(null);
              }}
              onPaneClick={() => {
                setSelectedNodeId(null);
                setSelectedEdgeId(null);
              }}
              onNodesDelete={() => pushHistory()}
              onEdgesDelete={() => pushHistory()}
              deleteKeyCode={["Backspace", "Delete"]}
              fitView
              minZoom={0.2}
              maxZoom={2}
              proOptions={{ hideAttribution: true }}
            >
              <Background variant={BackgroundVariant.Dots} gap={18} size={1} color="var(--color-border)" />
              <Controls showInteractive={false} position="bottom-left" />
              <MiniMap
                pannable
                zoomable
                className="arch-rf-minimap"
                nodeColor="var(--color-gray-300)"
                maskColor="rgba(0,0,0,0.06)"
                style={{ width: 130, height: 90 }}
              />
            </ReactFlow>
          {!result && nodes.length === 0 && (
            <div className="arch-canvas-blank">
              {loading && (
                <span className="arch-canvas-loading">
                  <span className="arch-gen-loading-dot" /> {thinkingPhrase}
                </span>
              )}
            </div>
          )}
          {loading && result && (
            <div className="arch-canvas-updating">
              <span className="arch-gen-loading-dot" /> {thinkingPhrase}
            </div>
          )}
        </div>
        <PropertiesPanel
          selectedNode={selectedNode}
          selectedEdge={selectedEdge}
          onRenameNode={renameNode}
          onRenameEdge={renameEdge}
          onDeleteNode={deleteNode}
          onDeleteEdge={deleteEdge}
          onOpenCitation={onOpenCitation}
        />
      </div>
    </div>
  );
}

export function ArchitectureCanvas(props: Props) {
  return (
    <ReactFlowProvider>
      <CanvasInner {...props} />
    </ReactFlowProvider>
  );
}
