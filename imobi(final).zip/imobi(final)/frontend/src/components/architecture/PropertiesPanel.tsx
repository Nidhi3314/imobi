import { Lock, ShieldAlert, Trash2 } from "lucide-react";
import type { Edge, Node } from "@xyflow/react";
import { Citations } from "../Citations";
import type { Citation } from "../../api/client";
import type { ComponentNodeData, BoundaryNodeData } from "./types";

interface Props {
  selectedNode: Node | null;
  selectedEdge: Edge | null;
  onRenameNode: (id: string, label: string) => void;
  onRenameEdge: (id: string, label: string) => void;
  onDeleteNode: (id: string) => void;
  onDeleteEdge: (id: string) => void;
  onOpenCitation: (citation: Citation) => void;
}

export function PropertiesPanel({ selectedNode, selectedEdge, onRenameNode, onRenameEdge, onDeleteNode, onDeleteEdge, onOpenCitation }: Props) {
  if (!selectedNode && !selectedEdge) {
    return (
      <aside className="arch-properties arch-properties-empty">
        <p>Select a node or connection to edit its details.</p>
      </aside>
    );
  }

  if (selectedNode) {
    const data = selectedNode.data as ComponentNodeData | BoundaryNodeData;
    const citations: Citation[] =
      data.kind === "component"
        ? (data.satisfies ?? []).map((c) => ({ guardrail_id: c.guardrail_id, clause_id: c.clause_ref }))
        : [];
    return (
      <aside className="arch-properties">
        <div className="arch-properties-heading">{data.kind === "boundary" ? "Trust boundary" : "Component"}</div>
        <label className="arch-properties-field">
          <span>Label</span>
          <input value={data.label} onChange={(e) => onRenameNode(selectedNode.id, e.target.value)} />
        </label>
        {data.kind === "component" && (
          <label className="arch-properties-field">
            <span>Type</span>
            <input value={data.componentType} disabled />
          </label>
        )}
        {data.description && <p className="arch-properties-desc">{data.description}</p>}
        {citations.length > 0 && (
          <div className="arch-properties-citations">
            <Citations citations={citations} onOpen={onOpenCitation} />
          </div>
        )}
        <button type="button" className="arch-properties-delete" onClick={() => onDeleteNode(selectedNode.id)}>
          <Trash2 size={13} /> Delete
        </button>
      </aside>
    );
  }

  const edge = selectedEdge!;
  const edgeData = (edge.data ?? {}) as { description?: string; satisfies?: { guardrail_id: string; clause_ref: string }[]; encrypted?: boolean };
  const citations: Citation[] = (edgeData.satisfies ?? []).map((c) => ({ guardrail_id: c.guardrail_id, clause_id: c.clause_ref }));
  return (
    <aside className="arch-properties">
      <div className="arch-properties-heading">Connection</div>
      <label className="arch-properties-field">
        <span>Label</span>
        <input value={typeof edge.label === "string" ? edge.label : ""} onChange={(e) => onRenameEdge(edge.id, e.target.value)} />
      </label>
      {edgeData.encrypted !== undefined && (
        <p className={`arch-properties-encryption ${edgeData.encrypted ? "encrypted" : "unencrypted"}`}>
          {edgeData.encrypted ? <Lock size={12} /> : <ShieldAlert size={12} />}
          {edgeData.encrypted ? "Encrypted hop" : "Unencrypted hop"}
        </p>
      )}
      {edgeData.description && <p className="arch-properties-desc">{edgeData.description}</p>}
      {citations.length > 0 && (
        <div className="arch-properties-citations">
          <Citations citations={citations} onOpen={onOpenCitation} />
        </div>
      )}
      <button type="button" className="arch-properties-delete" onClick={() => onDeleteEdge(edge.id)}>
        <Trash2 size={13} /> Delete
      </button>
    </aside>
  );
}
