import { useState } from "react";
import { Handle, Position, NodeResizer, useReactFlow, type NodeProps, type Node } from "@xyflow/react";
import type { ComponentNodeData } from "./types";

const SIDES = [Position.Top, Position.Right, Position.Bottom, Position.Left];

export function ShapeNode({ id, data, selected }: NodeProps<Node<ComponentNodeData>>) {
  const { updateNodeData } = useReactFlow();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(data.label);

  function commit() {
    setEditing(false);
    const trimmed = draft.trim();
    if (trimmed && trimmed !== data.label) updateNodeData(id, { label: trimmed });
    else setDraft(data.label);
  }

  return (
    <div className={`arch-node arch-node-${data.shape}`}>
      <NodeResizer isVisible={selected} minWidth={120} minHeight={48} lineClassName="arch-node-resize-line" handleClassName="arch-node-resize-handle" />
      {SIDES.map((pos) => (
        <Handle key={pos} type="source" position={pos} id={pos} className="arch-node-handle" />
      ))}
      <div className="arch-node-shape">
        <div className="arch-node-body">
          {editing ? (
            <input
              className="arch-node-label-input"
              value={draft}
              autoFocus
              onChange={(e) => setDraft(e.target.value)}
              onBlur={commit}
              onKeyDown={(e) => {
                if (e.key === "Enter") commit();
                if (e.key === "Escape") {
                  setDraft(data.label);
                  setEditing(false);
                }
              }}
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span className="arch-node-label" onDoubleClick={() => setEditing(true)} title="Double-click to rename">
              {data.label}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
