import { Shapes } from "lucide-react";
import { PALETTE_ITEMS, type ShapeKind } from "./types";

export const PALETTE_DRAG_TYPE = "application/complix-arch-node";
export const PALETTE_BOUNDARY_DRAG_TYPE = "application/complix-arch-boundary";

function MiniShape({ shape }: { shape: ShapeKind }) {
  return <span className={`arch-palette-mini arch-palette-mini-${shape}`} />;
}

export function ShapePalette() {
  return (
    <aside className="arch-palette">
      <div className="arch-palette-heading">
        <Shapes size={13} /> Shapes
      </div>
      <p className="arch-palette-hint">Drag onto the canvas.</p>
      <div className="arch-palette-items">
        {PALETTE_ITEMS.map((item) => (
          <div
            key={item.componentType}
            className="arch-palette-item"
            draggable
            onDragStart={(e) => {
              e.dataTransfer.setData(PALETTE_DRAG_TYPE, JSON.stringify(item));
              e.dataTransfer.effectAllowed = "move";
            }}
          >
            <MiniShape shape={item.shape} />
            <span>{item.label}</span>
          </div>
        ))}
        <div
          className="arch-palette-item arch-palette-item-boundary"
          draggable
          onDragStart={(e) => {
            e.dataTransfer.setData(PALETTE_BOUNDARY_DRAG_TYPE, "1");
            e.dataTransfer.effectAllowed = "move";
          }}
        >
          <span className="arch-palette-mini arch-palette-mini-boundary" />
          <span>Trust boundary</span>
        </div>
      </div>
    </aside>
  );
}
