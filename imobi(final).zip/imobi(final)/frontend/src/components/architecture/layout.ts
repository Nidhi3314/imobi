import dagre from "@dagrejs/dagre";
import type { Node, Edge } from "@xyflow/react";
import type { ArchitectureSpec } from "../../api/client";
import { SHAPE_SIZE, shapeForType, type ComponentNodeData, type BoundaryNodeData, type ShapeKind } from "./types";

const BOUNDARY_PAD_X = 44;
const BOUNDARY_PAD_TOP = 56;
const BOUNDARY_PAD_BOTTOM = 28;

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Runs dagre over a plain id/size/edge graph and returns each node's
 * top-left global rect -- the part shared by both layoutSpec (a freshly
 * generated spec) and relayoutGraph (an "Auto-arrange" over whatever's on
 * the canvas right now, including manually added nodes). */
function dagreLayout(sizeById: Map<string, { width: number; height: number }>, edgePairs: [string, string][]): Map<string, Rect> {
  const g = new dagre.graphlib.Graph();
  g.setGraph({ rankdir: "TB", nodesep: 70, ranksep: 90, marginx: 20, marginy: 20 });
  g.setDefaultEdgeLabel(() => ({}));

  for (const [id, size] of sizeById) g.setNode(id, size);
  for (const [from, to] of edgePairs) {
    if (!g.hasNode(from) || !g.hasNode(to)) continue;
    g.setEdge(from, to);
  }

  dagre.layout(g);

  const rects = new Map<string, Rect>();
  for (const id of sizeById.keys()) {
    const dn = g.node(id);
    if (!dn) continue;
    rects.set(id, { x: dn.x - dn.width / 2, y: dn.y - dn.height / 2, w: dn.width, h: dn.height });
  }
  return rects;
}

/** Wraps a set of member rects in a padded boundary rect. */
function boundingRect(rects: Rect[]): Rect {
  const minX = Math.min(...rects.map((r) => r.x)) - BOUNDARY_PAD_X;
  const minY = Math.min(...rects.map((r) => r.y)) - BOUNDARY_PAD_TOP;
  const maxX = Math.max(...rects.map((r) => r.x + r.w)) + BOUNDARY_PAD_X;
  const maxY = Math.max(...rects.map((r) => r.y + r.h)) + BOUNDARY_PAD_BOTTOM;
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

/** Fresh layout straight from a generated ArchitectureSpec -- used on first
 * generation and every subsequent chat-driven regeneration. */
export function layoutSpec(spec: ArchitectureSpec): { nodes: Node[]; edges: Edge[] } {
  const shapeById = new Map<string, ShapeKind>();
  const sizeById = new Map<string, { width: number; height: number }>();
  // Cloned per node -- dagre mutates the size object it's given in place to
  // record the computed x/y, so sharing SHAPE_SIZE's constant object
  // reference across same-shape nodes would collapse them onto whichever
  // node dagre happened to process last.
  for (const n of spec.nodes) {
    const shape = shapeForType(n.type);
    shapeById.set(n.id, shape);
    sizeById.set(n.id, { ...SHAPE_SIZE[shape] });
  }
  for (const e of spec.edges) {
    if (!sizeById.has(e.from)) sizeById.set(e.from, { ...SHAPE_SIZE.rect });
    if (!sizeById.has(e.to)) sizeById.set(e.to, { ...SHAPE_SIZE.rect });
  }

  const globalRect = dagreLayout(sizeById, spec.edges.map((e) => [e.from, e.to]));

  const memberOf = new Map<string, string>();
  for (const b of spec.boundaries ?? []) {
    for (const id of b.inside) memberOf.set(id, b.id);
  }

  const boundaryRect = new Map<string, Rect>();
  for (const b of spec.boundaries ?? []) {
    const rects = b.inside.map((id) => globalRect.get(id)).filter((r): r is Rect => !!r);
    if (rects.length === 0) continue;
    boundaryRect.set(b.id, boundingRect(rects));
  }

  const nodes: Node[] = [];
  for (const b of spec.boundaries ?? []) {
    const rect = boundaryRect.get(b.id);
    if (!rect) continue;
    nodes.push({
      id: b.id,
      type: "boundary",
      position: { x: rect.x, y: rect.y },
      style: { width: rect.w, height: rect.h },
      data: { kind: "boundary", label: b.name, description: b.description } satisfies BoundaryNodeData,
      zIndex: -1,
    });
  }

  for (const n of spec.nodes) {
    const rect = globalRect.get(n.id);
    if (!rect) continue;
    const parentId = memberOf.get(n.id);
    const parentRect = parentId ? boundaryRect.get(parentId) : undefined;
    const position = parentRect ? { x: rect.x - parentRect.x, y: rect.y - parentRect.y } : { x: rect.x, y: rect.y };
    nodes.push({
      id: n.id,
      type: "component",
      position,
      ...(parentId && parentRect ? { parentId, extent: "parent" as const } : {}),
      data: {
        kind: "component",
        label: n.name,
        shape: shapeById.get(n.id) ?? "rect",
        componentType: n.type,
        description: n.description,
        satisfies: n.satisfies,
      } satisfies ComponentNodeData,
    });
  }

  const edges: Edge[] = spec.edges.map((e) => {
    const encrypted = e.encryption === "required";
    const label = `${(e.protocol || "tcp").toUpperCase()} ${encrypted ? "\u{1F512}" : "⚠️"}`;
    return {
      id: e.id || `${e.from}-${e.to}`,
      source: e.from,
      target: e.to,
      label,
      type: "smoothstep",
      animated: !encrypted,
      style: encrypted ? undefined : { strokeDasharray: "5 4" },
      data: { description: e.description, satisfies: e.satisfies, encrypted },
    };
  });

  return { nodes, edges };
}

/** "Auto-arrange": re-runs dagre over whatever nodes/edges are on the canvas
 * right now (including manually added/renamed ones), preserving each node's
 * current data/shape/parent grouping -- only positions change. */
export function relayoutGraph(nodes: Node[], edges: Edge[]): Node[] {
  const boundaries = nodes.filter((n) => n.type === "boundary");
  const components = nodes.filter((n) => n.type !== "boundary");

  const sizeById = new Map<string, { width: number; height: number }>();
  for (const n of components) {
    const width = (n.measured?.width ?? (n.style?.width as number) ?? SHAPE_SIZE.rect.width) as number;
    const height = (n.measured?.height ?? (n.style?.height as number) ?? SHAPE_SIZE.rect.height) as number;
    sizeById.set(n.id, { width, height });
  }
  const edgePairs = edges.map((e) => [e.source, e.target] as [string, string]);
  const globalRect = dagreLayout(sizeById, edgePairs);

  const memberOf = new Map<string, string>();
  for (const n of components) {
    if (n.parentId) memberOf.set(n.id, n.parentId);
  }

  const boundaryRect = new Map<string, Rect>();
  for (const b of boundaries) {
    const memberIds = components.filter((n) => n.parentId === b.id).map((n) => n.id);
    const rects = memberIds.map((id) => globalRect.get(id)).filter((r): r is Rect => !!r);
    if (rects.length === 0) continue;
    boundaryRect.set(b.id, boundingRect(rects));
  }

  const next: Node[] = [];
  for (const b of boundaries) {
    const rect = boundaryRect.get(b.id);
    if (!rect) {
      next.push(b); // empty boundary (nothing inside it) -- leave where it is
      continue;
    }
    next.push({ ...b, position: { x: rect.x, y: rect.y }, style: { ...b.style, width: rect.w, height: rect.h } });
  }
  for (const n of components) {
    const rect = globalRect.get(n.id);
    if (!rect) {
      next.push(n);
      continue;
    }
    const parentId = memberOf.get(n.id);
    const parentRect = parentId ? boundaryRect.get(parentId) : undefined;
    const position = parentRect ? { x: rect.x - parentRect.x, y: rect.y - parentRect.y } : { x: rect.x, y: rect.y };
    next.push({ ...n, position });
  }
  return next;
}
