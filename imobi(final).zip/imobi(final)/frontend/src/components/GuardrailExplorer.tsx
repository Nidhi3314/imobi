import { useEffect, useMemo, useRef, useState } from "react";
import {
  Sparkles,
  Send,
  ShieldCheck,
  Globe,
  Lock,
  Database,
  Cloud,
  ShieldAlert,
  Scale,
  Layers,
  BookOpen,
} from "lucide-react";
import { api, type Guardrail, type Citation } from "../api/client";
import { isDeterministicSearchFallback, LIVE_REASONING_UNAVAILABLE_MESSAGE } from "../agentReply";
import { SeverityBadge } from "../design-system/Badge";
import "./GuardrailExplorer.scss";

const SEVERITY_RANK: Record<string, number> = { Mandatory: 3, High: 2, Medium: 1, Low: 0 };
const SEVERITIES = ["Mandatory", "High", "Medium", "Low"];

// A rough visual identity per domain -- purely decorative (icon choice by
// keyword match), never used for any actual filtering/business logic.
const DOMAIN_ICONS: [RegExp, typeof Globe][] = [
  [/privacy/i, Lock],
  [/cloud|infrastructure/i, Cloud],
  [/data|analytics/i, Database],
  [/api|integration/i, Layers],
  [/resilience/i, ShieldAlert],
  [/application/i, BookOpen],
  [/information security/i, ShieldCheck],
];
function domainIcon(domain: string) {
  return DOMAIN_ICONS.find(([re]) => re.test(domain))?.[1] ?? Scale;
}

function useCountUp(value: number, durationMs = 700): number {
  const [display, setDisplay] = useState(value);
  const fromRef = useRef(value);
  useEffect(() => {
    const from = fromRef.current;
    const delta = value - from;
    if (delta === 0) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(from + delta * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return display;
}

function StatTile({ value, label, tone }: { value: number; label: string; tone?: "amber" | "alert" }) {
  const shown = useCountUp(value);
  return (
    <div className={`explorer-stat ${tone ? `explorer-stat-${tone}` : ""}`}>
      <span className="explorer-stat-value">{shown}</span>
      <span className="explorer-stat-label">{label}</span>
    </div>
  );
}

interface AskState {
  query: string;
  reply: string;
  citations: Citation[];
  loading: boolean;
  error?: string;
}

export function GuardrailExplorer() {
  const [guardrails, setGuardrails] = useState<Guardrail[]>([]);
  const [domains, setDomains] = useState<string[]>([]);
  const [domain, setDomain] = useState("");
  const [severity, setSeverity] = useState("");
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [highlighted, setHighlighted] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [askInput, setAskInput] = useState("");
  const [ask, setAsk] = useState<AskState | null>(null);
  const [explaining, setExplaining] = useState<Record<string, { text: string; loading: boolean }>>({});

  useEffect(() => {
    api.listDomains().then(setDomains).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .listGuardrails({ domain: domain || undefined, severity: severity || undefined, q: q || undefined })
      .then(setGuardrails)
      .finally(() => setLoading(false));
  }, [domain, severity, q]);

  const stats = useMemo(
    () => ({
      total: guardrails.length,
      mandatory: guardrails.filter((g) => g.severity === "Mandatory").length,
      merged: guardrails.filter((g) => g.is_duplicate_merge).length,
      broken: guardrails.filter((g) => g.broken_reference).length,
    }),
    [guardrails],
  );

  const domainCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const g of guardrails) counts.set(g.domain, (counts.get(g.domain) ?? 0) + 1);
    return counts;
  }, [guardrails]);

  const grouped = useMemo(() => {
    const byDomain = new Map<string, Guardrail[]>();
    for (const g of guardrails) {
      if (!byDomain.has(g.domain)) byDomain.set(g.domain, []);
      byDomain.get(g.domain)!.push(g);
    }
    for (const list of byDomain.values()) {
      list.sort((a, b) => (SEVERITY_RANK[b.severity] ?? 0) - (SEVERITY_RANK[a.severity] ?? 0));
    }
    return [...byDomain.entries()].sort((a, b) => b[1].length - a[1].length);
  }, [guardrails]);

  async function submitAsk(query: string) {
    if (!query.trim() || ask?.loading) return;
    setAsk({ query, reply: "", citations: [], loading: true });
    try {
      const res = await api.chat(query);
      setAsk({ query, reply: res.reply, citations: res.citations ?? [], loading: false });
    } catch (e) {
      setAsk({ query, reply: "", citations: [], loading: false, error: (e as Error).message });
    }
  }

  function jumpToGuardrail(guardrailId: string) {
    // A cited guardrail should always be reachable regardless of the
    // current filters -- clear them rather than leaving the citation
    // pointing at a row the active filter is hiding.
    setDomain("");
    setSeverity("");
    setQ("");
    setExpanded(guardrailId);
    setHighlighted(guardrailId);
    setTimeout(() => {
      document.getElementById(`guardrail-row-${guardrailId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
    setTimeout(() => setHighlighted((h) => (h === guardrailId ? null : h)), 2200);
  }

  async function explainGuardrail(g: Guardrail) {
    if (explaining[g.id]?.loading) return;
    setExplaining((s) => ({ ...s, [g.id]: { text: s[g.id]?.text ?? "", loading: true } }));
    try {
      const res = await api.chat(
        `Explain in plain language what this guardrail requires and why it matters: "${g.statement}" (guardrail ${g.id}).`,
      );
      const text = isDeterministicSearchFallback(res.reply) ? LIVE_REASONING_UNAVAILABLE_MESSAGE : res.reply;
      setExplaining((s) => ({ ...s, [g.id]: { text, loading: false } }));
    } catch (e) {
      setExplaining((s) => ({ ...s, [g.id]: { text: `Couldn't reach the agent: ${(e as Error).message}`, loading: false } }));
    }
  }

  return (
    <div className="guardrail-explorer">
      <div className="explorer-grid-bg" aria-hidden="true" />

      <h1>Guardrail Explorer</h1>
      <p className="explorer-sub">
        Every guardrail below was derived from real clauses, not typed in by hand — expand a row to see its sources,
        or ask the agent about them directly.
      </p>

      <form
        className="explorer-ask"
        onSubmit={(e) => {
          e.preventDefault();
          submitAsk(askInput);
        }}
      >
        <span className="explorer-ask-icon">
          <Sparkles size={16} />
        </span>
        <input
          className="explorer-ask-input"
          value={askInput}
          onChange={(e) => setAskInput(e.target.value)}
          placeholder="Ask about these guardrails — e.g. &quot;what are the MFA requirements?&quot;"
        />
        <button className="explorer-ask-send" type="submit" disabled={!askInput.trim() || ask?.loading} aria-label="Ask">
          <Send size={15} />
        </button>
      </form>

      {ask && (
        <div className="explorer-ask-answer">
          <span className="explorer-ask-avatar">
            <Sparkles size={14} />
          </span>
          <div className="explorer-ask-answer-body">
            {ask.loading ? (
              <span className="explorer-ask-loading">
                <span className="explorer-loading-dot" /> Searching the guardrail model…
              </span>
            ) : ask.error ? (
              <span className="explorer-ask-error">{ask.error}</span>
            ) : (
              <>
                <p>{ask.reply}</p>
                {ask.citations.length > 0 && (
                  <div className="explorer-ask-citations">
                    {ask.citations.map((c, i) => (
                      <button key={i} type="button" onClick={() => jumpToGuardrail(c.guardrail_id)}>
                        {c.guardrail_id}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      <div className="explorer-stats">
        <StatTile value={stats.total} label="Guardrails" />
        <StatTile value={stats.mandatory} label="Mandatory" />
        <StatTile value={grouped.length} label="Domains shown" />
        <StatTile value={stats.merged} label="Duplicate merges" tone={stats.merged > 0 ? "amber" : undefined} />
        <StatTile value={stats.broken} label="Broken references" tone={stats.broken > 0 ? "alert" : undefined} />
      </div>

      <div className="explorer-filters">
        <input
          className="explorer-search"
          placeholder="Search guardrail text…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>

      <div className="explorer-chip-row">
        <button className={`explorer-chip ${domain === "" ? "active" : ""}`} onClick={() => setDomain("")}>
          All domains
        </button>
        {domains.map((d) => {
          const Icon = domainIcon(d);
          return (
            <button key={d} className={`explorer-chip ${domain === d ? "active" : ""}`} onClick={() => setDomain(d)}>
              <Icon size={12} /> {d}
              {domainCounts.has(d) && <span className="explorer-chip-count">{domainCounts.get(d)}</span>}
            </button>
          );
        })}
      </div>
      <div className="explorer-chip-row">
        <button className={`explorer-chip explorer-chip-sev ${severity === "" ? "active" : ""}`} onClick={() => setSeverity("")}>
          All severities
        </button>
        {SEVERITIES.map((s) => (
          <button
            key={s}
            className={`explorer-chip explorer-chip-sev explorer-chip-sev-${s.toLowerCase()} ${severity === s ? "active" : ""}`}
            onClick={() => setSeverity(s)}
          >
            {s}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="explorer-loading-text">
          <span className="explorer-loading-dot" /> Loading…
        </p>
      ) : (
        <div className="explorer-groups">
          {grouped.map(([domainName, items]) => {
            const Icon = domainIcon(domainName);
            return (
              <section key={domainName} className="explorer-group">
                <div className="explorer-group-header">
                  <Icon size={14} className="explorer-group-icon" />
                  <span className="explorer-group-name">{domainName}</span>
                  <span className="explorer-group-count">{items.length}</span>
                </div>
                <div className="explorer-table">
                  {items.map((g) => (
                    <div
                      key={g.id}
                      id={`guardrail-row-${g.id}`}
                      className={`explorer-row explorer-row-sev-${g.severity.toLowerCase()} ${highlighted === g.id ? "explorer-row-highlighted" : ""}`}
                    >
                      <div className="explorer-row-summary" onClick={() => setExpanded(expanded === g.id ? null : g.id)}>
                        <div className="explorer-row-top">
                          <SeverityBadge severity={g.severity} />
                          <span className="explorer-row-id">{g.id}</span>
                          <div className="explorer-row-flags">
                            {g.is_duplicate_merge && <span className="flag flag-amber">merged duplicate</span>}
                            {g.broken_reference && <span className="flag flag-red">broken reference</span>}
                          </div>
                          <span className={`explorer-chevron ${expanded === g.id ? "open" : ""}`}>▾</span>
                        </div>
                        <p className="explorer-row-statement">{g.statement}</p>
                      </div>
                      {expanded === g.id && (
                        <div className="explorer-row-detail">
                          {g.category && (
                            <p>
                              <strong>Category:</strong> {g.category}
                            </p>
                          )}
                          {g.applicability && (
                            <p>
                              <strong>Applicability:</strong> {g.applicability}
                            </p>
                          )}
                          <p>
                            <strong>Sources</strong> ({g.sources.length}
                            {g.is_duplicate_merge ? " — preserved from all merged clauses" : ""}):
                          </p>
                          <ul>
                            {g.sources.map((s, i) => (
                              <li key={i}>
                                Clause {s.clause_id} {s.document_id && <>(Document {s.document_id})</>}
                              </li>
                            ))}
                          </ul>

                          <div className="explorer-explain">
                            {explaining[g.id] ? (
                              explaining[g.id].loading ? (
                                <span className="explorer-ask-loading">
                                  <span className="explorer-loading-dot" /> Asking the agent…
                                </span>
                              ) : (
                                <div className="explorer-explain-answer">
                                  <Sparkles size={12} />
                                  <p>{explaining[g.id].text}</p>
                                </div>
                              )
                            ) : (
                              <button type="button" className="explorer-explain-btn" onClick={() => explainGuardrail(g)}>
                                <Sparkles size={12} /> Ask the agent to explain this
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
          {guardrails.length === 0 && <p className="explorer-empty">No guardrails match these filters.</p>}
        </div>
      )}
    </div>
  );
}
