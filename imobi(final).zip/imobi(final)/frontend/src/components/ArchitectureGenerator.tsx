import { useEffect, useRef, useState } from "react";
import { FileUp, Send, ShieldCheck, User as UserIcon } from "lucide-react";
import { api, type ArchitectureGenerateResult, type Citation } from "../api/client";
import { Citations } from "./Citations";
import { DocumentPreview } from "./DocumentPreview";
import { ArchitectureCanvas } from "./architecture/ArchitectureCanvas";
import "./ArchitectureGenerator.scss";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  error?: boolean;
}

const EXAMPLE_PROMPTS = [
  "A public web app with a Postgres database, S3 file storage, and an MFA-protected admin console, hosted in the EU",
  "An internal analytics pipeline that ingests customer data from a third-party API and writes to a data warehouse",
  "A mobile app backend with OAuth2 login, a Redis cache, and a payments microservice",
];

const THINKING_PHRASES_FIRST = ["Parsing your requirements…", "Mapping components to guardrails…", "Laying out the diagram…"];
const THINKING_PHRASES_MODIFY = ["Reading the current diagram…", "Applying your change…", "Re-checking guardrail citations…"];

// Baseline nodes every diagram gets regardless of what was described --
// excluded from the "detected" trace so it only calls out what the brief
// actually said, not the fixed secure-by-default scaffolding.
const _BASELINE_NODE_IDS = new Set(["auth_gateway", "api_service", "secret_store", "audit_log", "client"]);

/** A short, human-readable list of what the deterministic parser actually
 * recognized in the brief -- gives the heuristic path a visible "I read
 * this and understood these parts" trace, the same transparency principle
 * AgentTrace gives the main chat, instead of it reading as a black box. */
function detectedComponentNames(result: ArchitectureGenerateResult): string[] {
  return result.spec.nodes.filter((n) => !_BASELINE_NODE_IDS.has(n.id)).map((n) => n.name);
}

/** Flattens every `satisfies` citation across a spec's nodes/edges/controls
 * into the same Citation shape the chat's Citations chip strip uses. */
function specCitations(result: ArchitectureGenerateResult): Citation[] {
  const seen = new Set<string>();
  const citations: Citation[] = [];
  const collect = (items: { satisfies?: { guardrail_id: string; clause_ref: string }[] }[] | undefined) => {
    for (const item of items ?? []) {
      for (const c of item.satisfies ?? []) {
        const key = `${c.guardrail_id}::${c.clause_ref}`;
        if (seen.has(key)) continue;
        seen.add(key);
        citations.push({ guardrail_id: c.guardrail_id, clause_id: c.clause_ref });
      }
    }
  };
  collect(result.spec.nodes);
  collect(result.spec.edges);
  collect(result.spec.controls);
  return citations;
}

export function ArchitectureGenerator() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [result, setResult] = useState<ArchitectureGenerateResult | null>(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [thinkingPhrase, setThinkingPhrase] = useState(THINKING_PHRASES_FIRST[0]);
  const [requestKind, setRequestKind] = useState<"first" | "modify">("first");
  const [previewClauseId, setPreviewClauseId] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const briefRef = useRef<string[]>([]); // every user instruction so far, oldest first

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Tracks the *real* fullscreen state (not just "did we ask for it") so the
  // toggle button stays correct if the user exits with Esc instead of
  // clicking it again.
  useEffect(() => {
    function onChange() {
      setIsFullscreen(document.fullscreenElement === boardRef.current);
    }
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  function toggleFullscreen() {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      boardRef.current?.requestFullscreen();
    }
  }

  // Rotating "what the agent is doing" phrases while a request is in
  // flight -- the same transparency the main chat's AgentTrace gives,
  // scaled down for a single in-progress request instead of a full trace.
  useEffect(() => {
    if (!loading) return;
    const phrases = requestKind === "first" ? THINKING_PHRASES_FIRST : THINKING_PHRASES_MODIFY;
    let i = 0;
    setThinkingPhrase(phrases[0]);
    const id = setInterval(() => {
      i = (i + 1) % phrases.length;
      setThinkingPhrase(phrases[i]);
    }, 1100);
    return () => clearInterval(id);
  }, [loading, requestKind]);

  async function send(text: string) {
    if (!text.trim() || loading) return;
    const isFirst = briefRef.current.length === 0;
    setInput("");
    setLoading(true);
    setRequestKind(isFirst ? "first" : "modify");
    setMessages((m) => [...m, { id: crypto.randomUUID(), role: "user", text }]);

    briefRef.current = [...briefRef.current, isFirst ? text : `Additional instruction: ${text}`];
    const brief = briefRef.current.join("\n\n");

    try {
      const generated = await api.generateArchitecture(brief);
      setResult(generated);

      const detected = detectedComponentNames(generated);
      const detectedNote = detected.length > 0 ? ` Recognized: ${detected.join(", ")}.` : "";
      const heuristicNote =
        generated.spec.generation_mode === "heuristic"
          ? ` (Live AI reasoning wasn't available for this one -- unconfigured, rate-limited, or a transient failure -- so this was assembled by matching keywords in your prompt instead of full reasoning.${detectedNote})`
          : "";
      const reply = isFirst
        ? `Here's a reference architecture for that.${heuristicNote}`
        : `Updated the diagram.${heuristicNote}`;
      setMessages((m) => [...m, { id: crypto.randomUUID(), role: "assistant", text: reply }]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        { id: crypto.randomUUID(), role: "assistant", text: (e as Error).message, error: true },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function onPickFile(file: File) {
    try {
      const { text } = await api.extractArchitectureBrief(file);
      setInput((prev) => (prev ? `${prev}\n\n${text}` : text));
    } catch (e) {
      setMessages((m) => [
        ...m,
        { id: crypto.randomUUID(), role: "assistant", text: `Couldn't read "${file.name}": ${(e as Error).message}`, error: true },
      ]);
    }
  }

  function startOver() {
    briefRef.current = [];
    setMessages([]);
    setResult(null);
    setInput("");
  }

  async function openCitation(citation: Citation) {
    if (citation.clause_id) setPreviewClauseId(citation.clause_id);
  }

  const citations = result ? specCitations(result) : [];

  return (
    <div className={`arch-board ${isFullscreen ? "arch-board-fullscreen" : ""}`} ref={boardRef}>
      <div className="arch-canvas-col">
        <ArchitectureCanvas
          result={result}
          loading={loading}
          thinkingPhrase={thinkingPhrase}
          onOpenCitation={openCitation}
          onStartOver={startOver}
          canStartOver={!!result || messages.length > 0}
          isFullscreen={isFullscreen}
          onToggleFullscreen={toggleFullscreen}
        />

        {result && (
          <div className="arch-canvas-details">
            {result.spec.description && <p className="arch-canvas-desc">{result.spec.description}</p>}
            {result.spec.gaps?.length > 0 && (
              <div className="arch-gen-gaps">
                <strong>Open gaps:</strong>
                <ul>
                  {result.spec.gaps.map((g, i) => (
                    <li key={i}>{g}</li>
                  ))}
                </ul>
              </div>
            )}
            {result.spec.baseline_choices?.length > 0 && (
              <div className="arch-gen-baseline">
                <strong>Baseline choices (no direct guardrail citation -- flagged for review):</strong>
                <ul>
                  {result.spec.baseline_choices.map((b, i) => (
                    <li key={i}>{b.concern} -- {b.rationale}</li>
                  ))}
                </ul>
              </div>
            )}
            <Citations citations={citations} onOpen={openCitation} />
          </div>
        )}
      </div>

      <aside className="arch-chat-sidebar">
        <div className="arch-chat-heading">Agentic chat</div>
        <div className="arch-chat-messages">
          {messages.length === 0 && (
            <div className="arch-chat-empty">
              <p>Ask for a system and I'll draw it -- then keep talking to change it: "add a Redis cache", "move
              the database behind the boundary", "swap Postgres for MongoDB".</p>
              <div className="arch-gen-examples">
                {EXAMPLE_PROMPTS.map((p) => (
                  <button key={p} type="button" onClick={() => send(p)}>
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m) => (
            <div key={m.id} className={`arch-chat-row arch-chat-row-${m.role}`}>
              <span className={`arch-chat-avatar arch-chat-avatar-${m.role}`}>
                {m.role === "assistant" ? <ShieldCheck size={13} /> : <UserIcon size={13} />}
              </span>
              <div className={`arch-chat-bubble arch-chat-bubble-${m.role} ${m.error ? "arch-chat-bubble-error" : ""}`}>
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="arch-chat-row arch-chat-row-assistant">
              <span className="arch-chat-avatar arch-chat-avatar-assistant">
                <ShieldCheck size={13} />
              </span>
              <div className="arch-chat-bubble arch-chat-bubble-assistant arch-chat-bubble-loading">
                <span className="arch-gen-loading-dot" /> {thinkingPhrase}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <form
          className="arch-gen-input-row"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            hidden
            accept=".txt,.md,.pdf,text/plain,application/pdf"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onPickFile(f);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            className="arch-gen-attach-btn"
            onClick={() => fileInputRef.current?.click()}
            title="Fill the prompt from a design doc (.txt, .md, .pdf)"
            disabled={loading}
          >
            <FileUp size={16} />
          </button>
          <input
            className="arch-gen-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={messages.length === 0 ? "Describe the system, or attach a doc…" : "Ask for a change…"}
            disabled={loading}
          />
          <button className="arch-gen-send" type="submit" disabled={loading || !input.trim()} aria-label="Send">
            <Send size={16} />
          </button>
        </form>
      </aside>

      <DocumentPreview clauseId={previewClauseId} onClose={() => setPreviewClauseId(null)} />
    </div>
  );
}
