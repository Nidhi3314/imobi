import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  ChevronRight,
  Copy,
  FileStack,
  FileSearch,
  RefreshCw,
  Scale,
  ShieldAlert,
  Radio,
  ClipboardCheck,
  ShieldCheck,
  History,
  Share2,
  Unlink,
} from "lucide-react";
import { api } from "../api/client";
import "./Dashboard.scss";

const SEVERITY_ORDER = ["Mandatory", "High", "Medium", "Low"];
const SEVERITY_COLOR: Record<string, string> = {
  Mandatory: "var(--color-danger-dark)",
  High: "#f87171",
  Medium: "var(--color-warning-border)",
  Low: "var(--color-gray-300)",
};

type Summary = Awaited<ReturnType<typeof api.dashboardSummary>>;

/** Animates a number from 0 -> value once it first becomes available (and
 * again on every subsequent change, e.g. a manual refresh) -- purely a
 * presentation flourish, the underlying value is always the real fetched
 * number, never a fake ramp. */
function useCountUp(value: number, durationMs = 900): number {
  const [display, setDisplay] = useState(0);
  const fromRef = useRef(0);

  useEffect(() => {
    const from = fromRef.current;
    const delta = value - from;
    if (delta === 0) {
      setDisplay(value);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3); // ease-out-cubic
      setDisplay(Math.round(from + delta * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
      else fromRef.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return display;
}

function StatTile({
  icon,
  value,
  label,
  alert,
  onClick,
}: {
  icon: React.ReactNode;
  value: number;
  label: string;
  alert?: boolean;
  onClick?: () => void;
}) {
  const shown = useCountUp(value);
  return (
    <div
      className={`stat-tile ${onClick ? "stat-tile-clickable" : ""} ${alert ? "stat-tile-alert" : ""}`}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => (e.key === "Enter" || e.key === " ") && onClick() : undefined}
    >
      <span className="stat-tile-glow" aria-hidden="true" />
      <span className="stat-icon">{icon}</span>
      <div className="stat-value">{shown}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

interface AgentSpec {
  name: string;
  icon: React.ReactNode;
  metric: (s: Summary, precedent: number) => string;
  onClick?: (onNavigate: (view: "guardrails" | "conflicts") => void) => void;
}

// The actual pipeline order (see README's architecture diagram) -- every
// metric below is read straight off the same live summary the stat tiles
// use, never invented, so this reads as "here's what each agent actually
// did," not a decorative org chart.
const AGENTS: AgentSpec[] = [
  {
    name: "Extraction Agent",
    icon: <FileSearch size={16} />,
    metric: (s) => `${s.clauses} clauses → draft guardrails`,
    onClick: (nav) => nav("guardrails"),
  },
  {
    name: "Dedup Agent",
    icon: <Copy size={16} />,
    metric: (s) => `${s.duplicates_merged} duplicate${s.duplicates_merged === 1 ? "" : "s"} merged`,
    onClick: (nav) => nav("guardrails"),
  },
  {
    name: "Orphan Agent",
    icon: <Unlink size={16} />,
    metric: (s) => (s.broken_references > 0 ? `${s.broken_references} broken reference(s) flagged` : "0 broken references — every source verified"),
  },
  {
    name: "Conflict Agent",
    icon: <Scale size={16} />,
    metric: (s) => `${s.conflicts_open + s.conflicts_decided} conflict(s) detected, ${s.conflicts_open} open`,
    onClick: (nav) => nav("conflicts"),
  },
  {
    name: "Evaluation Agent",
    icon: <ClipboardCheck size={16} />,
    metric: (s) => `Ready against ${s.designs} design(s) on demand`,
  },
  {
    name: "Auditor Agent",
    icon: <ShieldCheck size={16} />,
    metric: () => "Independently re-checks every verdict",
  },
  {
    name: "Precedent Agent",
    icon: <History size={16} />,
    metric: (_s, precedent) => `${precedent} human decision(s) learned from`,
  },
  {
    name: "Orchestrator",
    icon: <Share2 size={16} />,
    metric: () => "Routes every chat message to the right specialist",
  },
];

function AgentRoster({
  summary,
  precedentDecisions,
  onNavigate,
}: {
  summary: Summary;
  precedentDecisions: number;
  onNavigate: (view: "guardrails" | "conflicts") => void;
}) {
  return (
    <div className="agent-roster">
      <div className="agent-roster-heading">
        <span className="agent-roster-pulse" />
        Multi-agent pipeline — live
      </div>
      <div className="agent-roster-row">
        {AGENTS.map((agent, i) => (
          <div key={agent.name} className="agent-roster-item">
            <div
              className={`agent-card ${agent.onClick ? "agent-card-clickable" : ""}`}
              onClick={agent.onClick ? () => agent.onClick!(onNavigate) : undefined}
              role={agent.onClick ? "button" : undefined}
              tabIndex={agent.onClick ? 0 : undefined}
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <span className="agent-card-icon">{agent.icon}</span>
              <span className="agent-card-name">{agent.name}</span>
              <span className="agent-card-metric">{agent.metric(summary, precedentDecisions)}</span>
            </div>
            {i < AGENTS.length - 1 && <ChevronRight size={14} className="agent-roster-arrow" />}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Dashboard({ onNavigate }: { onNavigate: (view: "guardrails" | "conflicts") => void }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [precedentDecisions, setPrecedentDecisions] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [chartsIn, setChartsIn] = useState(false);
  const [hoverSeverity, setHoverSeverity] = useState<string | null>(null);
  const [now, setNow] = useState(() => new Date());

  function load(isRefresh = false) {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    api
      .dashboardSummary()
      .then((s) => {
        setSummary(s);
        setChartsIn(false);
        // Let the bars/ring mount at 0 width first, then animate to their
        // real values on the next frame -- a plain initial render at full
        // width wouldn't transition.
        requestAnimationFrame(() => requestAnimationFrame(() => setChartsIn(true)));
      })
      .finally(() => {
        setLoading(false);
        setRefreshing(false);
      });
    api
      .llmStatus()
      .then((s) => setPrecedentDecisions(s.learning.precedent_decisions))
      .catch(() => {});
  }

  useEffect(() => load(), []);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  if (loading || !summary) {
    return (
      <div className="dashboard">
        <div className="dashboard-grid-bg" aria-hidden="true" />
        <h1>Dashboard</h1>
        <p className="dashboard-loading">
          <span className="pulse-dot" /> Loading live guardrail model…
        </p>
      </div>
    );
  }

  const domainEntries = Object.entries(summary.guardrails_by_domain).sort((a, b) => b[1] - a[1]);
  const maxDomainCount = Math.max(...domainEntries.map(([, v]) => v), 1);
  const severityEntries = SEVERITY_ORDER.filter((s) => summary.guardrails_by_severity[s]).map(
    (s) => [s, summary.guardrails_by_severity[s]] as const,
  );

  // Build the stroke-dasharray/offset for each ring segment (classic SVG
  // "donut chart from stacked circles" technique) so the severity mix reads
  // as a single glowing ring instead of a flat bar.
  const RADIUS = 54;
  const CIRC = 2 * Math.PI * RADIUS;
  let cumulative = 0;
  const ringSegments = severityEntries.map(([sev, count]) => {
    const fraction = count / summary.guardrails_total;
    const segment = { sev, count, fraction, offset: cumulative * CIRC };
    cumulative += fraction;
    return segment;
  });

  return (
    <div className="dashboard">
      <div className="dashboard-grid-bg" aria-hidden="true" />

      <div className="dashboard-header">
        <div>
          <h1>Dashboard</h1>
          <p className="dashboard-sub">
            A live view of the guardrail model — every number here is computed fresh from the database, not cached,
            so it reflects the current state after any re-ingest or Conflict Desk decision.
          </p>
        </div>
        <div className="dashboard-header-actions">
          <span className="live-badge" title={`Last refreshed ${now.toLocaleTimeString()}`}>
            <Radio size={12} className="live-badge-icon" />
            Live
          </span>
          <button
            className={`refresh-btn ${refreshing ? "spinning" : ""}`}
            onClick={() => load(true)}
            disabled={refreshing}
            aria-label="Refresh dashboard"
            title="Refresh"
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </div>

      <AgentRoster summary={summary} precedentDecisions={precedentDecisions} onNavigate={onNavigate} />

      <div className="stat-grid">
        <StatTile icon={<FileStack size={20} />} value={summary.guardrails_total} label="Guardrails" />
        <StatTile
          icon={<Copy size={20} />}
          value={summary.duplicates_merged}
          label="Duplicates merged"
          onClick={() => onNavigate("guardrails")}
        />
        <StatTile
          icon={<Scale size={20} />}
          value={summary.conflicts_open}
          label="Open conflicts"
          alert={summary.conflicts_open > 0}
          onClick={() => onNavigate("conflicts")}
        />
        <StatTile icon={<ShieldAlert size={20} />} value={summary.conflicts_decided} label="Conflicts decided" />
        <StatTile
          icon={<AlertTriangle size={20} />}
          value={summary.broken_references}
          label="Broken references"
          alert={summary.broken_references > 0}
        />
        <StatTile icon={<span className="stat-icon-dot" />} value={summary.documents} label="Source documents" />
        <StatTile icon={<span className="stat-icon-dot" />} value={summary.clauses} label="Clauses ingested" />
        <StatTile icon={<span className="stat-icon-dot" />} value={summary.designs} label="Designs available" />
      </div>

      <div className="chart-grid">
        <div className="chart-card">
          <h2>Guardrails by domain</h2>
          <div className="bar-chart">
            {domainEntries.map(([domain, count]) => (
              <button key={domain} className="bar-row" onClick={() => onNavigate("guardrails")}>
                <span className="bar-label">{domain}</span>
                <span className="bar-track">
                  <span
                    className="bar-fill"
                    style={{ width: chartsIn ? `${(count / maxDomainCount) * 100}%` : "0%" }}
                  />
                </span>
                <span className="bar-count">{count}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="chart-card chart-card-ring">
          <h2>Guardrails by severity</h2>
          <div className="ring-wrap">
            <svg viewBox="0 0 120 120" className="severity-ring">
              <circle className="ring-track" cx="60" cy="60" r={RADIUS} />
              {ringSegments.map(({ sev, fraction, offset }) => (
                <circle
                  key={sev}
                  cx="60"
                  cy="60"
                  r={RADIUS}
                  className={`ring-segment ${hoverSeverity && hoverSeverity !== sev ? "ring-segment-dim" : ""}`}
                  stroke={SEVERITY_COLOR[sev]}
                  strokeDasharray={`${chartsIn ? fraction * CIRC : 0} ${CIRC}`}
                  strokeDashoffset={-offset}
                  onMouseEnter={() => setHoverSeverity(sev)}
                  onMouseLeave={() => setHoverSeverity(null)}
                >
                  <title>{`${sev}: ${summary.guardrails_by_severity[sev]}`}</title>
                </circle>
              ))}
            </svg>
            <div className="ring-center">
              <div className="ring-center-value">{summary.guardrails_total}</div>
              <div className="ring-center-label">{hoverSeverity ?? "total"}</div>
            </div>
          </div>
          <ul className="severity-legend">
            {severityEntries.map(([sev, count]) => (
              <li
                key={sev}
                className={hoverSeverity === sev ? "legend-active" : ""}
                onMouseEnter={() => setHoverSeverity(sev)}
                onMouseLeave={() => setHoverSeverity(null)}
              >
                <span className="legend-dot" style={{ background: SEVERITY_COLOR[sev] }} />
                {sev} — {count}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
