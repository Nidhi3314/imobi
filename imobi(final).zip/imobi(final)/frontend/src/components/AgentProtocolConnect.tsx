import { useState } from "react";
import { Check, Copy, Network, X } from "lucide-react";
import "./AgentProtocolConnect.scss";

const BASE_URL: string = (import.meta.env.VITE_API_BASE_URL as string) || "http://localhost:8000";

interface Endpoint {
  protocol: string;
  label: string;
  url: string;
  hint: string;
}

const ENDPOINTS: Endpoint[] = [
  {
    protocol: "MCP",
    label: "Server (SSE)",
    url: `${BASE_URL}/mcp/sse`,
    hint: "Any MCP client that supports a remote/SSE server URL (Claude Desktop, Claude Code, Cursor, etc.) can connect here directly -- no local process to spawn. Exposes list_guardrails, evaluate_design, list_open_conflicts, ask_complix and more as tools.",
  },
  {
    protocol: "A2A",
    label: "Agent Card (discovery)",
    url: `${BASE_URL}/.well-known/agent.json`,
    hint: "Point any A2A-compatible client or orchestrator (Google's a2a-sdk, LangGraph/CrewAI A2A adapters, etc.) here to discover CompliX's skills.",
  },
  {
    protocol: "A2A",
    label: "Task endpoint",
    url: `${BASE_URL}/a2a`,
    hint: "JSON-RPC tasks/send -- the Agent Card's url field points here.",
  },
  {
    protocol: "ACP",
    label: "Agent manifest",
    url: `${BASE_URL}/acp/agents`,
    hint: "ACP-native orchestrators (e.g. BeeAI) list this endpoint to discover CompliX as agent \"complix\".",
  },
  {
    protocol: "ACP",
    label: "Run endpoint",
    url: `${BASE_URL}/acp/runs`,
    hint: "POST a run with agent_name \"complix\" to get a citation-gated answer back.",
  },
];

function CopyRow({ endpoint }: { endpoint: Endpoint }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(endpoint.url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      // clipboard unavailable -- the URL is still selectable/visible
    }
  }

  return (
    <div className="agent-protocol-row">
      <div className="agent-protocol-row-head">
        <span className="agent-protocol-tag">{endpoint.protocol}</span>
        <span className="agent-protocol-label">{endpoint.label}</span>
      </div>
      <div className="agent-protocol-url-line">
        <code className="agent-protocol-url">{endpoint.url}</code>
        <button type="button" className="agent-protocol-copy" onClick={copy} aria-label={`Copy ${endpoint.label} URL`}>
          {copied ? <Check size={13} /> : <Copy size={13} />}
        </button>
      </div>
      <p className="agent-protocol-hint">{endpoint.hint}</p>
    </div>
  );
}

export function AgentProtocolConnectButton() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button type="button" className="agent-protocol-btn" onClick={() => setOpen(true)}>
        <Network size={14} />
        Connect an external agent
      </button>

      {open && (
        <div className="agent-protocol-overlay" onClick={() => setOpen(false)}>
          <div className="agent-protocol-modal" onClick={(e) => e.stopPropagation()}>
            <div className="agent-protocol-modal-header">
              <span>
                <Network size={15} /> Connect via MCP / A2A / ACP
              </span>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close">
                <X size={16} />
              </button>
            </div>
            <p className="agent-protocol-intro">
              CompliX can be added as a callable agent (or MCP tool server) inside an external agentic platform,
              over three open interoperability protocols. Every path below hands the request to the exact same
              Orchestrator/tool code this chat uses -- an external platform gets the same citation-gated answers a
              person typing here does, never a looser guarantee.
            </p>
            <div className="agent-protocol-list">
              {ENDPOINTS.map((e) => (
                <CopyRow key={e.url} endpoint={e} />
              ))}
            </div>
            <p className="agent-protocol-footnote">
              No pairing step needed here -- these are read-only discovery/invoke endpoints. If the external
              platform needs write access to Jira/Confluence on CompliX's behalf, attach those separately from the
              chat settings (gear icon) Integrations panel.
            </p>
          </div>
        </div>
      )}
    </>
  );
}
