import { useRef } from "react";
import { Image as ImageIcon, FileText, PenSquare, Plus } from "lucide-react";
import "./AttachMenu.scss";

interface Props {
  open: boolean;
  onToggleOpen: () => void;
  onPickDiagram: (file: File) => void;
  onPickTextFile: (file: File) => void;
  onDescribeArchitecture: () => void;
  disabled?: boolean;
}

export function AttachMenu({ open, onToggleOpen, onPickDiagram, onPickTextFile, onDescribeArchitecture, disabled }: Props) {
  const diagramInputRef = useRef<HTMLInputElement>(null);
  const textInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="attach-menu-wrap">
      <input
        ref={diagramInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        hidden
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onPickDiagram(file);
          e.target.value = "";
        }}
      />
      <input
        ref={textInputRef}
        type="file"
        accept=".txt,.md,.pdf,text/plain,application/pdf"
        hidden
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onPickTextFile(file);
          e.target.value = "";
        }}
      />

      <button
        type="button"
        className="chat-attach-btn"
        onClick={onToggleOpen}
        disabled={disabled}
        aria-label="Attach or describe an architecture"
        aria-expanded={open}
        title="Attach or describe an architecture"
      >
        <Plus size={16} />
      </button>

      {open && (
        <div className="attach-menu">
          <button
            onClick={() => {
              onToggleOpen();
              diagramInputRef.current?.click();
            }}
          >
            <ImageIcon size={15} />
            <span>
              <strong>Upload architecture diagram</strong>
              <small>An image — analyzed and evaluated like a design</small>
            </span>
          </button>
          <button
            onClick={() => {
              onToggleOpen();
              textInputRef.current?.click();
            }}
          >
            <FileText size={15} />
            <span>
              <strong>Upload a design file</strong>
              <small>A .txt, .md, or .pdf design description</small>
            </span>
          </button>
          <button
            onClick={() => {
              onToggleOpen();
              onDescribeArchitecture();
            }}
          >
            <PenSquare size={15} />
            <span>
              <strong>Describe your architecture</strong>
              <small>Answer a few prompts instead of typing free text</small>
            </span>
          </button>
        </div>
      )}
    </div>
  );
}
