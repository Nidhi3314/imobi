import { useState } from "react";
import type { Finding } from "../api/client";
import { VerdictBadge, SeverityBadge, Chip } from "../design-system/Badge";
import "./ChatFindings.scss";

interface Props {
  findings: Finding[];
}

/** Renders per-guardrail findings in a chat response using the same
 * verdict/severity badge colors as the Guardrail Explorer and Evaluation
 * Report views -- red for Mandatory/Non-compliant, amber for Medium/Gap,
 * grey for Low/Unverified -- instead of plain emoji-prefixed text. */
export function ChatFindings({ findings }: Props) {
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  if (findings.length === 0) return null;

  const hasGap = findings.some((f) => f.verdict === "Gap");

  return (
    <div className="chat-findings">
      {hasGap && (
        <p className="chat-findings-legend">
          The severity badge (e.g. "Mandatory") is the guardrail's own importance, not the verdict — a{" "}
          <strong>Gap</strong> means the design doesn't say enough to confirm compliance either way, it's not a
          violation.
        </p>
      )}
      {findings.map((f, i) => (
        <div key={i} className="chat-finding-card">
          <div className="chat-finding-header">
            <VerdictBadge verdict={f.verdict} />
            <SeverityBadge
              severity={f.severity}
              title={`${f.severity}: how serious this guardrail is in general -- independent of the verdict. ${
                f.verdict === "Gap"
                  ? "Gap means the design doesn't give enough evidence to confirm compliance either way, not that it's compliant."
                  : ""
              }`}
            />
            <Chip>{f.guardrail_id}</Chip>
          </div>
          <p className="chat-finding-text">{f.plain_language || f.guardrail_statement}</p>
          {f.evidence_quote && (
            <button className="chat-finding-toggle" onClick={() => setExpanded((s) => ({ ...s, [i]: !s[i] }))}>
              {expanded[i] ? "Hide" : "Show"} evidence
            </button>
          )}
          {expanded[i] && f.evidence_quote && <blockquote className="chat-finding-evidence">"{f.evidence_quote}"</blockquote>}
        </div>
      ))}
    </div>
  );
}
