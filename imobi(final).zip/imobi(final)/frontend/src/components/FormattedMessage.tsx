import { Fragment } from "react";
import type { ResponseSection } from "../api/client";
import "./FormattedMessage.scss";

/** Splits **bold** markers out of a single line into React nodes. */
function parseInline(line: string, key: string | number) {
  const parts = line.split(/(\*\*[^*]+\*\*)/g).filter((p) => p !== "");
  return parts.map((part, i) =>
    part.startsWith("**") && part.endsWith("**") ? (
      <strong key={`${key}-${i}`}>{part.slice(2, -2)}</strong>
    ) : (
      <Fragment key={`${key}-${i}`}>{part}</Fragment>
    ),
  );
}

function renderFormattedText(text: string) {
  return text.split(/\n\n+/).map((paragraph, pi) => (
    <p key={pi} className="formatted-paragraph">
      {paragraph.split("\n").map((line, li, arr) => (
        <Fragment key={li}>
          {parseInline(line, li)}
          {li < arr.length - 1 && <br />}
        </Fragment>
      ))}
    </p>
  ));
}

interface Props {
  text: string;
  sections?: ResponseSection[];
}

/** Renders a chat response as either plain formatted text, or -- when the
 * backend supplies structured `sections` -- as titled blocks, so answers
 * read as organized findings instead of one dense paragraph. */
export function FormattedMessage({ text, sections }: Props) {
  if (!sections || sections.length === 0) {
    return <div className="formatted-message">{renderFormattedText(text)}</div>;
  }
  return (
    <div className="formatted-message">
      {sections.map((s, i) => (
        <div key={i} className="formatted-section">
          <div className="formatted-section-title">{s.title}</div>
          <div className="formatted-section-content">{renderFormattedText(s.content)}</div>
        </div>
      ))}
    </div>
  );
}
