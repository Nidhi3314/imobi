import { useEffect, useState } from "react";
import { BookOpen, Cpu, Link2, Loader2, Settings, Sparkles, X } from "lucide-react";
import { api } from "../api/client";
import "./ChatSettings.scss";

export interface ChatSettingsState {
  showTrace: boolean;
  showThinkingPhrases: boolean;
}

interface LlmMode {
  configured: boolean;
  model: string | null;
  learning: { precedent_decisions: number; metrics_covered: string[] };
}

interface Props {
  open: boolean;
  onToggleOpen: () => void;
  settings: ChatSettingsState;
  onSettingsChange: (settings: ChatSettingsState) => void;
  llmMode: LlmMode | null;
}

const PROVIDER_LABELS: Record<"jira" | "confluence", string> = { jira: "Jira", confluence: "Confluence" };

function IntegrationRow({ provider, connected, onChange }: { provider: "jira" | "confluence"; connected: boolean; onChange: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [baseUrl, setBaseUrl] = useState("");
  const [email, setEmail] = useState("");
  const [apiToken, setApiToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function connect(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.attachIntegration(provider, baseUrl, email, apiToken);
      setExpanded(false);
      setApiToken("");
      onChange();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function disconnect() {
    setBusy(true);
    try {
      await api.detachIntegration(provider);
      onChange();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="chat-integration-row">
      <div className="chat-integration-summary">
        <span className={`chat-integration-dot ${connected ? "on" : ""}`} />
        <span className="chat-integration-name">{PROVIDER_LABELS[provider]}</span>
        {connected ? (
          <button type="button" className="chat-integration-action" onClick={disconnect} disabled={busy}>
            {busy ? <Loader2 size={11} className="chat-integration-spin" /> : "Disconnect"}
          </button>
        ) : (
          <button type="button" className="chat-integration-action" onClick={() => setExpanded((v) => !v)}>
            {expanded ? "Cancel" : "Connect"}
          </button>
        )}
      </div>
      {expanded && !connected && (
        <form className="chat-integration-form" onSubmit={connect}>
          <input
            placeholder={`${PROVIDER_LABELS[provider]} site URL, e.g. https://yourteam.atlassian.net`}
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            required
          />
          <input placeholder="Account email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <input
            placeholder="API token"
            type="password"
            value={apiToken}
            onChange={(e) => setApiToken(e.target.value)}
            required
          />
          {error && <p className="chat-integration-error">{error}</p>}
          <button className="btn-primary chat-integration-submit" type="submit" disabled={busy}>
            {busy ? "Connecting…" : "Connect"}
          </button>
        </form>
      )}
    </div>
  );
}

export function ChatSettingsButton({ open, onToggleOpen }: Pick<Props, "open" | "onToggleOpen">) {
  return (
    <button
      className="chat-settings-btn"
      onClick={onToggleOpen}
      aria-label="Chat settings"
      aria-expanded={open}
      title="Chat settings"
    >
      <Settings size={16} />
    </button>
  );
}

export function ChatSettingsPanel({ open, onToggleOpen, settings, onSettingsChange, llmMode }: Props) {
  const [connected, setConnected] = useState<string[]>([]);

  function refreshIntegrations() {
    api.listIntegrations().then((r) => setConnected(r.connected)).catch(() => {});
  }

  useEffect(() => {
    if (open) refreshIntegrations();
  }, [open]);

  if (!open) return null;

  return (
    <div className="chat-settings-panel">
      <div className="chat-settings-header">
        <span>Chat settings</span>
        <button onClick={onToggleOpen} aria-label="Close settings">
          <X size={15} />
        </button>
      </div>

      <label className="chat-settings-toggle">
        <input
          type="checkbox"
          checked={settings.showTrace}
          onChange={(e) => onSettingsChange({ ...settings, showTrace: e.target.checked })}
        />
        Show agent workflow trace
      </label>

      <label className="chat-settings-toggle">
        <input
          type="checkbox"
          checked={settings.showThinkingPhrases}
          onChange={(e) => onSettingsChange({ ...settings, showThinkingPhrases: e.target.checked })}
        />
        Show "thinking" status phrases
      </label>

      <div className="chat-settings-mode">
        <span className="chat-settings-mode-label">Reasoning mode (read-only)</span>
        <span className="chat-settings-mode-value">
          {llmMode ? (
            <>
              {llmMode.configured ? <Sparkles size={12} /> : <Cpu size={12} />}
              {llmMode.configured ? `LLM — ${llmMode.model}` : "Heuristic fallback (no LLM configured)"}
            </>
          ) : (
            "Checking…"
          )}
        </span>
      </div>

      <div className="chat-settings-mode">
        <span className="chat-settings-mode-label">Learning (read-only)</span>
        <span className="chat-settings-mode-value">
          {llmMode ? (
            <>
              <BookOpen size={12} />
              {llmMode.learning.precedent_decisions === 0
                ? "No precedent yet — the Conflict Agent starts learning after the first Conflict Desk decision"
                : `Applying ${llmMode.learning.precedent_decisions} past decision${llmMode.learning.precedent_decisions === 1 ? "" : "s"} as precedent across ${llmMode.learning.metrics_covered.length} conflict type${llmMode.learning.metrics_covered.length === 1 ? "" : "s"}`}
            </>
          ) : (
            "Checking…"
          )}
        </span>
      </div>

      <div className="chat-settings-mode">
        <span className="chat-settings-mode-label">
          <Link2 size={11} /> Integrations
        </span>
        <p className="chat-integrations-hint">
          Attach Jira/Confluence so the assistant can check or reference them while answering — e.g. "is this already
          tracked in Jira?" Credentials stay in memory only, never written to disk.
        </p>
        <IntegrationRow provider="jira" connected={connected.includes("jira")} onChange={refreshIntegrations} />
        <IntegrationRow provider="confluence" connected={connected.includes("confluence")} onChange={refreshIntegrations} />
      </div>
    </div>
  );
}
