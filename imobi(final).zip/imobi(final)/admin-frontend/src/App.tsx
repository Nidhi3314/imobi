import { useEffect, useState } from "react";
import { Bell, FilePlus2, FileText, LogOut, Moon, Scale, ShieldCheck, ShieldPlus, Sun, UserRound } from "lucide-react";
import "./App.scss";
import { AuthProvider, useAuth } from "./auth/AuthContext";
import { AdminAuth } from "./components/AdminAuth";
import { AdminConflictDesk } from "./components/AdminConflictDesk";
import { AdminDesignForm } from "./components/AdminDesignForm";
import { AdminDocuments } from "./components/AdminDocuments";
import { AdminGuardrailForm } from "./components/AdminGuardrailForm";
import { AdminUsers } from "./components/AdminUsers";
import { api } from "./api/client";
import { useTheme } from "./theme";

type Tab = "conflicts" | "documents" | "guardrails" | "designs" | "users";

function ConsoleShell() {
  const { admin, loading, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const isDark = theme === "dark" || (theme === "system" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  const [tab, setTab] = useState<Tab>("conflicts");
  const [assignedCount, setAssignedCount] = useState(0);

  useEffect(() => {
    if (!admin) return;
    let cancelled = false;
    function poll() {
      api
        .myAssignedTickets()
        .then((tickets) => !cancelled && setAssignedCount(tickets.length))
        .catch(() => {});
    }
    poll();
    const id = setInterval(poll, 20000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [admin]);

  if (loading) {
    return <div className="admin-loading">Loading…</div>;
  }

  if (!admin) {
    return <AdminAuth />;
  }

  return (
    <div className="admin-shell">
      <header className="admin-navbar">
        <div className="admin-navbar-identity">
          <span className="admin-navbar-brand">
            <ShieldCheck size={22} /> CompliX
          </span>
          <span className="admin-navbar-tagline">Admin Console</span>
        </div>
        <nav className="admin-navbar-tabs">
          <button className={tab === "conflicts" ? "active" : ""} onClick={() => setTab("conflicts")}>
            <Scale size={14} /> Conflict Desk
            {assignedCount > 0 && <span className="admin-navbar-badge">{assignedCount}</span>}
          </button>
          <button className={tab === "documents" ? "active" : ""} onClick={() => setTab("documents")}>
            <FileText size={14} /> Documents
          </button>
          <button className={tab === "guardrails" ? "active" : ""} onClick={() => setTab("guardrails")}>
            <ShieldPlus size={14} /> Add Guardrail
          </button>
          <button className={tab === "designs" ? "active" : ""} onClick={() => setTab("designs")}>
            <FilePlus2 size={14} /> Add Design
          </button>
          <button className={tab === "users" ? "active" : ""} onClick={() => setTab("users")}>
            <UserRound size={14} /> Users
          </button>
        </nav>
        <div className="admin-navbar-spacer" />
        {assignedCount > 0 && (
          <span className="admin-navbar-notification" title={`${assignedCount} ticket(s) assigned to you`}>
            <Bell size={15} /> {assignedCount}
          </span>
        )}
        <button className="theme-toggle" onClick={toggle} aria-label="Toggle dark mode" title="Toggle dark mode">
          {isDark ? <Sun size={15} /> : <Moon size={15} />}
        </button>
        <div className="admin-navbar-account">
          <span className="admin-navbar-name">
            <UserRound size={16} /> {admin.display_name || admin.username}
          </span>
          <button className="admin-navbar-signout" onClick={logout}>
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </header>
      <main className="admin-main">
        {tab === "conflicts" && <AdminConflictDesk />}
        {tab === "documents" && <AdminDocuments />}
        {tab === "guardrails" && <AdminGuardrailForm />}
        {tab === "designs" && <AdminDesignForm />}
        {tab === "users" && <AdminUsers />}
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ConsoleShell />
    </AuthProvider>
  );
}

export default App;
