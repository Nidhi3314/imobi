import { useEffect, useState } from "react";
import { ChevronDown, ChevronUp, FileText, Plus, RefreshCw } from "lucide-react";
import { api, type GovernanceDocument } from "../api/client";
import { AdminFileUploadButton } from "./AdminFileUploadButton";
import "./AdminDocuments.scss";

interface ClauseRow {
  id: string;
  document_id: string;
  clause_ref: string | null;
  clause_heading: string | null;
  clause_text: string;
}

function DocumentClauses({ documentId }: { documentId: string }) {
  const [clauses, setClauses] = useState<ClauseRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [heading, setHeading] = useState("");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  function load() {
    setLoading(true);
    api
      .listDocumentClauses(documentId)
      .then(setClauses)
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [documentId]);

  async function addClause(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.createClause(documentId, { clause_heading: heading || undefined, clause_text: text });
      setHeading("");
      setText("");
      load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-document-clauses">
      <p className="admin-document-clauses-hint">
        Copy a clause ID below into Add Guardrail's "source clause ID(s)" field to cite it.
      </p>
      {error && <p className="admin-documents-error">{error}</p>}
      {loading ? (
        <p>Loading clauses…</p>
      ) : clauses.length === 0 ? (
        <p className="admin-document-clauses-empty">No clauses yet -- add one below.</p>
      ) : (
        <ul className="admin-clause-list">
          {clauses.map((c) => (
            <li key={c.id}>
              <code className="admin-clause-id">{c.id}</code>
              {c.clause_heading && <strong> {c.clause_heading}: </strong>}
              {c.clause_text}
            </li>
          ))}
        </ul>
      )}
      <form className="admin-clause-form" onSubmit={addClause}>
        <input placeholder="Heading (optional)" value={heading} onChange={(e) => setHeading(e.target.value)} />
        <textarea
          placeholder="Clause text -- the actual policy sentence a guardrail will cite"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={2}
          required
        />
        <button className="btn-primary" type="submit" disabled={busy}>
          {busy ? "Adding…" : "Add clause"}
        </button>
      </form>
    </div>
  );
}

export function AdminDocuments() {
  const [documents, setDocuments] = useState<GovernanceDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [versioning, setVersioning] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [domain, setDomain] = useState("Information Security");
  const [version, setVersion] = useState("1.0");
  const [summary, setSummary] = useState("");

  const [newVersion, setNewVersion] = useState("");

  function load() {
    setLoading(true);
    api.listDocuments().then(setDocuments).catch((e) => setError((e as Error).message)).finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function addDocument(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      const created = await api.createDocument({ title, domain, version, summary: summary || undefined });
      setTitle("");
      setSummary("");
      setShowAdd(false);
      load();
      setExpanded(created.id);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function bumpVersion(documentId: string) {
    if (!newVersion.trim()) return;
    setError(null);
    try {
      await api.bumpDocumentVersion(documentId, newVersion.trim());
      setNewVersion("");
      setVersioning(null);
      load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  return (
    <div className="admin-documents">
      <div className="admin-documents-header">
        <h1>
          <FileText size={20} /> Governance Documents
        </h1>
        <button className="btn-primary" onClick={() => setShowAdd((s) => !s)}>
          <Plus size={14} /> Add document
        </button>
      </div>
      <p className="admin-documents-sub">
        Bumping a document's version notifies every viewer of the main app with an in-app popup the next time they
        load it. Expand a document to add the real clauses a guardrail can cite -- a document with no clauses has
        nothing to reference.
      </p>

      {error && <p className="admin-documents-error">{error}</p>}

      {showAdd && (
        <form className="admin-documents-form" onSubmit={addDocument}>
          <label>
            Title
            <input value={title} onChange={(e) => setTitle(e.target.value)} required />
          </label>
          <label>
            Domain
            <input value={domain} onChange={(e) => setDomain(e.target.value)} required />
          </label>
          <label>
            Version
            <input value={version} onChange={(e) => setVersion(e.target.value)} required />
          </label>
          <label>
            Summary (optional)
            <textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={2} />
          </label>
          <AdminFileUploadButton
            label="Upload file to fill summary"
            extract={(file) => api.extractDocumentFile(file)}
            onExtracted={(text, suggestedTitle) => {
              setSummary(text);
              if (suggestedTitle && !title.trim()) setTitle(suggestedTitle);
            }}
          />
          <button className="btn-primary" type="submit">
            Create
          </button>
        </form>
      )}

      {loading && <p>Loading…</p>}

      <div className="admin-documents-list">
        {documents.map((d) => (
          <div key={d.id} className="admin-document-row">
            <div className="admin-document-row-top">
              <button
                className="admin-document-expand"
                onClick={() => setExpanded(expanded === d.id ? null : d.id)}
                aria-label="Toggle clauses"
              >
                {expanded === d.id ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
              </button>
              <div className="admin-document-main">
                <div className="admin-document-title">{d.title}</div>
                <div className="admin-document-meta">
                  {d.domain} · v{d.version} {d.effective_date && <>· effective {d.effective_date}</>} · {d.status}
                </div>
              </div>
              {versioning === d.id ? (
                <div className="admin-document-version-form">
                  <input
                    placeholder="New version"
                    value={newVersion}
                    onChange={(e) => setNewVersion(e.target.value)}
                    autoFocus
                  />
                  <button className="btn-primary" onClick={() => bumpVersion(d.id)}>
                    Save
                  </button>
                  <button className="btn-ghost" onClick={() => setVersioning(null)}>
                    Cancel
                  </button>
                </div>
              ) : (
                <button className="btn-ghost admin-document-version-btn" onClick={() => setVersioning(d.id)}>
                  <RefreshCw size={13} /> New version
                </button>
              )}
            </div>
            {expanded === d.id && <DocumentClauses documentId={d.id} />}
          </div>
        ))}
      </div>
    </div>
  );
}
