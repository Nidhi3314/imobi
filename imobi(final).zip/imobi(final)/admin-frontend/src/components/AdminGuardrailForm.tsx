import { useState } from "react";
import { ShieldPlus } from "lucide-react";
import { api } from "../api/client";
import { AdminFileUploadButton } from "./AdminFileUploadButton";
import "./AdminGuardrailForm.scss";

const SEVERITIES = ["Mandatory", "High", "Medium", "Low"];

export function AdminGuardrailForm() {
  const [domain, setDomain] = useState("Information Security");
  const [statement, setStatement] = useState("");
  const [severity, setSeverity] = useState("Mandatory");
  const [category, setCategory] = useState("");
  const [clauseIds, setClauseIds] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setBusy(true);
    try {
      const ids = clauseIds.split(",").map((s) => s.trim()).filter(Boolean);
      const result = await api.createGuardrail({
        domain,
        statement,
        severity,
        category: category || undefined,
        source_clause_ids: ids,
      });
      setSuccess(`Created ${(result as { id: string }).id}.`);
      setStatement("");
      setClauseIds("");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-guardrail-form">
      <h1>
        <ShieldPlus size={20} /> Add a Guardrail
      </h1>
      <p className="admin-guardrail-sub">
        Manually added guardrails are held to the same rule as every derived one: they must cite at least one real
        clause ID. An unknown clause ID is rejected outright rather than silently accepted as a broken reference.
      </p>

      <form onSubmit={submit} className="admin-guardrail-form-fields">
        <label>
          Domain
          <input value={domain} onChange={(e) => setDomain(e.target.value)} required />
        </label>
        <label>
          Category (optional)
          <input value={category} onChange={(e) => setCategory(e.target.value)} />
        </label>
        <label>
          Severity
          <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
            {SEVERITIES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>
        <label>
          Requirement statement
          <textarea value={statement} onChange={(e) => setStatement(e.target.value)} rows={3} required />
        </label>
        <AdminFileUploadButton
          label="Upload file to fill statement"
          extract={(file) => api.extractGuardrailFile(file)}
          onExtracted={(text) => setStatement(text)}
        />
        <label>
          Source clause ID(s), comma-separated
          <input
            value={clauseIds}
            onChange={(e) => setClauseIds(e.target.value)}
            placeholder="CL-0001, CL-0002"
            required
          />
        </label>
        {error && <p className="admin-guardrail-error">{error}</p>}
        {success && <p className="admin-guardrail-success">{success}</p>}
        <button className="btn-primary" type="submit" disabled={busy}>
          {busy ? "Creating…" : "Create guardrail"}
        </button>
      </form>
    </div>
  );
}
