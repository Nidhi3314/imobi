import { useEffect, useState } from "react";
import { UserRound } from "lucide-react";
import { api } from "../api/client";
import "./AdminUsers.scss";

interface RegisteredUser {
  id: number;
  username: string;
  email: string;
  display_name: string | null;
  created_at: string | null;
}

export function AdminUsers() {
  const [users, setUsers] = useState<RegisteredUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listUsers()
      .then(setUsers)
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="admin-users">
      <h1>
        <UserRound size={20} /> Registered Users
      </h1>
      <p className="admin-users-sub">
        Everyone who has registered via the main app's User Console — read-only visibility. This grants no rights
        over those accounts; User and admin identities stay fully separate.
      </p>

      {error && <p className="admin-users-error">{error}</p>}
      {loading ? (
        <p>Loading…</p>
      ) : users.length === 0 ? (
        <p className="admin-users-empty">No one has registered yet.</p>
      ) : (
        <div className="admin-users-list">
          {users.map((u) => (
            <div key={u.id} className="admin-user-row">
              <div className="admin-user-main">
                <div className="admin-user-name">{u.display_name || u.username}</div>
                <div className="admin-user-meta">
                  @{u.username} · {u.email}
                </div>
              </div>
              <div className="admin-user-joined">
                {u.created_at ? new Date(u.created_at).toLocaleDateString() : "—"}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
