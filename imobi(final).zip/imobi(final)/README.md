# CompliX

An AI-powered platform that turns scattered governance documents into a structured,
traceable guardrail model, then evaluates design descriptions against it — every
finding (compliant, non-compliant, or gap) citing the exact guardrail and source
clause it came from. No citation, no verdict.

Built for the GuardrailIQ Challenge, with a domain focus on **Information Security**.

## Why this shape

The fixed, judged requirement is trust and traceability, not any particular
technique — the guide explicitly says a modified copy of the dataset will be used for
judging, so nothing here matches on sample IDs. Everything is driven by meaning:
domain labels, text similarity, and normalized numeric values, never a literal
`KG-xxxx` or `CL-xxxx` string.

The **Conflict Desk** is the flagship feature: cross-document conflicts (e.g. two
policies stating different log-retention periods) are surfaced with a rationale and an
impact analysis, and a human reviewer explicitly approves one side, approves the
other, or keeps it open — the platform never silently picks a value. Every decision a
reviewer makes becomes learned precedent: the Conflict Agent cites it the next time a
structurally similar conflict shows up, even against a completely different (e.g.
re-uploaded, re-IDed) copy of the dataset. This is deliberately a multi-agent design
(Extraction, Dedup, Conflict, Evaluation, Auditor, Precedent, and an Orchestrator that
routes chat messages to the right one), reflecting this year's agentic-platforms
theme, layered on top of a deterministic citation gate that can't be argued out of the
"no ungrounded verdicts" rule.

## Three apps, one backend

- **`frontend/`** — the main app (Dashboard, Chat, Guardrail Explorer, Conflict Desk
  read-only view, Architectural Analysis, Judge Mode). Anyone can register a CompliX **User
  Console** account here (name + email, no special rights) for a personalized chat.
- **`admin-frontend/`** — a separate **Admin Console** app, deliberately isolated on
  its own port. This is the only place Conflict Desk tickets actually get decided —
  reviewers register/sign in here, and every decision is attributed to their account.
- **`backend/`** — the FastAPI service both apps talk to.

## Architecture

```
Excel workbook (Documents, Clauses, Design_Descriptions)
        │
        ▼
 Extraction Agent  ──▶  Dedup Agent  ──▶  Orphan Agent  ──▶  Conflict Agent
 (clause → draft         (merge near-       (validate every    (flag cross-doc value
  guardrail record)       duplicates,        source clause/      conflicts; consults
                          union sources)      doc reference)      Precedent Agent;
                                                                    opens a ticket)
        │
        ▼
   SQLite: documents / clauses / guardrails / guardrail_sources /
           guardrail_relationships / conflict_tickets / design_descriptions /
           users / admin_users (+ their sessions)
        │
        ▼
 Evaluation Agent (per design: retrieve candidates → verdict + evidence)
        │
        ▼
 Auditor Agent (independent critique)  ──▶  Citation Gate (deterministic backstop)
        │
        ▼
 Chat Composer (writes the answer in prose; citations come straight from the
 structured records above, never parsed out of that prose)
        │
        ▼
 FastAPI (/guardrails, /evaluate, /conflicts, /ingest/upload, /chat, /user, /admin, /debug, /architecture)
        │
        ▼
 React: main app (:5173) + Admin Console (:5174)
```

## Running it

### 1. Get the dataset

This repo does **not** include the hackathon-provided dataset or participant guide —
they're synthetic materials for the challenge, not ours to redistribute. Place your
own copies in the repo root before starting the backend:

```
CompliX/
  AI-Powered Enterprise Compliance Intelligence System_GuardrailIQ_Dataset_v2.xlsx
  backend/
  frontend/
  admin-frontend/
```

(Or point `GUARDRAILIQ_DATASET_PATH` at wherever you keep it.) Any workbook with the
same sheet shapes (`Governance_Documents`, `Clauses`, `Design_Descriptions`) works —
that's what Judge Mode's live-upload exists to prove.

### 2. Backend
```
cd backend
pip install -r requirements.txt
cp .env.example .env   # fill in an LLM key if you have one -- optional, see below
python -m uvicorn app.main:app --reload
```
Runs on `http://localhost:8000`. On startup it ingests the dataset from step 1 and
runs the full pipeline automatically.

**LLM (optional but recommended):** without one configured, every agent falls back to
a deterministic regex/lexical heuristic (the guide explicitly allows an LLM-free
approach) — the pipeline still runs end-to-end and correctly catches the sample
dataset's seeded duplicate/conflict scenarios. `.env` (git-ignored) takes:
```
GUARDRAILIQ_LLM_BASE_URL=<your OpenAI-compatible chat-completions base URL>
GUARDRAILIQ_LLM_API_KEY=<key>
GUARDRAILIQ_LLM_MODEL=<model name>
```
Tested against Google Gemini's OpenAI-compatibility layer
(`https://generativelanguage.googleapis.com/v1beta/openai`, model `gemini-2.5-flash`)
as a placeholder during development. Swapping in another gateway is a one-file change
(`backend/app/llm/client.py`).

**OCR (optional, complements the vision LLM):** architecture-diagram analysis
(`/architecture/evaluate`, and the chat "attach a diagram" flow) runs Tesseract OCR over
the uploaded image via `pytesseract`. When a vision LLM is configured, the OCR'd text is
folded into its prompt as grounding and its own regex-based exposure/label detection
(`app/vision/architecture_agent.py`) is unioned into the LLM's output — catching exact
on-diagram strings (a secret, an IP, default credentials) a vision model can paraphrase
or miss. When no vision LLM is configured, OCR text drives the deterministic extraction
path on its own instead of the feature being unavailable. Install the
[Tesseract OCR](https://github.com/tesseract-ocr/tesseract) binary (`winget install
UB-Mannheim.TesseractOCR` on Windows, `brew install tesseract` on macOS, `apt install
tesseract-ocr` on Debian/Ubuntu) and set `GUARDRAILIQ_TESSERACT_CMD` to its path if it
isn't on `PATH`. Without it, diagram analysis still works via the vision LLM alone (or,
if neither is available, returns a plain "nothing to evaluate" message rather than
failing oddly).

**MCP (Model Context Protocol):** two independent, optional integrations —
- *CompliX as an MCP server* (`app/mcp/server.py`): exposes `list_guardrails`,
  `get_guardrail`, `list_domains`, `evaluate_design`, `list_open_conflicts`, and
  `ask_complix` as MCP tools, so Claude Desktop/Claude Code or any other MCP host can
  browse the guardrail model and run a citation-gated design evaluation directly. Every
  tool calls the same DB/agent code the FastAPI routes use — an MCP client and the web
  UI never see a different shape of the same data. Two transports, same tools:
  - **stdio**, for hosts that spawn a local process: `python mcp_server.py` (run from
    `backend/`, same `.env`/venv as the backend), e.g. for Claude Code: `claude mcp add
    complix -- python /absolute/path/to/backend/mcp_server.py`.
  - **SSE, mounted on the running backend itself** at `GET /mcp/sse` — for a host that
    connects to a URL instead of spawning a process (Claude Desktop/Code's remote-MCP
    config, Cursor, Windsurf, etc.), point it at `http://localhost:8000/mcp/sse`
    directly; no separate process needed. Verified with the official `mcp` Python
    client (`mcp.client.sse.sse_client`) round-tripping `list_tools`/`call_tool` over
    the network. See `app.main`'s `app.mount("/mcp", ...)`.
- *CompliX's own agents calling external MCP servers* (`backend/app/mcp/client_manager.py`):
  set `GUARDRAILIQ_MCP_SERVERS` to a JSON array of
  `{"name": str, "command": str, "args": [str], "env": {str: str}?}` and the chat
  Orchestrator's guardrail-search and conflict-analysis reply composition
  (`_compose_search_with_llm`, `_analyze_conflicts_with_llm`) will let the LLM call
  those servers' tools while writing its answer. Left unset (the default), this is a
  no-op — the same graceful-degradation pattern the LLM gateway itself uses.
  Scoped deliberately to prose composition only: no tool output can become or alter a
  citation or a compliance verdict, which still come straight from guardrail/clause
  records via the Evaluation Agent → Auditor Agent → Citation Gate chain, unchanged.

  Two ways to configure it: `GUARDRAILIQ_MCP_SERVERS` at startup (server-wide, any MCP
  server), or live from the main app's Chat — the settings panel (gear icon) has an
  **Integrations** section where a user can attach Jira and/or Confluence directly,
  no restart needed (`POST /chat/integrations/attach`, `app/mcp/runtime_servers.py`).
  Both feed the exact same tool-calling path; the live-attach credentials are held
  in process memory only (never written to disk, the database, or a log line) and are
  gone on backend restart — appropriate for a local/demo deployment, not a substitute
  for real per-user secret storage in a multi-user production one.

  **Why this matters for compliance specifically:** a guardrail model that only lives
  inside CompliX is still an island — the actual remediation work happens in whatever
  tracker and wiki the org already uses. Attach a real Jira/Confluence connection
  (both map onto [sooperset/mcp-atlassian](https://github.com/sooperset/mcp-atlassian),
  run via `uvx mcp-atlassian` — see `.env.example` for the exact env block if you'd
  rather configure it at startup) and a reviewer's question stops being answered from
  CompliX's data alone:
  - *Conflict Desk*: "is anyone already tracking this?" — the agent checks Jira instead
    of the reviewer having to context-switch and search manually.
  - *Guardrail Explorer*: "why does this guardrail require 90-day retention?" — the
    agent can pull the actual Confluence policy page the number came from, not just
    the clause CompliX already cites.
  - Either agent can also *write*, not just read — e.g. file a Jira ticket for an open
    conflict on request — turning "we found a discrepancy" into a tracked piece of work
    without leaving the conversation.

  This is the same trust boundary as everything else in this README: Jira/Confluence
  content can inform what the model *says*, but a citation still only exists if it
  traces back to a real guardrail/clause in the database — an MCP tool has no path to
  fabricate one.

**Exposing CompliX to other agentic platforms (A2A / ACP):** the two MCP directions
above are about CompliX's own agents calling *out*; this is the reverse — letting an
external agentic platform add CompliX itself as a callable agent, over two open
interoperability protocols (`app/api/routes_agent_protocols.py`):
- **A2A (Agent2Agent):** `GET /.well-known/agent.json` returns an Agent Card (name,
  skills, capabilities) any A2A-compatible client can use to discover CompliX; tasks
  are submitted to `POST /a2a` via a minimal `tasks/send` JSON-RPC call.
- **ACP (Agent Communication Protocol):** `GET /acp/agents` returns an ACP-shaped
  manifest; runs are submitted to `POST /acp/runs` with `agent_name: "complix"`.

Both handlers call the exact same `Orchestrator.handle_message()` the web UI's
`POST /chat` uses — an external platform gets the same citation-gated answer a person
typing in the chat window does, never a looser guarantee. The main app's **Chat**
sidebar has a "Connect an external agent" button (below Chat history) that surfaces
all five URLs (MCP's SSE endpoint included), ready to copy into whatever platform is
doing the connecting.

### 3. Main app
```
cd frontend
npm install
npm run dev
```
Runs on `http://localhost:5173`.

### 4. Admin Console
```
cd admin-frontend
npm install
npm run dev
```
Runs on `http://localhost:5174`. Register an account here to decide Conflict Desk
tickets — this is a separate identity from the main app's User Console.

Both frontends default to a backend at `localhost:8000` — set `VITE_API_BASE_URL` (and
`VITE_ADMIN_CONSOLE_URL` in `frontend/`) if that's not where it's running.

### Tests
```
cd backend
python -m pytest tests/ -v
```
Covers dedup (merges true duplicates, preserves all sources, doesn't merge unrelated
clauses or cross-domain), conflict detection (cross-domain conflicts, no false
positives from a shared verb family alone, identical values aren't conflicts), orphan
detection, the citation gate (rejects fabricated guardrail/clause IDs, rejects broken
references, passes real citations through), precedent learning, the ingest-reset
regression (a re-ingested workbook fully replaces the previous one instead of
accumulating), and User/Admin account isolation.

## Assumptions

- The provided `Guardrails` sheet is treated as a **sample target schema**, not ground
  truth to copy — guardrails are derived independently from `Clauses` so the system
  survives a workbook that doesn't ship a pre-built guardrail sheet at all.
- Embeddings use TF-IDF / stemmed content-word Jaccard overlap rather than a
  transformer model — a torch/transformers version conflict made
  `sentence-transformers` unusable in the dev environment, and classical NLP is
  explicitly an accepted approach per the guide. When an LLM is configured, it does the
  semantic heavy lifting instead; the lexical path is the fallback.
- Cross-document conflict detection is **not** domain-scoped, because the seeded
  retention conflict spans Information Security and Privacy documents — scoping to one
  domain would have structurally missed it.
- "Judge Mode" (`/ingest/upload`) runs the identical pipeline against any uploaded
  workbook matching the sheet shapes, live — used to demonstrate the system isn't
  hardcoded to the sample IDs. Every ingest fully replaces the previous one (Documents/
  Clauses/Designs/open tickets), except *decided* Conflict Desk tickets, which persist
  as learned precedent across dataset changes.
- All data used is the synthetic workbook provided for this challenge. No real,
  sensitive, or proprietary content was used.

## Disclosure

LLM/frameworks used: FastAPI, SQLAlchemy, scikit-learn (TF-IDF), React, Tesseract OCR
(via `pytesseract`), the official `mcp` Python SDK, and — when configured — an
OpenAI-compatible chat-completions LLM gateway (tested against Google Gemini's
compatibility layer). No agent framework (LangChain/CrewAI/etc.) — agents are
hand-rolled Python modules behind one shared `llm/client.py` seam; the `mcp` SDK is used
directly for its stdio server/client primitives, not as an agent framework.
